package Editar;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Graphic.Buscar.ResultadosBusquedaCamino;
import Graphic.Buscar.ResultadosBusquedaPlanta;
import isi.died.tp.dominio.Planta;
import logica.Logica;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EditarPlanta extends JFrame {

	private JPanel contentPane;
	private JTextField id;
	private JTextField nombre;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditarPlanta frame = new EditarPlanta();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditarPlanta() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 376);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null); //para centrar
		
		JLabel lblEditarPlanta = new JLabel("Editar Planta");
		lblEditarPlanta.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblEditarPlanta.setBounds(23, 13, 203, 52);
		contentPane.add(lblEditarPlanta);
		
		JLabel lblIdPlanta = new JLabel("Id Planta:");
		lblIdPlanta.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblIdPlanta.setBounds(259, 105, 98, 16);
		contentPane.add(lblIdPlanta);
		
		id = new JTextField();
		id.setEditable(false);
		id.setBounds(404, 98, 116, 22);
		id.setText(ResultadosBusquedaPlanta.plantaGlob.toString());
		contentPane.add(id);
		id.setColumns(10);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNombre.setBounds(259, 185, 82, 16);
		contentPane.add(lblNombre);
		
		nombre = new JTextField();
		nombre.setBounds(404, 179, 116, 22);
		contentPane.add(nombre);
		nombre.setColumns(10);
		
		JButton btnModificar = new JButton("Modificar");
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(nombre.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Debe ingresar el nombre nuevo","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				else {
					Planta plantaNueva= new Planta(ResultadosBusquedaPlanta.plantaGlob.getIdPlanta(),nombre.getText());
					Logica.listaPlantasIndustria.remove(ResultadosBusquedaPlanta.plantaGlob);
					Logica.listaPlantasIndustria.add(plantaNueva);

					JOptionPane.showMessageDialog(null, "Se ha modificado correctamente","¡Exito!", JOptionPane.WARNING_MESSAGE);
				}
				
			}
		});
		btnModificar.setBounds(538, 291, 97, 25);
		contentPane.add(btnModificar);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final ResultadosBusquedaPlanta agregar= new ResultadosBusquedaPlanta();
				agregar.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(690, 291, 97, 25);
		contentPane.add(btnAtras);
	}
}
