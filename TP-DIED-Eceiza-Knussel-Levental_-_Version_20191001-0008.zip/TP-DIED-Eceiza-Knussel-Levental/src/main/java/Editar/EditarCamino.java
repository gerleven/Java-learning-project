package Editar;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Graphic.Agregar.VentanaAgregar;
import Graphic.Buscar.ResultadosBusquedaCamino;
import Graphic.Buscar.ResultadosBusquedaPlanta;
import isi.died.tp.dominio.Planta;
import isi.died.tp.estructuras.Arista;
import isi.died.tp.estructuras.Vertice;
import logica.Logica;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;

public class EditarCamino extends JFrame {

	private JPanel contentPane;
	private JTextField distancia;
	private JTextField duracion;
	private JTextField peso;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditarCamino frame = new EditarCamino();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditarCamino() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		setLocationRelativeTo(null); //para centrar
		
		distancia = new JTextField();
		distancia.setFont(new Font("Tahoma", Font.PLAIN, 15));
		distancia.setColumns(10);
		distancia.setBounds(418, 373, 237, 22);
		distancia.setText(ResultadosBusquedaCamino.caminoGlob.getDistancia().toString());
		contentPane.add(distancia);
		
		duracion = new JTextField();
		duracion.setFont(new Font("Tahoma", Font.PLAIN, 15));
		duracion.setColumns(10);
		duracion.setBounds(418, 320, 237, 22);
		duracion.setText(ResultadosBusquedaCamino.caminoGlob.getDuracionDelViaje().toString());
		contentPane.add(duracion);
		
		peso = new JTextField();
		peso.setFont(new Font("Tahoma", Font.PLAIN, 15));
		peso.setColumns(10);
		peso.setBounds(418, 256, 237, 22);
		peso.setText(ResultadosBusquedaCamino.caminoGlob.getPesoMaximoCamino().toString());
		contentPane.add(peso);
		
		JComboBox plantaFin = new JComboBox();
		plantaFin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		List<String> nombrePlantas2 = new ArrayList<>();
		List<Planta> plantasFiltradas2 = new ArrayList<>(Logica.listaPlantasIndustria);
		if (!plantasFiltradas2.isEmpty()) plantasFiltradas2.remove(0);//no te tiene que incluir la del Puerto.
		for(Planta p : plantasFiltradas2) nombrePlantas2.add(p.get_Nombre_Id());
		plantaFin.setModel(new DefaultComboBoxModel(nombrePlantas2.toArray()));
		plantaFin.setBounds(418, 185, 237, 22);
		contentPane.add(plantaFin);
		
		JComboBox plantaInicial = new JComboBox();
		plantaInicial.setFont(new Font("Tahoma", Font.PLAIN, 15));
		List<String> nombrePlantas = new ArrayList<>();
		List<Planta> plantasFiltradas = new ArrayList<>(Logica.listaPlantasIndustria);
		if (!plantasFiltradas.isEmpty()) plantasFiltradas.remove(1);//no te tiene que incluir la del AcopioFinal.
		for(Planta p : plantasFiltradas) nombrePlantas.add(p.get_Nombre_Id());
		plantaInicial.setModel(new DefaultComboBoxModel(nombrePlantas.toArray()));
		plantaInicial.setBounds(418, 117, 237, 22);
		contentPane.add(plantaInicial);
		
		JLabel label = new JLabel("Planta Inicial:");
		label.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label.setBounds(226, 121, 88, 16);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Planta final:");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_1.setBounds(226, 192, 88, 16);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("Peso Maximo:");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_2.setBounds(226, 263, 97, 16);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("Duracion:");
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_3.setBounds(226, 324, 88, 16);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("Distancia:");
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label_4.setBounds(225, 379, 88, 16);
		contentPane.add(label_4);
		
		JLabel lblEditarCamino = new JLabel("Editar Camino");
		lblEditarCamino.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblEditarCamino.setBounds(34, 25, 252, 46);
		contentPane.add(lblEditarCamino);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final ResultadosBusquedaCamino agregar= new ResultadosBusquedaCamino();
				agregar.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(719, 470, 97, 25);
		contentPane.add(btnAtras);
		
		JButton btnModificar = new JButton("Modificar");
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(distancia.getText().isEmpty()||duracion.getText().isEmpty()||peso.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Todos los campos deben estar completos","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				else {
					int seleccion =plantaInicial.getSelectedIndex();
					Vertice vertiIniNuevo= new Vertice(plantasFiltradas2.get(seleccion));
					
					int seleccion2= plantaFin.getSelectedIndex();
					Vertice vertiFinNuevo= new Vertice(plantasFiltradas2.get(seleccion2));
					
					
					for(int i=0; i<Logica.grafoDePlantas.getAristas().size();i++) {
						
						//obtengo el camino a editar
						if(Logica.grafoDePlantas.getAristas().get(i).getInicio().equals(ResultadosBusquedaCamino.caminoGlob.getInicio())&&
								Logica.grafoDePlantas.getAristas().get(i).getFin().equals(ResultadosBusquedaCamino.caminoGlob.getFin())) {
							
							//System.out.println("**************************************"+Logica.grafoDePlantas.getAristas().get(i));
							//System.out.println("-----------------------------------"+ResultadosBusquedaCamino.caminoGlob);
							
							//actualizo el camino
							Logica.grafoDePlantas.getAristas().get(i).setInicio(vertiIniNuevo);
							Logica.grafoDePlantas.getAristas().get(i).setFin(vertiFinNuevo);
							Logica.grafoDePlantas.getAristas().get(i).setDistancia(Double.parseDouble(distancia.getText()));
							Logica.grafoDePlantas.getAristas().get(i).setDuracionDelViaje(Integer.parseInt(duracion.getText()));
							Logica.grafoDePlantas.getAristas().get(i).setPesoMaximoCamino(Double.parseDouble(peso.getText()));
						}
					}

					JOptionPane.showMessageDialog(null, "Se ha modificado correctamente","¡Exito!", JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnModificar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnModificar.setBounds(570, 470, 97, 25);
		contentPane.add(btnModificar);
	}
}
