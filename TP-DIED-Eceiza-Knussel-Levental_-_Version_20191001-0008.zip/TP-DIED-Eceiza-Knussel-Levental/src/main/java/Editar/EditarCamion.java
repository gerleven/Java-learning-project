package Editar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Graphic.Agregar.AgregarCamiones;
import Graphic.Agregar.VentanaAgregar;
import Graphic.Buscar.ResultadosBusquedaCamion;
import isi.died.tp.dominio.Camion;
import logica.Logica;

public class EditarCamion extends JFrame {

	private JPanel contentPane;
	private JTextField marca;
	private JTextField modelo;
	private JTextField dominio;
	private JTextField anio;
	private JTextField costoKm;
	private JTextField capacidad;
	private JTextField id;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditarCamion frame = new EditarCamion();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditarCamion() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAgregarCamiones = new JLabel("Editar Camiones");
		lblAgregarCamiones.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblAgregarCamiones.setBounds(22, 13, 293, 37);
		contentPane.add(lblAgregarCamiones);
		
		JLabel lblMarca = new JLabel("Marca:");
		lblMarca.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMarca.setBounds(145, 296, 56, 16);
		contentPane.add(lblMarca);
		
		marca = new JTextField();
		marca.setColumns(10);
		marca.setBounds(245, 293, 116, 22);
		marca.setText(ResultadosBusquedaCamion.camionGlob.getMarca());
		contentPane.add(marca);
		
		JLabel lblModelo = new JLabel("Modelo:");
		lblModelo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblModelo.setBounds(145, 399, 56, 16);
		contentPane.add(lblModelo);
		
		modelo = new JTextField();
		modelo.setColumns(10);
		modelo.setBounds(245, 396, 116, 22);
		modelo.setText(ResultadosBusquedaCamion.camionGlob.getModelo());
		contentPane.add(modelo);
		
		JLabel lblDominio = new JLabel("Dominio:");
		lblDominio.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDominio.setBounds(145, 194, 56, 16);
		contentPane.add(lblDominio);
		
		JLabel lblAo = new JLabel("Año:");
		lblAo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblAo.setBounds(440, 291, 56, 16);
		contentPane.add(lblAo);
		
		JLabel lblCostoPorKm = new JLabel("Costo por Km:");
		lblCostoPorKm.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblCostoPorKm.setBounds(440, 81, 99, 16);
		contentPane.add(lblCostoPorKm);
		
		JLabel lblCapacidad = new JLabel("Capacidad:");
		lblCapacidad.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblCapacidad.setBounds(440, 188, 83, 16);
		contentPane.add(lblCapacidad);
		
		JRadioButton rbAptoLiqu = new JRadioButton("Apto para líquidos");
		rbAptoLiqu.setFont(new Font("Tahoma", Font.PLAIN, 15));
		rbAptoLiqu.setBounds(440, 395, 170, 25);
		contentPane.add(rbAptoLiqu);
		
		dominio = new JTextField();
		dominio.setColumns(10);
		dominio.setBounds(245, 191, 116, 22);
		dominio.setText(ResultadosBusquedaCamion.camionGlob.getDominio().toString());
		contentPane.add(dominio);
		
		anio = new JTextField();
		anio.setColumns(10);
		anio.setBounds(562, 288, 116, 22);
		anio.setText(ResultadosBusquedaCamion.camionGlob.getAnio().toString());
		contentPane.add(anio);
		
		costoKm = new JTextField();
		costoKm.setColumns(10);
		costoKm.setBounds(562, 78, 116, 22);
		costoKm.setText(ResultadosBusquedaCamion.camionGlob.getCostoPorKm().toString());
		contentPane.add(costoKm);
		
		capacidad = new JTextField();
		capacidad.setColumns(10);
		capacidad.setBounds(562, 185, 116, 22);
		capacidad.setText(ResultadosBusquedaCamion.camionGlob.getCapacidad().toString());
		contentPane.add(capacidad);

		id = new JTextField();
		id.setEditable(false);
		id.setBounds(245, 79, 116, 22);
		id.setText(ResultadosBusquedaCamion.camionGlob.getIdCamion().toString());
		contentPane.add(id);
		id.setColumns(10);
		
		JButton btnAceptar = new JButton("Modificar");
		btnAceptar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	
				if(marca.getText().isEmpty()||modelo.getText().isEmpty()||dominio.getText().isEmpty()||anio.getText().isEmpty()||costoKm.getText().isEmpty()||capacidad.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Debe completar todos los campos","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				else {
				
				//Contructor Camion(Integer idCamion, String marca, String modelo, Integer dominio, Integer anio, Float costoPorKm,Boolean aptoLiquidos, Float capacidad)
					for(int i=0; i<Logica.listaCamiones.size();i++) {
						
						if(Logica.listaCamiones.get(i).getIdCamion()==ResultadosBusquedaCamion.camionGlob.getIdCamion()) {
							
							Logica.listaCamiones.get(i).setAnio(Integer.parseInt(anio.getText()));
							Logica.listaCamiones.get(i).setAptoLiquidos(rbAptoLiqu.isSelected());
							Logica.listaCamiones.get(i).setCapacidad(Double.parseDouble(capacidad.getText()));
							Logica.listaCamiones.get(i).setCostoPorKm(Double.parseDouble(costoKm.getText()));
							Logica.listaCamiones.get(i).setDominio(Integer.parseInt(dominio.getText()));
							Logica.listaCamiones.get(i).setIdCamion(Integer.parseInt(id.getText()));
							Logica.listaCamiones.get(i).setMarca(marca.getText());
							Logica.listaCamiones.get(i).setModelo(modelo.getText());
							
							JOptionPane.showMessageDialog(null, "Se ha modificado con éxito","¡Exito!", JOptionPane.WARNING_MESSAGE);
							
						}
					}
					
				}
			}
		});
		btnAceptar.setBounds(595, 470, 97, 25);
		contentPane.add(btnAceptar);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final ResultadosBusquedaCamion a = new ResultadosBusquedaCamion();
				a.setVisible(true);
				dispose();		
			}
		});
		btnAtras.setBounds(719, 470, 97, 25);
		contentPane.add(btnAtras);
		
		JLabel lblId = new JLabel("Id");
		lblId.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblId.setBounds(145, 82, 56, 16);
		contentPane.add(lblId);
		
		

		setLocationRelativeTo(null); //para centrar
		
		
	}	
}
