package Editar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Graphic.Buscar.ResultadosBusquedaCamino;
import Graphic.Buscar.ResultadosBusquedaInsumo;
import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.InsumoLiquido;
import isi.died.tp.dominio.UnidadDeMedida;
import logica.Logica;

public class EditarInsumo extends JFrame {

	private JPanel contentPane;
	private JTextField costo;
	private JTextField peso;
	private JTextField nombre;
	private JTextField densidad;
	private JTextField id;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditarInsumo frame = new EditarInsumo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditarInsumo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 621);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null); //para centrar
		
		JLabel label = new JLabel("Costo:");
		label.setFont(new Font("Dialog", Font.PLAIN, 15));
		label.setBounds(250, 277, 56, 16);
		contentPane.add(label);
		
		costo = new JTextField();
		costo.setToolTipText("");
		costo.setColumns(10);
		costo.setBounds(419, 275, 183, 22);
		costo.setText(ResultadosBusquedaInsumo.insumoGlob.getCosto().toString());
		contentPane.add(costo);
		
		JLabel label_1 = new JLabel("Peso:");
		label_1.setFont(new Font("Dialog", Font.PLAIN, 15));
		label_1.setBounds(250, 204, 56, 16);
		contentPane.add(label_1);
		
		peso = new JTextField();
		peso.setColumns(10);
		peso.setBounds(419, 202, 183, 22);
		peso.setText(ResultadosBusquedaInsumo.insumoGlob.getPeso().toString());
		contentPane.add(peso);
		
		JLabel label_2 = new JLabel("Nombre:");
		label_2.setFont(new Font("Dialog", Font.PLAIN, 15));
		label_2.setBounds(250, 133, 56, 16);
		contentPane.add(label_2);
		
		nombre = new JTextField();
		nombre.setColumns(10);
		nombre.setBounds(419, 131, 183, 22);
		nombre.setText(ResultadosBusquedaInsumo.insumoGlob.getNombre());
		contentPane.add(nombre);
		
		JLabel label_3 = new JLabel("Unidad de medida:");
		label_3.setFont(new Font("Dialog", Font.PLAIN, 15));
		label_3.setBounds(250, 349, 138, 16);
		contentPane.add(label_3);
		
		JComboBox unidadMedida = new JComboBox();
		unidadMedida.setBounds(419, 349, 183, 22);
		UnidadDeMedida listaUnidadesDeMedida[] = new UnidadDeMedida[] {UnidadDeMedida.KILO,UnidadDeMedida.PIEZA,UnidadDeMedida.GRAMO,UnidadDeMedida.METRO,UnidadDeMedida.LITRO,UnidadDeMedida.M3,UnidadDeMedida.M2};
		unidadMedida.setModel(new DefaultComboBoxModel(listaUnidadesDeMedida));
		
		contentPane.add(unidadMedida);
		
		JCheckBox liquido = new JCheckBox("Insumo liquido");
		liquido.setFont(new Font("Dialog", Font.PLAIN, 15));
		liquido.setBounds(248, 413, 140, 25);
		contentPane.add(liquido);
		
		JRadioButton refrigerado = new JRadioButton("Refrigerado");
		refrigerado.setFont(new Font("Dialog", Font.PLAIN, 15));
		refrigerado.setBounds(493, 413, 109, 25);
		contentPane.add(refrigerado);
		
		JLabel label_4 = new JLabel("Densidad:");
		label_4.setFont(new Font("Dialog", Font.PLAIN, 15));
		label_4.setBounds(250, 481, 73, 16);
		contentPane.add(label_4);
		
		densidad = new JTextField();
		densidad.setColumns(10);
		densidad.setBounds(419, 479, 183, 22);
		contentPane.add(densidad);
		
		JLabel lblEditarInsumo = new JLabel("Editar insumo");
		lblEditarInsumo.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblEditarInsumo.setBounds(24, 13, 166, 39);
		contentPane.add(lblEditarInsumo);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Dialog", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final ResultadosBusquedaInsumo agregar= new ResultadosBusquedaInsumo();
				agregar.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(719, 536, 97, 25);
		contentPane.add(btnAtras);
		
		
		id = new JTextField();
		id.setBounds(419, 78, 183, 22);
		contentPane.add(id);
		id.setText(ResultadosBusquedaInsumo.insumoGlob.getIdInsumo().toString());
		id.setColumns(10);
		
		JButton btnNewButton = new JButton("Mdificar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(nombre.getText().isEmpty()||costo.getText().isEmpty()||peso.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Debe ingresar el nombre nuevo","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				else {
					if(densidad.getText().isEmpty()||!liquido.isSelected()) {
						
						//public Insumo(Integer id, String nombre, UnidadDeMedida unidadDeMedida, Double costo, Double peso, Boolean esRefrigerado ) 
						Insumo insumoNuevo = new Insumo(ResultadosBusquedaInsumo.insumoGlob.getIdInsumo(),nombre.getText(),listaUnidadesDeMedida[unidadMedida.getSelectedIndex()],Double.parseDouble(costo.getText()),Double.parseDouble(peso.getText()),refrigerado.isSelected());
						Logica.listaInsumosIndustria.add(insumoNuevo);
						Logica.listaInsumosIndustria.remove(ResultadosBusquedaInsumo.insumoGlob);
						}
					else {
						//InsumoLiquido(Integer id, String nombre, UnidadDeMedida unidad, Double costo, Boolean esRefrigerado, Double densidad){
						InsumoLiquido insumoLiquiNuevo = new InsumoLiquido(ResultadosBusquedaInsumo.insumoGlob.getIdInsumo(),nombre.getText(),listaUnidadesDeMedida[unidadMedida.getSelectedIndex()],Double.parseDouble(peso.getText()),refrigerado.isSelected(),Double.parseDouble(densidad.getText()));
						Logica.listaInsumosIndustria.add(insumoLiquiNuevo);
						Logica.listaInsumosIndustria.remove(insumoLiquiNuevo);
						
					}
					JOptionPane.showMessageDialog(null, "Se ha modificado con éxito","¡Exito!", JOptionPane.WARNING_MESSAGE);
				}
				
				
			}
		});
		btnNewButton.setFont(new Font("Dialog", Font.PLAIN, 15));
		btnNewButton.setBounds(582, 536, 97, 25);
		contentPane.add(btnNewButton);
		
		JLabel lblId = new JLabel("Id");
		lblId.setBounds(250, 81, 56, 16);
		contentPane.add(lblId);
		
		
	}
}
