package PantallaGrafo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import App.Bienvenido;
import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.Planta;
import isi.died.tp.dominio.Stock;
import isi.died.tp.estructuras.Arista;
import isi.died.tp.estructuras.GrafoPlanta;
import isi.died.tp.estructuras.Vertice;
import logica.Logica;
import PantallaGrafo.GrafoPanel;

import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JSeparator;

public class EjecutarGrafo extends JFrame {

	public static int pintar;
	public static int reset;
	public static int color=0;
	public static List<List<Vertice<Planta>>> caminos = new ArrayList<List<Vertice<Planta>>>();
	public static List<AristaView> aristasAPintar= new ArrayList<>();
	private  GrafoPlanta grafoDePlantas = new GrafoPlanta();
	public  List<Insumo> listaInsumosIndustria = new ArrayList<Insumo>();
	public  List<Planta> listaPlantasIndustria = new ArrayList<Planta>();
	public List<Stock> listaStocksIndustria = new ArrayList<Stock>();
	
	private JPanel contentPane;
	static GrafoPanel grafopanel = new GrafoPanel();
	private JButton btnSalir;
	private JLabel lblInsumo;
	private JTextField distanciaTotal;
	private JTextField tiempoTotal;
	private JTextField pesoMax;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EjecutarGrafo frame = new EjecutarGrafo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EjecutarGrafo() {
		System.out.println("Grafo cargado satisfactoriamente.");
		grafoDePlantas= Logica.grafoDePlantas; //obtengo el grafo
		listaInsumosIndustria = Logica.listaInsumosIndustria;
		listaPlantasIndustria = Logica.listaPlantasIndustria;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1442, 740);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null); //para centrar
		
		grafopanel.setBackground(Color.LIGHT_GRAY);
		grafopanel.setBounds(263, 13, 1149, 632);
		contentPane.add(grafopanel);
		
		btnSalir = new JButton("Atrás");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				GrafoPanel.borrarGrafo();
				final Bienvenido a= new Bienvenido();
				a.setVisible(true);
				dispose();
			}
		});
		btnSalir.setBounds(1323, 656, 89, 23);
		contentPane.add(btnSalir);
		
		lblInsumo = new JLabel("Insumo:");
		lblInsumo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblInsumo.setBounds(12, 27, 67, 16);
		contentPane.add(lblInsumo);
		
			
		JLabel lblMejorCaminoPor = new JLabel("Mejor camino por:");
		lblMejorCaminoPor.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMejorCaminoPor.setBounds(23, 130, 152, 16);
		contentPane.add(lblMejorCaminoPor);
		
		
		JComboBox listaDesplInsumo = new JComboBox();
		listaDesplInsumo.setBounds(102, 25, 117, 22);
		List<String> nombreInsumos = new ArrayList<>();
		for(Insumo i : Logica.listaInsumosIndustria) nombreInsumos.add(i.get_Nombre_Id());
		listaDesplInsumo.setModel(new DefaultComboBoxModel(nombreInsumos.toArray()));
		contentPane.add(listaDesplInsumo);
		
		
		JButton btnDistancia = new JButton("Distancia");
		btnDistancia.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

			
			if(listaDesplInsumo.getSelectedIndex()==-1) {
			JOptionPane.showMessageDialog(null, "Debe seleccionar un insumo","¡Error!", JOptionPane.WARNING_MESSAGE);
			}
	
			else {
				//insumo seleccionado
				int insumoSelec= listaDesplInsumo.getSelectedIndex();
				Insumo insumo = Logica.listaInsumosIndustria.get(insumoSelec);
				
				pintar=1;	//variable global que uso en grafo panel 
				aristasAPintar = GrafoPanel.verticesToAristasViewInsumo(insumo,true);
				
				//aristasAPintar es una lista global que la uso en la clase GrafoPanel para que me pinte las aristas que quiero			
				//metodo que hay que usar -public List<Vertice<Planta>> buscarPlantasFaltaInsumo(Insumo i)- para obetener la lista de vertices
				// hay que pasar esa lista a arista y de aristas a asristaview para que el metodo que hice funcione.
	
			}
		}

		});
		btnDistancia.setBounds(23, 175, 89, 24);
		contentPane.add(btnDistancia);
		
		JButton btnDuracin = new JButton("Duración");
		btnDuracin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(listaDesplInsumo.getSelectedIndex()==-1) {
					JOptionPane.showMessageDialog(null, "Debe seleccionar un insumo","¡Error!", JOptionPane.WARNING_MESSAGE);
					}
			
					else {
						//insumo seleccionado
						int insumoSelec= listaDesplInsumo.getSelectedIndex();
						Insumo insumo = Logica.listaInsumosIndustria.get(insumoSelec);
						
						pintar=1;	//variable global que uso en grafo panel 
						aristasAPintar = GrafoPanel.verticesToAristasViewInsumo(insumo,false);
						
						//aristasAPintar es una lista global que la uso en la clase GrafoPanel para que me pinte las aristas que quiero			
						//metodo que hay que usar -public List<Vertice<Planta>> buscarPlantasFaltaInsumo(Insumo i)- para obetener la lista de vertices
						// hay que pasar esa lista a arista y de aristas a asristaview para que el metodo que hice funcione.
			
					}
				}
			
		});
		btnDuracin.setBounds(124, 175, 95, 22);
		contentPane.add(btnDuracin);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 95, 221, 2);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(12, 231, 221, 2);
		contentPane.add(separator_1);
		
		JLabel lblCaminoEntrePlantas = new JLabel("Caminos entre plantas:");
		lblCaminoEntrePlantas.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblCaminoEntrePlantas.setBounds(12, 270, 177, 16);
		contentPane.add(lblCaminoEntrePlantas);
		
		JLabel lblPlantaInicio = new JLabel("Planta inicio:");
		lblPlantaInicio.setBounds(12, 314, 79, 16);
		contentPane.add(lblPlantaInicio);
		
		JComboBox listaDesplPlantaInicio = new JComboBox();
		listaDesplPlantaInicio.setBounds(91, 311, 149, 22);
		List<String> plantasInicio = new ArrayList<>();
		for(Planta i : Logica.listaPlantasIndustria) plantasInicio.add(i.get_Nombre_Id());
		listaDesplPlantaInicio.setModel(new DefaultComboBoxModel(plantasInicio.toArray()));
		contentPane.add(listaDesplPlantaInicio);
		
		JLabel lblPlantaFin = new JLabel("Planta fin:");
		lblPlantaFin.setBounds(12, 351, 79, 16);
		contentPane.add(lblPlantaFin);
		
		JComboBox listaDesplPlantaFin = new JComboBox();
		listaDesplPlantaFin.setBounds(91, 348, 149, 22);
		List<String> plantasFin = new ArrayList<>();
		for(Planta i : Logica.listaPlantasIndustria) plantasFin.add(i.get_Nombre_Id());
		listaDesplPlantaFin.setModel(new DefaultComboBoxModel(plantasFin.toArray()));
		contentPane.add(listaDesplPlantaFin);
		
		JComboBox seleccioneCamino = new JComboBox();
		seleccioneCamino.setBounds(133, 467, 100, 22);
		contentPane.add(seleccioneCamino);
		
		JButton btnBuscar = new JButton("Buscar Caminos");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(listaDesplPlantaInicio.getSelectedIndex()==listaDesplPlantaFin.getSelectedIndex()) {
					JOptionPane.showMessageDialog(null, "Debe seleccionar plantas diferentes","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				else {
					//metodo que busque caminos entre esas plantas
					//luego con esos datos cargar la lista deplegable  listaCaminos
					//y recien presionando el boton mostrar, se va a mostrar el camino seleccionado en la lista deplegable listaCaminos
					
					//**********************************************************************************************************************
					//List<List<Vertice<T>>> 	caminos(T v1,T v2)
					//El metodo de agus me devuelve una lista dwe los caminos que hay entre dos nodos, cada posicion corresponde a un camino diferente
					//una vez que obtengo los caminos, le aplico el metodo de german y eso me devuelve arista view de esa manera mando a grafo panel y se hace la magia
					

					int plantaSelec= listaDesplPlantaInicio.getSelectedIndex();
					int PlantaSelec2= listaDesplPlantaFin.getSelectedIndex();
					
					Planta plantaInicio = Logica.listaPlantasIndustria.get(plantaSelec);
					Planta plantaFin = Logica.listaPlantasIndustria.get(PlantaSelec2);
					
					//cada camino deberia pintarse de un color diferente
			    	caminos= Logica.grafoDePlantas.caminos(plantaInicio, plantaFin);
			    	
			    	if(caminos.isEmpty()) JOptionPane.showMessageDialog(null, "No existe un camino entre esas plantas","¡Aviso!", JOptionPane.WARNING_MESSAGE);
					
			    	// esto debe ir en la lista desplegable
			    	/*
			    	int i = caminos.size()-1; //porque empieza en cero, y en la pos caminos.size hay basura
			    	
			    	aristasAPintar= GrafoPanel.verticesToAristasView(caminos.get(1)); //me devuelve los vertices convertidos a aristas view
			    	aristasAPintar= GrafoPanel.verticesToAristasView(caminos.get(2));
			    	aristasAPintar= GrafoPanel.verticesToAristasView(caminos.get(0));
			    	pintar=1;
			    	i--;
			    	if(i<0)i=caminos.size();
			    	
		    		color++;
		    		if(color==7) color=0;
			    	*/
			    	

					
					List<String> cam = new ArrayList<>();
					for (int i=1;i<=caminos.size();i++)
						cam.add("camino"+i);
					seleccioneCamino.setModel(new DefaultComboBoxModel(cam.toArray()));
				}
			}
		});
		btnBuscar.setBounds(46, 393, 143, 25);
		contentPane.add(btnBuscar);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(12, 442, 221, 2);
		contentPane.add(separator_2);
		
		
		JButton btnBuscar_1 = new JButton("Buscar");
		btnBuscar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//cuando seleccione un insumo deberia acrualizarse el grafo fintando los nodos correspondiente
				//se aplica el metodo obteniendo una lista de vertices y luego se aplica
				//la lista obtenida debe almacenarse en private static List<VerticeView> vertices para que el metodo funcione
				//una vez obtenida la lista solo se llama a esa funcionn sin pasarle argumentos restaurarVertices();
			// si no se pintan hacer un repaint();
				

				if(listaDesplInsumo.getSelectedIndex()==-1) {
				JOptionPane.showMessageDialog(null, "Debe seleccionar un insumo","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				else {
					if(Logica.grafoDePlantas.getAristas().isEmpty()) {
						JOptionPane.showMessageDialog(null, "Aun no se cargaron los caminos! Grafo inexistente","¡Error!", JOptionPane.WARNING_MESSAGE);
						}
					else {
						//Antes de cada busqueda reestablece los colores
						for (VerticeView vView : GrafoPanel.getVerticesView()) {
								vView.setColor(Color.WHITE);
								repaint();
							}
						//insumo seleccionado
						int insumoSelec= listaDesplInsumo.getSelectedIndex();
						Insumo insumo = Logica.listaInsumosIndustria.get(insumoSelec);
						
						List<Vertice<Planta>> listaPlantasFaltaInsumo = Logica.grafoDePlantas.buscarPlantasFaltaInsumo(insumo);
						if (listaPlantasFaltaInsumo.isEmpty())
							JOptionPane.showMessageDialog(null, "No existe planta que necesite tal insumo","", JOptionPane.WARNING_MESSAGE);
						else {
							for (Vertice<Planta> planta : Logica.grafoDePlantas.buscarPlantasFaltaInsumo(insumo)) {
								for (VerticeView vView : GrafoPanel.getVerticesView()) {
									if (vView.getId()==planta.getValor().getIdPlanta()) {
										vView.setColor(Color.GREEN);
										repaint();
									}
								}
							}
						}
					}
				}	
			}
		});
		btnBuscar_1.setBounds(79, 57, 97, 25);
		contentPane.add(btnBuscar_1);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				reset=1;
				for (VerticeView vView : GrafoPanel.getVerticesView()) {
					vView.setColor(Color.WHITE);
					repaint();
				}
				distanciaTotal.setText("0.0");
				tiempoTotal.setText("0.0");
				pesoMax.setText("0.0");
				caminos.clear();
				seleccioneCamino.setModel(new DefaultComboBoxModel());
				//reseteo los valores de las banderas paraque se puedan volver a presionar los botones y vuelvan a marcar los caminos y los nodos
				reset=0;
				pintar=0;
			}
		});
		btnReset.setBounds(262, 655, 97, 25);
		contentPane.add(btnReset);
		
		JLabel lblTiempoTotal = new JLabel("Tiempo total:");
		lblTiempoTotal.setBounds(12, 629, 89, 16);
		contentPane.add(lblTiempoTotal);
		
		JLabel lblDistanciaTotal = new JLabel("Distancia total:");
		lblDistanciaTotal.setBounds(12, 591, 89, 16);
		contentPane.add(lblDistanciaTotal);
		
		JLabel lblDuracinTotal = new JLabel("Peso Maximo:");
		lblDuracinTotal.setBounds(12, 664, 89, 16);
		contentPane.add(lblDuracinTotal);
		
		distanciaTotal = new JTextField();
		distanciaTotal.setEditable(false);
		distanciaTotal.setBounds(117, 588, 116, 22);
		contentPane.add(distanciaTotal);
		distanciaTotal.setColumns(10);
		
		tiempoTotal = new JTextField();
		tiempoTotal.setEditable(false);
		tiempoTotal.setBounds(117, 620, 116, 22);
		contentPane.add(tiempoTotal);
		tiempoTotal.setColumns(10);
		
		pesoMax = new JTextField();
		pesoMax.setEditable(false);
		pesoMax.setBounds(117, 657, 116, 22);
		contentPane.add(pesoMax);
		pesoMax.setColumns(10);
		
		JLabel lblSeleccionarCamino = new JLabel("Seleccionar camino:");
		lblSeleccionarCamino.setBounds(12, 471, 130, 16);
		contentPane.add(lblSeleccionarCamino);
		

		
		JButton btnNewButton = new JButton("Mostrar camino");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (!caminos.isEmpty()) {
					aristasAPintar=GrafoPanel.verticesToAristasView(caminos.get(seleccioneCamino.getSelectedIndex()));
					pintar=1;
					color++;
					if(color==7) color=0;
					
					List<Arista<Planta>> listaAristas = new ArrayList<>();
					listaAristas=GrafoPanel.verticesToAristas(caminos.get(seleccioneCamino.getSelectedIndex()));
					
					float distancia=0,tiempo=0;
					Double pesoMaximo = Double.MAX_VALUE;
					for(Arista<Planta> a :	listaAristas) {
						distancia+=a.getDistancia();
						tiempo+=a.getDuracionDelViaje();
						if (a.getPesoMaximoCamino()<pesoMaximo)
							pesoMaximo=a.getPesoMaximoCamino();
					}

					distanciaTotal.setText(Float.toString(distancia));
					tiempoTotal.setText(Float.toString(tiempo));
					pesoMax.setText(Double.toString(pesoMaximo));
				} else
					JOptionPane.showMessageDialog(null, "Debe volver a buscar camino/s entre plantas.","¡Error!", JOptionPane.WARNING_MESSAGE);
				
			}
		});
		btnNewButton.setBounds(58, 528, 141, 25);
		contentPane.add(btnNewButton);
		

		pintar=0;
		grafopanel.inicializarVertices(Logica.grafoDePlantas.getVertices());
		grafopanel.inicializarAristas(Logica.grafoDePlantas.getAristas());
	}
}