package PantallaGrafo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Line2D;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.Planta;
import isi.died.tp.estructuras.Arista;
import isi.died.tp.estructuras.Vertice;
import logica.Logica;

public class GrafoPanel extends JPanel {
	
	private static GrafoPanel panel;
    private JFrame framePadre;
   
    private static List<VerticeView> vertices= new ArrayList<VerticeView>();
    private static List<AristaView> aristas= new ArrayList<AristaView>();
 
    private int xRepintado = 0;    
    private int yRepintado = 0;
    
    private Boolean arrastrando = false;
    private VerticeView aristaSeleccionada = null;
	private static final GrafoPanel INSTANCE = new GrafoPanel();

	
	//Constructor
	
    public GrafoPanel() {    	
        this.framePadre = (JFrame) this.getParent();
        this.vertices = new ArrayList<>();
        this.aristas = new ArrayList<>();

        
        addMouseListener(new MouseAdapter() {		//para capturar el doble click
            public void mouseClicked(MouseEvent event) {
                if (event.getClickCount() == 2 && !event.isConsumed()) {
                    event.consume();
                    VerticeView v = clicEnUnNodo(event.getPoint());
                    if(v != null) {
                    	aristaSeleccionada = v; 
                    	
                    	aristaSeleccionada.setColor(Color.gray);
                    	actualizarVertice(aristaSeleccionada, event.getPoint());
                    }
                    System.out.println("DOBLE CLICK");
                }
            }

            public void mouseReleased(MouseEvent event) {
               System.out.println("mouseReleased: "+event.getPoint());
               if(aristaSeleccionada != null) {
            	   aristaSeleccionada.setColor(Color.WHITE);
            	   actualizarVertice(aristaSeleccionada, event.getPoint());
               }
               aristaSeleccionada = null;
               arrastrando = false;
            }
            

        });

        addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent event) {
                if(aristaSeleccionada != null) {
                	actualizarVertice(aristaSeleccionada ,event.getPoint());
                } 
            }
        });
        
    }

    
    //Getters and Setters
    
    public static List<VerticeView> getVerticesView() {
    	return GrafoPanel.vertices;
    }
    
    public static List<AristaView> getAristasView() {
    	return GrafoPanel.aristas;
    }
    
    public static GrafoPanel getInstance() {
		return INSTANCE;
	}

   
    
    //METODOS
    
    public static void borrarGrafo() { //para que borre el grafo al apretar SALIR, si no pasa que cuando salir y volves a entrar lo vuelve a redibujar encima
	    vertices.clear();
	    aristas.clear();
	   }
    
    protected void paintComponent(Graphics g) {    	
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        dibujarVertices(g2d);
        dibujarAristas(g2d);
       // restaurarColorArista(g2d);//sirve para restaurar el color negro de las aristas 
        if(EjecutarGrafo.pintar==1) {
        	actualizarColorArista(g2d);
        }
        if(EjecutarGrafo.reset==1) {
            restaurarColorArista(g2d);//sirve para restaurar el color negro de las aristas 
            
        }
        
         
    }
    
    public void inicializarVertices(List<Vertice<Planta>> lista) { //Crea la lista de nodos blancos a ser dibujados en la variable "vertices"
		//Logica.GrafoDePlantas() le paso por parametro la lista de plantas del sistema
		if(Logica.cargaAutomatica) {
			int x = 0; 
			int y = 0;
			Color c = Color.WHITE;
			
			for(Vertice<Planta> p : lista) {                  //Vertice<Planta> p : lista){
				if(lista.indexOf(p)==12) { x=0; y=0;}
				
				switch(lista.indexOf(p)) {
					
				case 0:
					x=147;
					y=274;
					break;
				case 1:
					x=916;
					y=259;
					break;
				case 2:
					x=279;
					y=180;
					break;
				case 3:
					x=290;
					y=288;
					break;
				case 4:
					x=370;
					y=432;
					break;
				case 5:
					x=397;
					y=74;
					break;
				case 6:
					x=466;
					y=300;
					break;
				case 7:
					x=567;
					y=60;
					break;
				case 8:
					x=567;
					y=176;
					break;
				case 9:
					x=622;
					y=441;
					break;
				case 10:
					x=755;
					y=128;
					break;
				case 11:
					x=742;
					y=300;
					break;
				default:
					x=x+40;
					y=40;
					break;
				
		}
				VerticeView v = new VerticeView(x,y,c);
				v.setNombre(p.getValor().getNombre()); //
				v.setId(p.getValor().getIdPlanta());
				vertices.add(v);						//

				}
			getInstance().repaint();			//			
			}
		else {
			int y = 0;
			int x = 0;
			int i = 0;
			Color c = Color.WHITE;
			
			for(Vertice<Planta> p : lista) {                  //Vertice<Planta> p : lista){
				i++;
				x +=80; 
				if( i % 2 == 0 ) {
					y = 100;
				} else {
					y = 400;
				}
				
				VerticeView v = new VerticeView(x,y,c);
				v.setNombre(p.getValor().getNombre()); //
				v.setId(p.getValor().getIdPlanta());
				vertices.add(v);						//

			}

			getInstance().repaint();			//
		}
		}
    
	public void inicializarVerticesProfe(List<Vertice<Planta>> lista) { //Crea la lista de nodos blancos a ser dibujados en la variable "vertices"
		//Logica.GrafoDePlantas() le paso por parametro la lista de plantas del sistema
		
			int y = 0;
			int x = 0;
			int i = 0;
			Color c = Color.WHITE;
			
			for(Vertice<Planta> p : lista) {     
				i++;
				x +=80; 
				if( i % 2 == 0 ) {
					y = 100;
				} else {
					y = 400;
				}
				
				VerticeView v = new VerticeView(x,y,c);
				v.setNombre(p.getValor().getNombre()); 
				v.setId(p.getValor().getIdPlanta());
				vertices.add(v);						

			}

			getInstance().repaint();	
			
			
			
		}
	
	public void inicializarAristas(List<Arista<Planta>> lista) { //Crea la lista de caminos negros a dibujar en el atributo "aristas"
		
			for(Arista<Planta> p : lista){
				
				AristaView camino = new AristaView();
				camino.setColor(Color.black);
				camino.setOrigen(getVertice(p.getInicio().getValor()));
				camino.setDestino(getVertice(p.getFin().getValor()));
				camino.setCamino(p);
				//agregue la arista al camino de esa manera puedo sacar la informacion del camino e imprimirla en el grafo				
				aristas.add(camino);
			}
		getInstance().repaint();
		}
		
	public void actualizarCaminos() {
		for (AristaView a : this.aristas) {
			a.actualizar();
		}
		repaint();
	}
	
    private void actualizarVertice(VerticeView v, Point puntoNuevo) {
    	xRepintado = puntoNuevo.x;
         yRepintado = puntoNuevo.y;
         v.setCoordenadaX(xRepintado);
         v.setCoordenadaY(yRepintado);
         v.update();
         repaint();
     }
	
    private VerticeView clicEnUnNodo(Point p) {
        for (VerticeView v : this.vertices) {
            if (v.getNodo().contains(p)) {
                return v;
            }
        }
        return null;
    }
    
	public static VerticeView getVertice(Planta v) {
		for(VerticeView n : vertices) {
			if(n.getId()==v.getIdPlanta()) {
				return n;
			}
		}
		return null;			
	}
	
	private void dibujarFlecha(Graphics2D g2, Point tip, Point tail, Color color)    {
	        double phi;
	        int barb;      
	        phi = Math.toRadians(20);
	        barb = 15;
	        
	        g2.setPaint(color);
	        double dy = tip.y - tail.y;
	        double dx = tip.x - tail.x;
	        double theta = Math.atan2(dy, dx);
	        //System.out.println("theta = " + Math.toDegrees(theta));
	        double x, y, rho = theta + phi;
	        for(int j = 0; j < 2; j++)
	        {
	            x = tip.x - barb * Math.cos(rho);
	            y = tip.y - barb * Math.sin(rho);
	            g2.draw(new Line2D.Double(tip.x, tip.y, x, y));
	            rho = theta - phi;
	        }
	    }
	   
	private void dibujarVertices(Graphics2D g2d) {
	        for (VerticeView v : this.vertices) {
	            g2d.setPaint(Color.DARK_GRAY);
	            g2d.drawString(v.etiqueta(),v.getCoordenadaX()+25,v.getCoordenadaY()+25);
	            g2d.setPaint(v.getColor());
	            g2d.fill(v.getNodo());
	          
	        }
	    }
	    
	private void restaurarColorArista(Graphics2D g2d) {
        for (AristaView a : aristas) {

            g2d.setPaint(Color.BLACK);
            g2d.setStroke ( a.getFormatoLinea());

            g2d.draw(a.getLinea());
            g2d.setFont(new Font("Tahoma", Font.PLAIN, 10));
            dibujarFlecha(g2d,new Point (a.getDestino().getCoordenadaX()+a.getMedio(),a.getDestino().getCoordenadaY()+a.getMedio()),new Point(a.getOrigen().getCoordenadaX()-a.getMedio(),a.getOrigen().getCoordenadaY()-a.getMedio()),Color.BLACK);
			repaint();
			restaurarAristas();
        }
    }
	
	private void actualizarColorArista(Graphics2D g2d) {
	        for (AristaView a : EjecutarGrafo.aristasAPintar) { 
	        	
	        	g2d.setStroke ( a.getFormatoLinea());
	          	List<Color> color= new ArrayList<>();
	           
			    color.add(Color.BLUE);
			    color.add(Color.RED);
			    color.add(Color.CYAN);
			    color.add(Color.YELLOW);
			    color.add(Color.GREEN);
			    color.add(Color.MAGENTA);
			    color.add(Color.ORANGE);
			    color.add(Color.PINK);
			    
			    
	            g2d.setPaint(color.get(EjecutarGrafo.color)); 			
	            g2d.draw(a.getLinea());
	            g2d.setFont(new Font("Tahoma", Font.PLAIN, 10));
	            dibujarFlecha(g2d,new Point (a.getDestino().getCoordenadaX()+a.getMedio(),a.getDestino().getCoordenadaY()+a.getMedio()),new Point(a.getOrigen().getCoordenadaX()-a.getMedio(),a.getOrigen().getCoordenadaY()-a.getMedio()),color.get(EjecutarGrafo.color));
				repaint();
				restaurarAristas();//ESTO ERA LO QUE FALTABAAAA
	        }
	    }
	    
	    
	private void dibujarAristas(Graphics2D g2d) {
	        for (AristaView a : this.aristas) {

	        	Arista<Planta> camino = a.getCamino();
	        	//System.out.println(camino);
	        	
	            g2d.setPaint(a.getColor());
	            g2d.setStroke ( a.getFormatoLinea());
	            int medioX =(a.getOrigen().getCoordenadaX() + a.getDestino().getCoordenadaX()) / 2;
				int medioY = (a.getOrigen().getCoordenadaY() + a.getDestino().getCoordenadaY()) / 2;
				
	            g2d.drawString("Distancia : "+ camino.getDistancia(), medioX + 10, medioY + 10);
				g2d.drawString("Peso maximo: "+camino.getPesoMaximoCamino(), medioX + 10, medioY + 20);
				g2d.drawString("Minutos: "+camino.getDuracionDelViaje(), medioX + 10, medioY + 30);
				
	            g2d.draw(a.getLinea());
	            g2d.setFont(new Font("Tahoma", Font.PLAIN, 10));
	            //lo que esta comentado abajo me dibujaba unas flechas feas
	            //g2d.setPaint(Color.MAGENTA);
	           // Polygon flecha = new Polygon();  
	           // flecha.addPoint(a.getDestino().getCoordenadaX(), a.getDestino().getCoordenadaY()+7);
	           // flecha.addPoint(a.getDestino().getCoordenadaX()+20, a.getDestino().getCoordenadaY()+10);
	          //  flecha.addPoint(a.getDestino().getCoordenadaX(), a.getDestino().getCoordenadaY()+18);
	         //   g2d.fillPolygon(flecha);
	            dibujarFlecha(g2d,new Point (a.getDestino().getCoordenadaX()+a.getMedio(),a.getDestino().getCoordenadaY()+a.getMedio()),new Point(a.getOrigen().getCoordenadaX()-a.getMedio(),a.getOrigen().getCoordenadaY()-a.getMedio()),Color.BLACK);
				repaint();
				restaurarAristas();//ESTO ERA LO QUE FALTABAAAA
	        }
	    }

	public static void actualizarColorVert(VerticeView vert, Color k) {
		vert.setColor(k);
		vert.setColorBase(k);
		vert.update();
	}
	
	public static void actualizarColorArista(AristaView  v, Color k) {
		v.setColor(k);
		v.actualizar();
	}
	
	public static void restaurarAristas() {
		
		for (AristaView a : aristas) {
			actualizarColorArista(a,Color.BLACK);
		}
	}
	
	public static void restaurarVertices() {
			for(VerticeView a : vertices) {
				actualizarColorVert(a,Color.WHITE);
			}
		}
	 
    public void agregar(AristaView arista){
        this.aristas.add(arista);
    }    
    
    public void agregar(VerticeView vert){
        this.vertices.add(vert);
    }
    
    public Dimension getPreferredSize() {
        return new Dimension(900, 400);
    }

    //Convierte vertices en aristas view dependiendo si necesitan un insumo
    public static List<AristaView> verticesToAristasViewInsumo(Insumo i, Boolean opcion){
    	System.out.println("Ejecutando verticesToAristasViewDistancia("+i.get_Nombre_Id()+"):");
    	
    	//Lista provisoria hasta que el metodo de agus funcione
    	List<Arista<Planta>> listaDeAristas = new ArrayList<>();
    	List<AristaView> listaDeAristasView = new ArrayList<>();
    	List<List<Vertice<Planta>>> listaDeVerticesPlanta2 = new ArrayList<>();
    	List<List<Vertice<Planta>>> listaDeVerticesPlanta3 = new ArrayList<>();
    	
    	if(opcion) {
    		listaDeVerticesPlanta2 =Logica.grafoDePlantas.mejorCaminoDistancia(i);
    		for (List<Vertice<Planta>> camino : listaDeVerticesPlanta2) {
        		for (int j=0;j<camino.size()-1;j++)
        			listaDeAristas.add(Logica.grafoDePlantas.buscarArista(camino.get(j), camino.get(j+1)));
        	}
    	} else {
    		listaDeVerticesPlanta3 =Logica.grafoDePlantas.mejorCaminoDuracion(i);
    		for (List<Vertice<Planta>> camino : listaDeVerticesPlanta3) {
        		for (int j=0;j<camino.size()-1;j++)
        			listaDeAristas.add(Logica.grafoDePlantas.buscarArista(camino.get(j), camino.get(j+1)));
        	}
    	}
	
    	System.out.println("\n\nLista de aristas:\n"+listaDeAristas);
    	System.out.println("Convirtiendo a AristasView...");
    	
    	for(Arista<Planta> a : listaDeAristas){
			
			AristaView caminoColor = new AristaView();
			//caminoColor.setColor(Color.BLACK);
			caminoColor.setOrigen(getVertice(a.getInicio().getValor())); //obtiene el verticeView que corresponde el vertice de a.inicio
			caminoColor.setDestino(getVertice(a.getFin().getValor()));
			caminoColor.setCamino(a);
			
			
			//***********************modificacion hecha por belen
	    	//el resultado de este metodo me da instancias nuevas de aristas view y lo que necesito son las instancias ya creadas asique ese es el punto de esta modificacion
	    	//porque sino en el grafo se marcan mal las aristas, se superponen, no se mueves, etc.
	    
			//busco esa aristaView en la lista de aristas del sistema
			for(AristaView viewOriginal :aristas) {
				if(viewOriginal.getOrigen().getId()==a.getInicio().getValor().getIdPlanta() &&
						viewOriginal.getDestino().getId()==a.getFin().getValor().getIdPlanta()) {
					
					listaDeAristasView.add(viewOriginal);
				}
			}
			//agregue la arista al camino de esa manera puedo sacar la informacion del camino e imprimirla en el grafo				
			//listaDeAristasView.add(caminoColor);
		}
    	//getInstance().repaint();
    	
    	System.out.println("\n\nCantidad de aristasView:     "+listaDeAristasView.size());
    	System.out.println("\n\nLista de aristasView:\n"+listaDeAristasView);
    	return listaDeAristasView;
    }
    
    
    //convierte vertices en aristasView
    public static List<AristaView> verticesToAristasView(List<Vertice<Planta>> listaDeVerticesPlanta){  
			
    	List<Vertice<Planta>> subListaDeVerticesPlanta = listaDeVerticesPlanta.subList(0, listaDeVerticesPlanta.size()-1); //es una sub lista de la iriginal pero sin el ultimo elemento
			List<Arista> listaDeAristas = new ArrayList<>();
			List<AristaView> listaDeAristasView = new ArrayList<>();
			
			for(Vertice<Planta> v: subListaDeVerticesPlanta) {
				System.out.println("sublista: "+v);
				for(Arista a : Logica.grafoDePlantas.getAristas()) {
		    		if((a.getInicio().equals(v)) && (a.getFin().equals(listaDeVerticesPlanta.get(listaDeVerticesPlanta.indexOf(v)+1)))){
		    			
		    			listaDeAristas.add(a);
		    		}
		    	}
			}
			System.out.println("\n\nLista de aristas:\n"+listaDeAristas);
			System.out.println("Convirtiendo a AristasView...");
			
			for(Arista<Planta> a : listaDeAristas){
				
				AristaView caminoColor = new AristaView();
				//caminoColor.setColor(Color.BLACK);
				caminoColor.setOrigen(getVertice(a.getInicio().getValor())); //obtiene el verticeView que corresponde el vertice de a.inicio
				caminoColor.setDestino(getVertice(a.getFin().getValor()));
				caminoColor.setCamino(a);
				
				
				//***********************modificacion hecha por belen
		    	//el resultado de este metodo me da instancias nuevas de aristas view y lo que necesito son las instancias ya creadas asique ese es el punto de esta modificacion
		    	//porque sino en el grafo se marcan mal las aristas, se superponen, no se mueves, etc.
		    
				//busco esa aristaView en la lista de aristas del sistema
				for(AristaView viewOriginal :aristas) {
					if(viewOriginal.getOrigen().getId()==a.getInicio().getValor().getIdPlanta() &&
							viewOriginal.getDestino().getId()==a.getFin().getValor().getIdPlanta()) {
						
						listaDeAristasView.add(viewOriginal);
					}
				}
				//agregue la arista al camino de esa manera puedo sacar la informacion del camino e imprimirla en el grafo				
				//listaDeAristasView.add(caminoColor);
			}
			//getInstance().repaint();
			
			System.out.println("\n\nCantidad de aristasView:     "+listaDeAristasView.size());
			System.out.println("\n\nLista de aristasView:\n"+listaDeAristasView);
			return listaDeAristasView;
		}
    
    
    //convierte verties en aristas
    public static List<Arista<Planta>> verticesToAristas(List<Vertice<Planta>> listaDeVerticesPlanta){ 
    	List<Vertice<Planta>> subListaDeVerticesPlanta = listaDeVerticesPlanta.subList(0, listaDeVerticesPlanta.size()-1); //es una sub lista de la original pero sin el ultimo elemento
		List<Arista<Planta>> listaDeAristas = new ArrayList<>();
		List<AristaView> listaDeAristasView = new ArrayList<>();
		
		for(Vertice<Planta> v: subListaDeVerticesPlanta) {
			System.out.println("sublista: "+v);
			for(Arista<Planta> a : Logica.grafoDePlantas.getAristas()) {
	    		if((a.getInicio().equals(v)) && (a.getFin().equals(listaDeVerticesPlanta.get(listaDeVerticesPlanta.indexOf(v)+1)))){
	    			
	    			listaDeAristas.add(a);
	    		}
	    	}
		}
		return listaDeAristas;
    	
    }


}
