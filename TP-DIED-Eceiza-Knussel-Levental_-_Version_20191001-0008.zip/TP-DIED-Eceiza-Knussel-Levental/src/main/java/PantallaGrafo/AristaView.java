package PantallaGrafo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;

//import Ventanas.VerticeView;
import isi.died.tp.dominio.*;

import isi.died.tp.dominio.Planta;
import isi.died.tp.estructuras.Arista;


public class AristaView {

    private VerticeView origen;
    private VerticeView destino;
    private Shape linea;
    private Stroke formatoLinea;
    private Paint color;
    private int medio=VerticeView.RADIO/2;
    
	private Arista<Planta> camino;
	
	
	public Arista<Planta> getCamino() {
		return camino;
	}

	public void setCamino(Arista<Planta> camino) {
		this.camino = camino;
	}
    
    
    public int getMedio() {
		return medio;
	}

	public void setMedio(int medio) {
		this.medio = medio;
	}

	public AristaView (VerticeView inicio, VerticeView fin,Arista<Planta> cam,Color c) {
		this.medio = fin.RADIO /2;
		this.origen = inicio;
		this.destino = fin;
		this.camino = cam;
		this.color = c;
	} 
	
	public AristaView() {
    }

    /**
     * Define que el color de la linea es un degradado (color) 
 desde la coordenada origen de la linea, tomando como base el color origen de la linea
 hacia la coordenada destino de la linea, tomando como base el color destino de la linea
     * @return 
     */
    public Paint getColor() {
        if(this.color==null) this.color = new GradientPaint(origen.getCoordenadaX() + 10,origen.getCoordenadaY() + 10,destino.getColorBase(),destino.getCoordenadaX() + 10, destino.getCoordenadaY() + 10,origen.getColorBase());
        return color;
    }

    public void setColor(Paint color) {
        this.color = color;
    }

    
    public boolean pertenece(Point2D p) {
        return this.linea.contains(p);
    }

    /**
     * Dibuja una linea 2D desde el las coordenadas del nodo origen 
     * hacia las coordenadas del nodo destino
     * @return 
     */
    public Shape getLinea() {
        if(this.linea==null)  this.linea = new Line2D.Double(origen.getCoordenadaX() + 10, origen.getCoordenadaY() + 10, destino.getCoordenadaX() + 10, destino.getCoordenadaY() + 10);
        return linea;
    }

    public void setLinea(Shape linea) {
        this.linea = linea;
    }

    /**
     * Determina el grosor de la linea.
     * @return 
     */
    public Stroke getFormatoLinea() {
        if(this.formatoLinea==null)  this.formatoLinea = new BasicStroke(2.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND);       
        return formatoLinea;
    }

    public void setFormatoLinea(Stroke formatoLinea) {
        this.formatoLinea = formatoLinea;
    }

    public VerticeView getOrigen() {
        return origen;
    }

    public void setOrigen(VerticeView origen) {
        this.origen = origen;
    }

    public VerticeView getDestino() {
        return destino;
    }

    public void setDestino(VerticeView destino) {
        this.destino = destino;
    }

    @Override
    public String toString() {
        return "Arista{" + "origen=" + origen + ", destino=" + destino + ", linea=" + linea + ", formatoLinea=" + formatoLinea + ", gradiente=" + color + '}';
    }

    public void actualizar() {
		this.linea = new Line2D.Double(origen.getCoordenadaX() + medio,
				origen.getCoordenadaY() + medio,
				destino.getCoordenadaX() +medio,
				destino.getCoordenadaY()+ medio);
	}

}
