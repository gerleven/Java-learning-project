package logica;

import java.util.Comparator;

import isi.died.tp.dominio.Insumo;

public class ComparadorStockDescendente implements Comparator<Insumo>{
	public int compare(Insumo a, Insumo b) {
		return b.getCantidadEnStockDePlanta().compareTo(a.getCantidadEnStockDePlanta());
	}
	

}
