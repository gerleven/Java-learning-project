package logica;

import java.util.Comparator;

import isi.died.tp.dominio.Insumo;

public class ComparadorCostoDescendente implements Comparator<Insumo>{
	public int compare(Insumo a, Insumo b) {
		return b.getCosto().compareTo(a.getCosto());
	}
	

}
