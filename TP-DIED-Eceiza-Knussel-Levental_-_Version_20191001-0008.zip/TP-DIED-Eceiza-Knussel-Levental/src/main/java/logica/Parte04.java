package logica;

import java.util.List;

import PantallaGrafo.GrafoPanel;
import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.Planta;
import isi.died.tp.dominio.UnidadDeMedida;
import isi.died.tp.estructuras.GrafoPlanta;
import isi.died.tp.estructuras.Vertice;

public class Parte04 {

	public static void main(String arg[]) {
		System.out.println("Parte04");
		Logica.cargaDeDatos();
		GrafoPlanta grafo = Logica.grafoDePlantas; //??
		Insumo insumo = Logica.listaInsumosIndustria.get(9);
	
	// 1) 
		//Ejecutar desde la interfaz grafica
	
	//2)
		//a)

	System.out.println("Plantas que necesitan "+insumo.get_Nombre_Id()+": ");
	List<Vertice<Planta>> resultado_a = grafo.buscarPlantasFaltaInsumo(insumo);
	if (!resultado_a.isEmpty()) {
		for (Vertice<Planta> lista : resultado_a)
			System.out.println(lista);
	} else 
		System.out.println("Ninguna");
	
		// b
	
	System.out.println("\nMejor camino por distancia: ");
	List<List<Vertice<Planta>>> resultado_b1 = grafo.mejorCaminoDistancia(insumo);
	for (List<Vertice<Planta>> camino : resultado_b1)
		System.out.println(camino);
	System.out.println("\nMejor camino por duracion: ");
	List<List<Vertice<Planta>>> resultado_b2 = grafo.mejorCaminoDuracion(insumo);
	for (List<Vertice<Planta>> camino : resultado_b2)
		System.out.println(camino);
	
	//3)Metodo resuelve para dos plantas cualesquiera, tomo como ejemplo puerto y acopioFinal
	
	System.out.println("\nTodos los caminos entre Puerto y AcopioFinal: ");
	List<List<Vertice<Planta>>> caminos = grafo.caminos(grafo.getPlantaPuerto(), grafo.getPlantaAcopioFinal());
	for (List<Vertice<Planta>> c : caminos)
		System.out.println(c);
	}
}
