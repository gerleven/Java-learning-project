package logica;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import App.Bienvenido;
import isi.died.tp.dominio.Camion;
import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.InsumoLiquido;
import isi.died.tp.dominio.Planta;
import isi.died.tp.dominio.Stock;
import isi.died.tp.dominio.UnidadDeMedida;
import isi.died.tp.estructuras.GrafoPlanta;

public class Logica { 

	//DATOS Y ESTRUCTURAS GLOBALES DEL SISTEMA:
	
	public static List<Insumo> listaInsumosIndustria = new ArrayList<Insumo>();
	public static List<Planta> listaPlantasIndustria = new ArrayList<Planta>();
	public static List<Stock> listaStocksIndustria = new ArrayList<Stock>();

	public static List<Camion> listaCamiones = new ArrayList<Camion>();
	
	public static final GrafoPlanta grafoDePlantas = new GrafoPlanta();
	
	public static Boolean cargaAutomatica = false; //usada para saber si se realizó una carga autotica
	public static Integer tipoDeCarga = 0;
	
	public static Integer ultimoId=0;
	public static Integer getNewId() { //general para cualquier cosa, sea Insumo, Stock o lo que sea
		if(ultimoId==null) ultimoId=0;
		//System.out.println("Id asignado: "+ultimoId);
		return (++(ultimoId));
	}
	
	
//public static void main(String args[]) { //Para testing
		
		//System.out.println("Testing:");
		
		//Logica.cargaDeDatos();
		//Logica.mochilaTest();
	//}get

	public static void mostrarListas() { //Muestra las listas globales (es para testing)
		System.out.println("\n\n\n #########Listas del sistema:");
		if(!Logica.listaInsumosIndustria.isEmpty()) System.out.println("Insumos: "+Logica.listaInsumosIndustria);
		if(!Logica.listaStocksIndustria.isEmpty()) System.out.println("Stocks: "+Logica.listaStocksIndustria);
		if(!Logica.listaPlantasIndustria.isEmpty()) System.out.println("Plantas en lista: "+Logica.listaPlantasIndustria);
		if(!Logica.listaPlantasIndustria.isEmpty()) System.out.println("Plantas en grafo por anchura: "+Logica.grafoDePlantas.recorridoAnchura(Logica.grafoDePlantas.getPlantaPuerto()));
		if(!Logica.listaCamiones.isEmpty()) System.out.println("Camiones: "+Logica.listaCamiones);
		if(!Logica.grafoDePlantas.getAristas().isEmpty()) System.out.println("Aristas en grafo: "+Logica.grafoDePlantas.getAristas());
		if(!Logica.grafoDePlantas.getVertices().isEmpty()) System.out.println("Vertices en grado: "+Logica.grafoDePlantas.getVertices());
	}
	
	/*
	public static void mostrarListasViejo() { //NO ANDA
		if(!Logica.listaInsumosIndustria.isEmpty()
				||!Logica.listaStocksIndustria.isEmpty()
				||!Logica.listaPlantasIndustria.isEmpty() //plantass
				||!Logica.listaCamiones.isEmpty()
				||!Logica.grafoDePlantas.getAristas().isEmpty()
				||!Logica.grafoDePlantas.getVertices().isEmpty()
				) {
			System.out.println("\n\n\n #########Listas del sistema:");
			System.out.println("Insumos: "+Logica.listaInsumosIndustria);
			System.out.println("Stocks: "+Logica.listaStocksIndustria);
			System.out.println("Plantas en lista: "+Logica.listaPlantasIndustria);
			System.out.println("Plantas en grafo por anchura: "+Logica.grafoDePlantas.recorridoAnchura(Logica.grafoDePlantas.getPlantaPuerto()));
			System.out.println("Camiones: "+Logica.listaCamiones);
			System.out.println("Aristas en grafo: "+Logica.grafoDePlantas.getAristas());
			System.out.println("Vertices en grado: "+Logica.grafoDePlantas.getVertices());
		}
		else {
			System.out.println("Nada que mostrar aun...");
		}
	}
	*/
	
public static void resetValores() {
	//if (Logica.tipoDeCarga!=0 || !Logica.listaInsumosIndustria.isEmpty() || !Logica.listaPlantasIndustria.isEmpty() || !Logica.listaStocksIndustria.isEmpty() || !Logica.listaCamiones.isEmpty()) {
		
		mostrarListas();
		Logica.grafoDePlantas.resetGrafo2(); //Agu: en GrafoPlanta agregue un metodo resetGrafo2() que hace lo mismo que el tuyo solo que limpiando las listas originales con .clear() en vez de crear listas nuevas y dejar sin uso las viejas en memoria
		Logica.listaInsumosIndustria.clear();
		Logica.listaStocksIndustria.clear();
		Logica.listaPlantasIndustria.clear();
		Logica.listaCamiones.clear();
		mostrarListas();
		
		Logica.cargaAutomatica=false;
		Logica.tipoDeCarga=0;
		Logica.ultimoId=0;
		
	//} else
		//JOptionPane.showMessageDialog(null, "Aún no se han cargado datos de prueba.","¡Error!", JOptionPane.WARNING_MESSAGE);
}

public static Boolean validarCargaDePrueba() {
	if(cargaAutomatica==true||!Logica.listaPlantasIndustria.isEmpty()||!Logica.grafoDePlantas.getAristas().isEmpty()||!Logica.grafoDePlantas.getVertices().isEmpty()
			||!Logica.listaInsumosIndustria.isEmpty()||!Logica.listaCamiones.isEmpty()||!Logica.listaStocksIndustria.isEmpty()
			) {
		JOptionPane.showMessageDialog(null, "Solo es posible cargar los datos de prueba si no había datos previamente cargados!","¡Error!", JOptionPane.WARNING_MESSAGE);
		return false;
	}
	else {
		return true;
	}
}

public static void mochilaTest() {
	Logica.resetValores();
	if(validarCargaDePrueba()) { //Solo se hará la carga de prueba si la validacion da OK, dará no OK si ya hay otra previamente cargada o algun dato cargado a mano
		cargaAutomatica=true;
		tipoDeCarga=3;
		System.out.println("Cargando datos \"Mochila\".");
		
		//public Insumo(Integer id, String nombre, UnidadDeMedida unidadDeMedida, Double costo, Double peso, Boolean esRefrigerado ) {
																			//costo peso
		Logica.listaInsumosIndustria.add(new Insumo(Logica.getNewId(),"UNO",UnidadDeMedida.KILO, 	6.0, 3.0, false)); 
		Logica.listaInsumosIndustria.add(new Insumo(Logica.getNewId(),"DOS",UnidadDeMedida.M3, 		9.0, 2.0, false));
		Logica.listaInsumosIndustria.add(new Insumo(Logica.getNewId(),"TRES",UnidadDeMedida.PIEZA, 	5.0, 1.0, false));
		Logica.listaInsumosIndustria.add(new Insumo(Logica.getNewId(),"CUATRO",UnidadDeMedida.M3, 	6.0, 2.0, true));		//7
		
		
		
		//public Stock(Integer idStock, Insumo/InsumoLiquido insumo, Integer cantidad, Integer puntoPedido) {
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(0),4,5)); //cantidad faltante dará siempre 1
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(1),5,6));
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(2),6,7));
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(3),7,8));
		
		//public Planta(Integer id, String nombre) {
		if(Logica.listaPlantasIndustria.isEmpty()) {
			Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-Puerto(0)"));						 //0			//Ger_20190808-14545_ cambio id1 por Logica.GetNewId()
			Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-AcopioFinal(1)"));						 //1
		}
		Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"PlantaIntermedia",Logica.listaStocksIndustria));	//la planta intermedia tiene un stock donde falta 1 del UNO 1 del DOS 1 del TRES y 1 del CUATRO
		System.out.println("lista de plantas cargadas en mochila: "+Logica.listaPlantasIndustria);
		
		for(Planta p: Logica.listaPlantasIndustria) {
			System.out.println("Agregando la planta "+p+" al grafo");
			Logica.grafoDePlantas.addNodo(p);
		}
		System.out.println("Vertices post carga: "+Logica.grafoDePlantas.getVertices());
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(0), Logica.listaPlantasIndustria.get(2),1,50.0,60,100.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(2), Logica.listaPlantasIndustria.get(1),1,50.0,60,100.0);
		
		//public Camion(				idCamion,  marca, modelo, dominio, anio,  costoPorKm,aptoLiquidos,capacidad) {
		Double capacidad = 4.0;
		Logica.listaCamiones.add(new Camion(Logica.getNewId(),"MOCHILA","BAG",2,		2019,50.0,true,capacidad));
		
		System.out.println("Se cargaron los datos de prueba \"Mochila\".\n");
		JOptionPane.showMessageDialog(null, "Se cargaron los datos de prueba \n     \"Mochila\" para Mejor Envio","¡Exito!", JOptionPane.WARNING_MESSAGE);
	}
}

//public static void ejemploGrafo() {
public static void cargaDeDatosMinimal() {
	Logica.resetValores();
	//Carga de datos minimalista!
	
	
	if(validarCargaDePrueba()) { //Solo se hará la carga de prueba si la validacion da OK, dará no OK si ya hay otra previamente cargada o algun dato cargado a mano
	System.out.println("Cargando datos \"Minimal\".");
		cargaAutomatica=true;
		tipoDeCarga=2;
		
		//INSUMOS
		//public InsumoLiquido(Integer id, String nombre, UnidadDeMedida unidad, Double costo, Boolean esRefrigerado, Double densidad){
		//public InsumoLiquido(Integer id, String nombre, Double costo, Boolean esRefrigerado, Double densidad){
		Logica.listaInsumosIndustria.add(new InsumoLiquido(Logica.getNewId(),"NITROGENO LIQUIDO", 550.0, true, 20.0));
		
		
		//public Insumo(Integer id, String nombre, UnidadDeMedida unidadDeMedida, Double costo, Double peso, Boolean esRefrigerado ) {
		Logica.listaInsumosIndustria.add(new Insumo(Logica.getNewId(),"MADERA",UnidadDeMedida.KILO, 150.0, 100.0,false)); 
		Logica.listaInsumosIndustria.add(new Insumo(Logica.getNewId(),"HIELO",UnidadDeMedida.M3, 150.0, 100.0,true));
		
		
		//STOCKS
		//public Stock(Integer idStock, Insumo/InsumoLiquido insumo, Integer cantidad, Integer puntoPedido) {
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(0),300,310));//Nitrogeno liquido faltan 10 L
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(1),300,310));//MADERA faltan 10
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(2),300,310));//MADERA faltan 10
		
		//public Planta(Integer id, String nombre) {
		if(Logica.listaPlantasIndustria.isEmpty()) {
			Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-Puerto(0)",new ArrayList<Stock>()));
			Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-AcopioFinal(1)",new ArrayList<Stock>()));
		}
		Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-2",Logica.listaStocksIndustria.subList(0, 2))); //A la Planta-2 le faltan 10L de Nitrogeno liquido y 10 de Madera
		Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-3",Logica.listaStocksIndustria.subList(1, 3))); //A la Planta-3 le faltan 10 de Madera y 10 de HIELO
		
		
		//CAMINOS
		for(Planta p: Logica.listaPlantasIndustria) {
			Logica.grafoDePlantas.addNodo(p);
		}
		
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(0), Logica.listaPlantasIndustria.get(2),1,50.0,60,100.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(2), Logica.listaPlantasIndustria.get(1),1,50.0,60,100.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(0), Logica.listaPlantasIndustria.get(3),1,50.0,60,100.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(3), Logica.listaPlantasIndustria.get(1),1,50.0,60,100.0);
		
		//Logica.grafoDePlantas.setPlantaPuerto();
		//Logica.grafoDePlantas.setPlantaAcopioFinal();
		
		//CAMIONES
		//public Camion(idCamion,  marca, modelo, dominio, anio,  costoPorKm,aptoLiquidos,capacidad) {
		Logica.listaCamiones.add(new Camion(Logica.getNewId(),"Renault","TYJTY55",2,2019,50.0,true,75450.0));
		
		System.out.println("Se cargaron los datos de prueba \"Minimal\".\n");
		JOptionPane.showMessageDialog(null, "Se cargaron los datos de prueba \"Minimal\".","¡Exito!", JOptionPane.WARNING_MESSAGE);
	}
	
}
	public static void cargaDeDatos() {
		Logica.resetValores();
		if(validarCargaDePrueba()) { //Solo se hará la carga de prueba si la validacion da OK, dará no OK si ya hay otra previamente cargada o algun dato cargado a mano
		
			System.out.println("Cargando datos de prueba \"EjemploGrafo\".");
		cargaAutomatica=true;
		tipoDeCarga=1;
		
		//INSUMOS
		//public InsumoLiquido(Integer id, String nombre, UnidadDeMedida unidad, Double costo, Boolean esRefrigerado, Double densidad){
		Logica.listaInsumosIndustria.add(new InsumoLiquido(Logica.getNewId(),"NITROGENO LIQUIDO",UnidadDeMedida.LITRO, 550.0, true, 20.3));
		Logica.listaInsumosIndustria.add(new InsumoLiquido(Logica.getNewId(),"AGUA MINERAL",UnidadDeMedida.LITRO, 50.0, false, 1.0));
		Logica.listaInsumosIndustria.add(new InsumoLiquido(Logica.getNewId(),"GASEOSA NARAMPOL",UnidadDeMedida.LITRO, 70.0, true, 1.3));
		Logica.listaInsumosIndustria.add(new InsumoLiquido(Logica.getNewId(),"MERCURIO",UnidadDeMedida.LITRO, 770.0, false, 50.5));
		
		
		
		//public Insumo(Integer id, String nombre, UnidadDeMedida unidadDeMedida, Double costo, Double peso, Boolean esRefrigerado ) {
		Logica.listaInsumosIndustria.add(new Insumo(Logica.getNewId(),"MADERA",UnidadDeMedida.KILO, 150.0, 100.0,false)); 
		Logica.listaInsumosIndustria.add(new Insumo(Logica.getNewId(),"ARENA",UnidadDeMedida.M3, 250.0, 200.0,false));
		Logica.listaInsumosIndustria.add(new Insumo(Logica.getNewId(),"PISTON",UnidadDeMedida.PIEZA, 750.5,3.0,false));
		Logica.listaInsumosIndustria.add(new Insumo(Logica.getNewId(),"HIELO",UnidadDeMedida.M3, 50.5,1.0,true));		//7
		Logica.listaInsumosIndustria.add(new Insumo(Logica.getNewId(),"TELA",UnidadDeMedida.M2, 78.5,0.2,false));
		Logica.listaInsumosIndustria.add(new Insumo(Logica.getNewId(),"LEVADURA",UnidadDeMedida.GRAMO, 0.5,0.1,false));
		Logica.listaInsumosIndustria.add(new Insumo(Logica.getNewId(),"ZABORA",UnidadDeMedida.METRO, 10.5, 0.5,false));
		
		
		//STOCKS
		//public Stock(Integer idStock, Insumo/InsumoLiquido insumo, Integer cantidad, Integer puntoPedido) {

		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(0),435,300));//Madera 
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(1),245,200));//Arena (necesita)
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(2),175,350));//Gaseosa naranpol (necesita)	
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(3),473,500));//Hielo 	
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(4),355,300));//Nitrogeno liquido
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(5),265,300));//Levadura (necesita)
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(6),246,500));//Zabora (necesita)
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(7),456,400));//Piston (necesita)
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(8),279,300));//Tela (necesita)
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(9),149,200));//Agua mineral
		Logica.listaStocksIndustria.add(new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(10),357,600));//Mercurio (necesita)
		
		//PLANTAS
		//public Planta(Integer id, String nombre) {
		if(Logica.listaPlantasIndustria.isEmpty()) {
			Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-Puerto(0)"));						 //0			//Ger_20190808-14545_ cambio id1 por Logica.GetNewId()
			Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-AcopioFinal(1)"));						 //1
		}
		Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-2",Logica.listaStocksIndustria.subList(0, 3)));	 //2 //subList(a,c) -> incluye el a, b pero excluye el c. 
		Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-3",Logica.listaStocksIndustria.subList(1, 5)));  //3
		Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-4",Logica.listaStocksIndustria.subList(4, 6)));  //4
		Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-5",Logica.listaStocksIndustria.subList(3, 6)));  //5
		Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-6",Logica.listaStocksIndustria.subList(5, 7)));  //6
		Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-7",Logica.listaStocksIndustria.subList(4, 6)));  //7
		Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-8",Logica.listaStocksIndustria.subList(6, 8)));  //8
		Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-9",Logica.listaStocksIndustria.subList(7, 9)));  //9
		Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-10",Logica.listaStocksIndustria.subList(8, 11))); //10
		Logica.listaPlantasIndustria.add(new Planta(Logica.getNewId(),"Planta-11",Logica.listaStocksIndustria.subList(9, 11))); //11  //20190817Ger cambie el (8,10) por (8,11) para que tome el stock numero 10
		
		
		//CAMINOS
		//private void conectar(Vertice<T> nodo1,Vertice<T> nodo2,Number valor,Double dist,Integer durViaje,Double pesoMax){
		for(Planta p: Logica.listaPlantasIndustria) {
			Logica.grafoDePlantas.addNodo(p);
		}
		
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(0), Logica.listaPlantasIndustria.get(2),1,50.0,60,100.0);// Agu-20190808-1645-cambiamos los pesosMax
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(0), Logica.listaPlantasIndustria.get(3),2,35.0,40,50.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(0), Logica.listaPlantasIndustria.get(4),3,30.0,35,75.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(2), Logica.listaPlantasIndustria.get(5),4,80.0,90,230.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(2), Logica.listaPlantasIndustria.get(11),5,120.0,150,200.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(3), Logica.listaPlantasIndustria.get(6),6,60.0,40,150.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(4), Logica.listaPlantasIndustria.get(9),7,100.0,70,250.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(5), Logica.listaPlantasIndustria.get(7),8,47.0,25,60.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(5), Logica.listaPlantasIndustria.get(8),9,59.0,70,50.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(6), Logica.listaPlantasIndustria.get(9),10,34.0,30,45.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(7), Logica.listaPlantasIndustria.get(10),11,97.0,80,80.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(8), Logica.listaPlantasIndustria.get(10),12,56.0,40,90.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(9), Logica.listaPlantasIndustria.get(11),13,19.0,25,120.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(10), Logica.listaPlantasIndustria.get(1),14,75.0,75,100.0);
		Logica.grafoDePlantas.conectar(Logica.listaPlantasIndustria.get(11), Logica.listaPlantasIndustria.get(1),15,60.0,70,300.0);
		
		//Logica.grafoDePlantas.setPlantaPuerto(); //ya lo agregue ne el constructor con un if, no hace falta (Ger 20190831-22:21 hs
		//Logica.grafoDePlantas.setPlantaAcopioFinal();
		
		
		//CAMIONES
		//public Camion(idCamion,  marca, modelo, dominio, anio,  costoPorKm,aptoLiquidos,capacidad) {
		Logica.listaCamiones.add(new Camion(Logica.getNewId(),"Renault","TYJTY55",2,2019,50.0,true,75450.0));
		Logica.listaCamiones.add(new Camion(Logica.getNewId(),"Iveco","ASX"		,3,2018,70.0,true,50006990.0));
		Logica.listaCamiones.add(new Camion(Logica.getNewId(),"Mercedes","20AER",4,2019,66.0,true,7810000.0));
		Logica.listaCamiones.add(new Camion(Logica.getNewId(),"Ford","58ADE"	,2,2017,88.0,true,701000.0));
		Logica.listaCamiones.add(new Camion(Logica.getNewId(),"Scnia","QWD6"	,7,2018,54.0,false,9000.0));
		Logica.listaCamiones.add(new Camion(Logica.getNewId(),"Renault","THRT55",8,2016,20.0,false,8000.0));
		Logica.listaCamiones.add(new Camion(Logica.getNewId(),"Ford","UTY63"	,7,2019,60.0,false,20000.0));
		Logica.listaCamiones.add(new Camion(Logica.getNewId(),"Iveco","HHGT57"	,8,2019,70.0,true,80000.0));
		

		System.out.println("Se cargaron los datos de prueba \"EjemploGrafo\".\n");
		JOptionPane.showMessageDialog(null, "Se cargaron los datos de prueba \"EjemploGrafo\".","¡Exito!", JOptionPane.WARNING_MESSAGE);
		}
	}
	
	

}
