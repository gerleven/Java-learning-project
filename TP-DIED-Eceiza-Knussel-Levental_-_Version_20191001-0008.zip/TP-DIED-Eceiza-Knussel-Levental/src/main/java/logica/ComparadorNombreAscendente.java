package logica;

import java.util.Comparator;

import isi.died.tp.dominio.Insumo; //borrar esto?

public class ComparadorNombreAscendente implements Comparator<Insumo>{
	public int compare(Insumo a, Insumo b) {
		return a.getNombre().compareTo(b.getNombre());
	}
	

}