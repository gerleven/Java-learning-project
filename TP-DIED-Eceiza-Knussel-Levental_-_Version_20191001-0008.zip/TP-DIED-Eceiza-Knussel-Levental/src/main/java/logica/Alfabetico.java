package logica;

public class Alfabetico implements Comparable<Alfabetico>{

	private String nombre;
	//private Integer id;
	
	public Alfabetico(String n) {
		this.nombre=n;
	}
	
	
	public String getNombre() {
		return this.nombre;
	}
	
	public int compareTo(Alfabetico otro) {
		return this.nombre.compareTo(otro.nombre);
	}
	
	public String toString() {
		return "("+this.nombre+")";
	}
}
