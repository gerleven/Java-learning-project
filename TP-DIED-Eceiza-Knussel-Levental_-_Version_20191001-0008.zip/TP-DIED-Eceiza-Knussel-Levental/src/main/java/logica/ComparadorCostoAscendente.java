package logica;

import java.util.Comparator;

import isi.died.tp.dominio.Insumo;

public class ComparadorCostoAscendente implements Comparator<Insumo>{
	public int compare(Insumo a, Insumo b) {
		return a.getCosto().compareTo(b.getCosto());
	}
	

}
