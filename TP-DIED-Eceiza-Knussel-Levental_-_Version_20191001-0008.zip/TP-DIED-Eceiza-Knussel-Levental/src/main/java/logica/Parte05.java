package logica;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import isi.died.tp.dominio.Camion;
import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.InsumoLiquido;
import isi.died.tp.dominio.Planta;
import isi.died.tp.estructuras.InsumoPesoValor;
import isi.died.tp.estructuras.InsumoPesoValorInteger;
import isi.died.tp.estructuras.Mochila;
import isi.died.tp.estructuras.Vertice;

public class Parte05 {
	
	public static void main(String arg[]) {
		
		System.out.println("Parte05");
		Logica.cargaDeDatos();
		
		//unoydos();
		
		//3 
		//tres();
		Camion camionSeleccionado = Logica.listaCamiones.get(3);
		MejorEnvio(camionSeleccionado);
		
	}
	
	public static void tres() {

		//3-a
	//El sistema debe mostrar una lista de todos los insumos faltantes en cada una de las plantas, y la cantidad del mismo
	//Creo que lo plantie mal, porque yo devuelvo por cada planta que insumo y que cantidad 
	System.out.println("\n###### Lista de insumos faltantes:\n"+Parte05.ipvFaltantesEnIndustria()+"\n\n");
	
	
	
	//System.out.println("Chicos: Creo que aca ne vez de la cantidad en unidades de stock tendria que ser la cantidad en Kg faltante");
	//System.out.println("Que pasa si la planta 2 nececita 200Kg de ARENA y la planta 7 necesita 350Kg de ARENA? seria un insumoFalntanteEnPlantas de Arena con peso 550Kh, no?? porque segun el audio del profe suponemos que el camion no tiene caminos si no que va a llegar a todas las plantas por lo tanto necesita saber cual de los insumos faltantes debe llevar");
		//3-b
		//El sistema debe mostrar todos los camiones disponibles e información del camión
	System.out.println("\n###### Lista de camiones disponibles:");
	System.out.println("return: "+Logica.listaCamiones);
	
	//System.out.println("\nFin de Lista de camiones disponibles:");
	
		//3-c
	/*
	 * El usuario puede seleccionar uno de estos camiones y presionar un botón generar solución. La solución le va a indicar 
	 * cual o cuales son los insumos que conviene que el camión transporte, sujeto a el peso máximo que puede transportar el 
	 * camión y buscando como objetivo maximizar el valor de los insumos transportados (el valor de un insumo transportado se 
	 * mide a través de su costo). Debe usar programación dinámica o back tracking para resolver este problema
	 */
	
	System.out.println("\n###### Generar solucion:");
	System.out.println("Elija un camion y presiones \"Generar solucion\" para saber cual o cuales de los InsumosFaltanteEnPlantas debe cargar al camion");
	Camion camionSeleccionado = Logica.listaCamiones.get(3); //camiones.add(new Camion(Logica.getNewId(),"Ford","58ADE"	,2,2017,88.0,true,701000.0));
	System.out.println("\n\n\n\nCamion seleccionado: "+camionSeleccionado.getDominioId()+(camionSeleccionado.getAptoLiquidos()?"aptoliqudos":"noaptoliquidos"));
	MejorEnvio(camionSeleccionado);
	System.out.println("\n\n\n\nCamion seleccionado: "+camionSeleccionado.getDominioId()+(camionSeleccionado.getAptoLiquidos()?"aptoliqudos":"noaptoliquidos"));
	camionSeleccionado.setAptoLiquidos(false);
	MejorEnvio(camionSeleccionado);
	
	//System.out.println("\nFin de Generar solucion:");
	}
	public static void unoydos() {
		//1
				//Flujo Maximo
				
				Double resultado_1 = Logica.grafoDePlantas.calcularFlujoMaximo();
				System.out.println("\n###### Flujo Maximo:"+resultado_1);
				
				//2
				//Pagerank
				System.out.println("\n###### PageRank:");
				List<Vertice<Planta>> resultado_2 = Logica.grafoDePlantas.ordenarPorPageRank();
				int i=1;
				for(Vertice<Planta> v : resultado_2) {
					System.out.println(i+" - "+v);
					i++;
				}
	}
	
	public static List<InsumoPesoValorInteger> ipvFaltantesEnIndustria(){ //Devuelve la lista de IPV de la industria entera que necesitan ser abastecidos en al menos alguna planta
		List<InsumoPesoValorInteger> ipvFaltantesEnIndustria = new ArrayList<>();

		//obtiene la lista de todas las plantas del grafo
		System.out.println("Plantas en logica: "+Logica.listaPlantasIndustria);
		System.out.println("Lista de plantas en el gafo: "+Logica.grafoDePlantas.recorridoProfundidad(Logica.grafoDePlantas.getPlantaPuerto()));
		System.out.println("planta puerto: "+Logica.grafoDePlantas.getPlantaPuerto());
		for (Planta planta: Logica.grafoDePlantas.recorridoAnchura(Logica.grafoDePlantas.getPlantaPuerto())) {
			
			System.out.println("planta in: "+planta);
			for(InsumoPesoValorInteger ipv : planta.ipvIntegerFaltantesEnPlanta()) { //obtiene la lista de ifp de cada planta, donde ifp tiene como atributo el insumo flatante y su cantidad faltante en pesoKg
				if(ipvFaltantesEnIndustria.isEmpty()) { //si es el primero (osea que la lista esta vacia) lo agrega directamente, si no deberia buscarlo y actualizar el acumulado
					ipvFaltantesEnIndustria.add(ipv);
				}
				else {
					List<InsumoPesoValorInteger> lista = ipvFaltantesEnIndustria.stream().distinct().filter((obj)->obj.getIdDelInsumo()==ipv.getIdDelInsumo()).collect(Collectors.toList());
					if(lista.isEmpty()) { //si el insumo estaba ya presente aparecerá en esta lista de 1 elemento
						ipvFaltantesEnIndustria.add(ipv); //Si el insumo no estaba presente en el resultado se lo agrega directamente, si no hubise tenia que actualiar sus valores de peso y valor
					}
					else { //El insumo ya esta presente en la lista resultado entonces actualizamos el valor acumulado de peso y valor-costo
						lista.get(0).sumarPesoFaltante(ipv.getPesoFaltante());
						lista.get(0).sumarValorFaltante(ipv.getValorFaltante());
					}
				}
				
			}
			System.out.println("planta out: "+planta);
		}
			System.out.println("Testing resultado final de insumosFaltantesCantidad() antes del return:\n"+ipvFaltantesEnIndustria);
		return ipvFaltantesEnIndustria;
	}
	
	public static List<InsumoPesoValorInteger> MejorEnvio(Camion camion){
		List<InsumoPesoValorInteger> ipvFaltantesEnIndustria;

		System.out.println(camion.getAptoLiquidos()?"Camion apto para liquidos":"camion no apto para liquidos");
		
		if(!camion.getAptoLiquidos()) {
			System.out.println("No se podran llevar insumos liquidos en este camion");
			ipvFaltantesEnIndustria = Parte05.ipvFaltantesEnIndustria().stream().filter(i->!(i.getInsumo() instanceof InsumoLiquido)).collect(Collectors.toList());
		}
		else {
			System.out.println("Si se podran llevar insumos liquidos en este camion");
			ipvFaltantesEnIndustria = Parte05.ipvFaltantesEnIndustria();
		}
		System.out.println("Insumos a abastecer"+ipvFaltantesEnIndustria+"\n\n\n");
		
		//Terminar aca el de la mochila!
		
		int pesoMaximo = (int) (camion.getCapacidad()-camion.getCapacidad()%1);
		System.out.println("camion: "+camion+"\n Peso maximo de carga: "+pesoMaximo);
		int pesos[] = pesosInteger(ipvFaltantesEnIndustria);
		int valores[] = valoresInteger(ipvFaltantesEnIndustria);
		
		
		boolean[] resultado = Mochila.mejorEnvio(pesos, valores, pesoMaximo);
		
		for(Boolean b : resultado) {System.out.println(b?" si ":" no ");} //Testing
		
		//teniendo la lista de Boolean de Mochila y la lista de ipvFaltantesEnIndustria armamos la lista resultado de los insumos faltantes a llevar
		List<InsumoPesoValorInteger> insumosALlevar = new ArrayList<>();
		int index=0;
		for(Boolean b : resultado) {
			if(b) {
				insumosALlevar.add(ipvFaltantesEnIndustria.get(index));
			}
			index++;
		}
		System.out.println("\nSu mejor combinacion de envio es:\n"+insumosALlevar);
		return insumosALlevar;
	}
	
	public static int[] pesosInteger(List<InsumoPesoValorInteger> ipvFaltantesEnIndustria) {
		int pesosEjemplo[] = {3,2,1,2};
		int pesos[];
		pesos = new int[ipvFaltantesEnIndustria.size()];
		
		for (InsumoPesoValorInteger i : ipvFaltantesEnIndustria) {
			//ipvFaltantesEnIndustria.indexOf(i)
			pesos[ipvFaltantesEnIndustria.indexOf(i)] = i.getPesoFaltante();
		}
		//for (int i : pesos){System.out.println("Testing lista integer de pesos: "+i);}
		return pesos;
	}

	public static int[] valoresInteger(List<InsumoPesoValorInteger> ipvFaltantesEnIndustria) {
		int valoresEjemplo[] = {6,9,5,6};
		int valores[];
		valores = new int[ipvFaltantesEnIndustria.size()];
		
		
		for (InsumoPesoValorInteger i : ipvFaltantesEnIndustria) {
			//ipvFaltantesEnIndustria.indexOf(i)
			valores[ipvFaltantesEnIndustria.indexOf(i)] = i.getValorFaltante();
		}
		//for (int i : valores){System.out.println("Testing lista integer de valores: "+i);}
		return valores;
	}

}
