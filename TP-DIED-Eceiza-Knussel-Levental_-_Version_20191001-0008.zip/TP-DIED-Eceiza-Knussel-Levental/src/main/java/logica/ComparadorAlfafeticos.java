package logica;

import java.util.Comparator;

public class ComparadorAlfafeticos implements Comparator<Alfabetico>{

	public int compare(Alfabetico a, Alfabetico b) {
		return a.getNombre().compareTo(b.getNombre());
	}
}
