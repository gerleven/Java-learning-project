package logica;

import java.util.Comparator;

import isi.died.tp.dominio.Insumo;

public class ComparadorStockAscendente implements Comparator<Insumo>{
	public int compare(Insumo a, Insumo b) {
		return a.getCantidadEnStockDePlanta().compareTo(b.getCantidadEnStockDePlanta());
	}
	

}
