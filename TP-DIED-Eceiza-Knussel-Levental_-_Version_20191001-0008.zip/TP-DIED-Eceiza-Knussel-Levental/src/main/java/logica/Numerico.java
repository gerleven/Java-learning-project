package logica;

public class Numerico implements Comparable<Numerico>{
	
	private Integer valor;
	
	public Numerico(Integer n) {
		this.valor = n;
	}
	
	public int compareTo(Numerico otro){
		return this.valor-otro.valor;
	}
	
	public String toString() {
		return "("+String.valueOf(this.valor)+")";
	}

}
