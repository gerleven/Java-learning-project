package logica;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.JOptionPane;

import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.UnidadDeMedida;
import isi.died.tp.estructuras.ArbolBinarioBusqueda;

public class Parte03 {
public static void main(String args[]) { //Para testing
		
		System.out.println("Testing:");
		
		//Parte03
		Logica.cargaDeDatos(); 		//Ger-20190808-0346 agregue la carga de datos que no estaba
		//Buscar inusmo por nombre (si ingresa un nombre lo encuentra y si no ingresa ningun nombre muestra toda la lista ascendenetemente (o descendentemente)
		System.out.println("\nbusquedaPorNombreAsc(null) trae toda la lista de Insumos y la ardena alfabeticamente"); //Ger20190808-0252
		Parte03.busquedaPorNombreAsc(null);
		Parte03.busquedaPorNombreDes(null); 					//Ger-20190808-0358 agregue el Des(null) que no estaba
		
		System.out.println("\nBuscar el insumo HIELO:");
		Parte03.busquedaPorNombreAsc("HIELO");
		
		//buscar insumo por costo(min max)
		System.out.println("\nBusqueda por costo(min,mix) Asc");
		Parte03.busquedaPorCostoAsc(50.0, 250.0);
		System.out.println("Fin Busqueda por costo(min,mix) Asc:");
		
		System.out.println("\nBusqueda por costo(min,mix) Des");
		Parte03.busquedaPorCostoDes(50.0, 250.0);
		System.out.println("Fin Busqueda por costo(min,mix) Des");
		
		
		//buscar insumo por stock(min max)
		
		System.out.println("\nBusqueda por stock(min,mix) Asc");
		Parte03.busquedaPorStockAsc(50.0, 250.0);
		System.out.println("Fin Busqueda por costo(min,mix) Asc:");
		
		System.out.println("\nBusqueda por stock Des");			//Ger-20190808-2053		cambio "costo" por "stock"
		Parte03.busquedaPorStockDes(50.0, 250.0);
		System.out.println("Fin Busqueda por costo Des");
		
		
		//Logica.arbolTest();
	}


//METODOS
	
	
	public static ArrayList<Insumo> busquedaPorNombreAsc(String nombre) {
		ArrayList<Insumo> resul = new ArrayList<Insumo>();
		List<Insumo> listaInsumo = new ArrayList<>();
		//public Insumo(Integer id, String nombre, UnidadDeMedida unidadDeMedida, Double costo, Double peso, Boolean esRefrigerado ) {
		listaInsumo.add(new Insumo(Logica.getNewId(),"MADERA",UnidadDeMedida.KILO, 150.0, 100.0,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"ARENA",UnidadDeMedida.M3, 250.0, 200.0,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"PISTON",UnidadDeMedida.PIEZA, 750.5, 3.0,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"HIELO",UnidadDeMedida.M3, 50.5,1.0,true));
		listaInsumo.add(new Insumo(Logica.getNewId(),"TELA",UnidadDeMedida.M2, 78.5,0.2,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"LEVADURA",UnidadDeMedida.GRAMO, 0.5,0.1,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"ZABORA",UnidadDeMedida.M3, 10.5,0.5,false));
	
		
		ArbolBinarioBusqueda<Insumo> a = new ArbolBinarioBusqueda<Insumo>(); 
		ComparadorNombreAscendente comp = new ComparadorNombreAscendente();		//usa el comparator As-cendente
		for(Insumo i : Logica.listaInsumosIndustria)	a.agregarPorCriterio(i, comp);							//Ger-20190808-0340  cambio la lista provisoria de insumos por la lista del sistema
		List<Insumo> insumosOrdenados = a.inOrden();
		//Respuesta:
		if(nombre==null) {
			System.out.println(insumosOrdenados); //Si no ingreso ningun nombre muestra todos los insumos ordenados por nombre Ascendentemente
			resul.addAll(insumosOrdenados);
		}
		else {
			List<Insumo> insumoEncontrado = insumosOrdenados.stream().filter(i->i.getNombre().compareTo(nombre)==0).collect(Collectors.toList());			//Ger-20190808-0355_ saque el .get(0) porque en vaso de no encontrar el insumo daba puntero a null, ahora primero verifica
			if(!insumoEncontrado.isEmpty()) { 
				System.out.println(insumoEncontrado.get(0));
				resul.addAll(insumoEncontrado);
			}
			else { 
//				System.out.println("No se encontro el insumo \""+nombre+"\".");
			JOptionPane.showMessageDialog(null, "No se encontró el insumo","¡Error!", JOptionPane.WARNING_MESSAGE);
			}
		}
		
		return resul;
	}
	
	
public static ArrayList<Insumo> busquedaPorNombreDes(String nombre) {
	ArrayList<Insumo> resul = new ArrayList<Insumo>();
	
	
		List<Insumo> listaInsumo = new ArrayList<>();
		//public Insumo(Integer id, String nombre, UnidadDeMedida unidadDeMedida, Double costo, Double peso, Boolean esRefrigerado ) {
		listaInsumo.add(new Insumo(Logica.getNewId(),"MADERA",UnidadDeMedida.KILO, 150.0, 100.0,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"ARENA",UnidadDeMedida.M3, 250.0, 200.0,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"PISTON",UnidadDeMedida.PIEZA, 750.5, 3.0,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"HIELO",UnidadDeMedida.M3, 50.5,1.0,true));
		listaInsumo.add(new Insumo(Logica.getNewId(),"TELA",UnidadDeMedida.M2, 78.5,0.2,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"LEVADURA",UnidadDeMedida.GRAMO, 0.5,0.1,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"ZABORA",UnidadDeMedida.M3, 10.5,0.5,false));

		
		ArbolBinarioBusqueda<Insumo> a = new ArbolBinarioBusqueda<Insumo>(); 
		ComparadorNombreDescendente comp = new ComparadorNombreDescendente();		//usa el comparator As-cendente
		for(Insumo i : Logica.listaInsumosIndustria)	a.agregarPorCriterio(i, comp); //si lo hago con la Logica.listaInsumos no lo ordena bien pero con esta si, buscar y corregir BUG
		List<Insumo> insumosOrdenados = a.inOrden();
		//Respuesta:
		if(nombre==null) {
			System.out.println(insumosOrdenados); //Si no ingreso ningun nombre muestra todos los insumos ordenados por nombre Ascendentemente
			resul.addAll(insumosOrdenados);
		}
		else {
			List<Insumo> insumoEncontrado = insumosOrdenados.stream().filter(i->i.getNombre().compareTo(nombre)==0).collect(Collectors.toList());			//Ger-20190808-0355_ saque el .get(0) porque en vaso de no encontrar el insumo daba puntero a null, ahora primero verifica
			if(!insumoEncontrado.isEmpty()) {
				System.out.println(insumoEncontrado.get(0));
				resul.addAll(insumoEncontrado);
			}
			else {
//				System.out.println("No se encontro el insumo \""+nombre+"\".");
				JOptionPane.showMessageDialog(null, "No se encontró el insumo","¡Error!", JOptionPane.WARNING_MESSAGE);
				
			}
			
		}
		

		return resul;
	}

	public static ArrayList<Insumo> busquedaPorCostoAsc(Double costoMin, Double costoMax) { 
		ArrayList<Insumo> resul = new ArrayList<Insumo>();
		
		
//		System.out.println("\n\n\ncambiar este metodo para que en vez de void de una lista que la guardemos en Logica y despues la usemos en la ventana de resultado de busqueda\n\n\n");
		List<Insumo> listaInsumo = new ArrayList<>();
		//public Insumo(Integer id, String nombre, UnidadDeMedida unidadDeMedida, Double costo, Double peso, Boolean esRefrigerado ) {
		listaInsumo.add(new Insumo(Logica.getNewId(),"MADERA",UnidadDeMedida.KILO, 150.0, 100.0,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"ARENA",UnidadDeMedida.M3, 250.0, 200.0,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"PISTON",UnidadDeMedida.PIEZA, 750.5, 3.0,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"HIELO",UnidadDeMedida.M3, 50.5,1.0,true));
		listaInsumo.add(new Insumo(Logica.getNewId(),"TELA",UnidadDeMedida.M2, 78.5,0.2,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"LEVADURA",UnidadDeMedida.GRAMO, 0.5,0.1,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"ZABORA",UnidadDeMedida.M3, 10.5,0.5,false));
	
		
		ArbolBinarioBusqueda<Insumo> a = new ArbolBinarioBusqueda<Insumo>(); 
		ComparadorCostoAscendente comp = new ComparadorCostoAscendente();		//usa el comparator As-cendente
		for(Insumo i : Logica.listaInsumosIndustria)	a.agregarPorCriterio(i, comp);//si lo hago con la Logica.listaInsumos no lo ordena bien pero con esta si, buscar y corregir BUG
		List<Insumo> insumosOrdenados = a.inOrden();
		//Respuesta:
		if(costoMin==null && costoMax==null) {
			System.out.println(insumosOrdenados); //Si no ingreso ningun nombre muestra todos los insumos ordenados por nombre Ascendentemente
			resul.addAll(insumosOrdenados);
		}
		else {
			resul.addAll(insumosOrdenados.stream().filter(i->i.getCosto()>costoMin && i.getCosto()<costoMax).collect(Collectors.toList()));
			
		}
		
		return resul;
	}
	
public static ArrayList<Insumo> busquedaPorCostoDes(Double costoMin, Double costoMax) {
		
	ArrayList<Insumo> resul = new ArrayList<Insumo>();
	
		List<Insumo> listaInsumo = new ArrayList<>();
		//public Insumo(Integer id, String nombre, UnidadDeMedida unidadDeMedida, Double costo, Double peso, Boolean esRefrigerado ) {
		listaInsumo.add(new Insumo(Logica.getNewId(),"MADERA",UnidadDeMedida.KILO, 150.0, 100.0,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"ARENA",UnidadDeMedida.M3, 250.0, 200.0,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"PISTON",UnidadDeMedida.PIEZA, 750.5, 3.0,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"HIELO",UnidadDeMedida.M3, 50.5,1.0,true));
		listaInsumo.add(new Insumo(Logica.getNewId(),"TELA",UnidadDeMedida.M2, 78.5,0.2,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"LEVADURA",UnidadDeMedida.GRAMO, 0.5,0.1,false));
		listaInsumo.add(new Insumo(Logica.getNewId(),"ZABORA",UnidadDeMedida.M3, 10.5,0.5,false));
	
		
		ArbolBinarioBusqueda<Insumo> a = new ArbolBinarioBusqueda<Insumo>(); 
		ComparadorCostoDescendente comp = new ComparadorCostoDescendente();		//usa el comparator As-cendente
		for(Insumo i : Logica.listaInsumosIndustria)	a.agregarPorCriterio(i, comp);//si lo hago con la Logica.listaInsumos no lo ordena bien pero con esta si, buscar y corregir BUG
		List<Insumo> insumosOrdenados = a.inOrden();
		//Respuesta:
		if(costoMin==null && costoMax==null) {
			System.out.println(insumosOrdenados); //Si no ingreso ningun nombre muestra todos los insumos ordenados por nombre Ascendentemente
			resul.addAll(insumosOrdenados);
		}
		else {
			resul.addAll(insumosOrdenados.stream().filter(i->i.getCosto()>costoMin && i.getCosto()<costoMax).collect(Collectors.toList()));
		}
		return resul;

	}


public static ArrayList<Insumo> busquedaPorStockAsc(Double stockMin, Double stockMax) {
	
	ArrayList<Insumo> resul = new ArrayList<Insumo>();
	
	List<Insumo> listaInsumo = new ArrayList<>();
	//public Insumo(Integer id, String nombre, UnidadDeMedida unidadDeMedida, Double costo, Double peso, Boolean esRefrigerado ) {
	listaInsumo.add(new Insumo(Logica.getNewId(),"MADERA",UnidadDeMedida.KILO, 150.0, 100.0,false));
	listaInsumo.add(new Insumo(Logica.getNewId(),"ARENA",UnidadDeMedida.M3, 250.0, 200.0,false));
	listaInsumo.add(new Insumo(Logica.getNewId(),"PISTON",UnidadDeMedida.PIEZA, 750.5, 3.0,false));
	listaInsumo.add(new Insumo(Logica.getNewId(),"HIELO",UnidadDeMedida.M3, 50.5,1.0,true));
	listaInsumo.add(new Insumo(Logica.getNewId(),"TELA",UnidadDeMedida.M2, 78.5,0.2,false));
	listaInsumo.add(new Insumo(Logica.getNewId(),"LEVADURA",UnidadDeMedida.GRAMO, 0.5,0.1,false));
	listaInsumo.add(new Insumo(Logica.getNewId(),"ZABORA",UnidadDeMedida.M3, 10.5,0.5,false));

	
	ArbolBinarioBusqueda<Insumo> a = new ArbolBinarioBusqueda<Insumo>(); 
	ComparadorStockAscendente comp = new ComparadorStockAscendente();		//usa el comparator As-cendente
	for(Insumo i : Logica.listaInsumosIndustria)	a.agregarPorCriterio(i, comp);//si lo hago con la Logica.listaInsumos no lo ordena bien pero con esta si, buscar y corregir BUG
	List<Insumo> insumosOrdenados = a.inOrden();
	//Respuesta:
	if(stockMin==null && stockMax==null) {
//		System.out.println(insumosOrdenados); //Si no ingreso ningun nombre muestra todos los insumos ordenados por nombre Ascendentemente
		resul.addAll(insumosOrdenados);
	}
	else {
		resul.addAll(insumosOrdenados.stream().filter(i->i.getCantidadEnStockDePlanta()>stockMin && i.getCantidadEnStockDePlanta()<stockMax).collect(Collectors.toList()));
	
	}
	return resul;
}

public static ArrayList<Insumo> busquedaPorStockDes(Double stockMin, Double stockMax) {
	
	ArrayList<Insumo> resul = new ArrayList<Insumo>();
	
	List<Insumo> listaInsumo = new ArrayList<>();
	//public Insumo(Integer id, String nombre, UnidadDeMedida unidadDeMedida, Double costo, Double peso, Boolean esRefrigerado ) {
	listaInsumo.add(new Insumo(Logica.getNewId(),"MADERA",UnidadDeMedida.KILO, 150.0, 100.0,false));
	listaInsumo.add(new Insumo(Logica.getNewId(),"ARENA",UnidadDeMedida.M3, 250.0, 200.0,false));
	listaInsumo.add(new Insumo(Logica.getNewId(),"PISTON",UnidadDeMedida.PIEZA, 750.5, 3.0,false));
	listaInsumo.add(new Insumo(Logica.getNewId(),"HIELO",UnidadDeMedida.M3, 50.5,1.0,true));
	listaInsumo.add(new Insumo(Logica.getNewId(),"TELA",UnidadDeMedida.M2, 78.5,0.2,false));
	listaInsumo.add(new Insumo(Logica.getNewId(),"LEVADURA",UnidadDeMedida.GRAMO, 0.5,0.1,false));
	listaInsumo.add(new Insumo(Logica.getNewId(),"ZABORA",UnidadDeMedida.M3, 10.5,0.5,false));

	
	ArbolBinarioBusqueda<Insumo> a = new ArbolBinarioBusqueda<Insumo>(); 
	ComparadorStockDescendente comp = new ComparadorStockDescendente();		//usa el comparator As-cendente
	for(Insumo i : Logica.listaInsumosIndustria)	a.agregarPorCriterio(i, comp);//si lo hago con la Logica.listaInsumos no lo ordena bien pero con esta si, buscar y corregir BUG
	List<Insumo> insumosOrdenados = a.inOrden();
	//Respuesta:
	if(stockMin==null && stockMax==null) {
//		System.out.println(insumosOrdenados); //Si no ingreso ningun nombre muestra todos los insumos ordenados por nombre Ascendentemente
		resul.addAll(insumosOrdenados);
	}
	else {
		resul.addAll(insumosOrdenados.stream().filter(i->i.getCantidadEnStockDePlanta()>stockMin && i.getCantidadEnStockDePlanta()<stockMax).collect(Collectors.toList()));
	}
	return resul;
	}

public static void arbolTest() {
	
	List<Numerico> n = new ArrayList<>();
	n.add(new Numerico(5));
	n.add(new Numerico(2));
	n.add(new Numerico(8));
	n.add(new Numerico(1));
	n.add(new Numerico(9));
	n.add(new Numerico(3));
	
	System.out.println(n);
	
	ArbolBinarioBusqueda<Numerico> a = new ArbolBinarioBusqueda<Numerico>();
	for (Numerico i : n) a.agregar(i);
	System.out.println(a.inOrden());
	
	List<Alfabetico> m = new ArrayList<>();
	m.add(new Alfabetico("F"));
	m.add(new Alfabetico("B"));
	m.add(new Alfabetico("G"));
	m.add(new Alfabetico("A"));
	m.add(new Alfabetico("E"));
	m.add(new Alfabetico("C"));
	m.add(new Alfabetico("C"));
	m.add(new Alfabetico("D"));
	m.add(new Alfabetico("ABC"));
	m.add(new Alfabetico("ACD"));
	m.add(new Alfabetico("ABD"));
	m.add(new Alfabetico("BBD"));
	m.add(new Alfabetico("BAD"));
	
	System.out.println(m);
	
	ArbolBinarioBusqueda<Alfabetico> aa = new ArbolBinarioBusqueda<Alfabetico>();
	//for (Alfabetico i : m) aa.agregar(i);
	ComparadorAlfafeticos comp = new ComparadorAlfafeticos();
	for (Alfabetico i : m) aa.agregarPorCriterio(i, comp);
	System.out.println(aa.inOrden());
	
	
	List<Insumo> insumos = new ArrayList<>();
	//public Insumo(Integer id, String nombre, UnidadDeMedida unidadDeMedida, Double costo, Double peso, Boolean esRefrigerado ) {
	insumos.add(new Insumo(1,"B",UnidadDeMedida.KILO,2.0,2.0,true));
	insumos.add(new Insumo(1,"A",UnidadDeMedida.KILO,2.0,2.0,true));
	insumos.add(new Insumo(1,"C",UnidadDeMedida.KILO,2.0,2.0,true));
	insumos.add(new Insumo(1,"AABD",UnidadDeMedida.KILO,2.0,2.0,true));
	insumos.add(new Insumo(1,"ABABD",UnidadDeMedida.KILO,2.0,2.0,true));
	insumos.add(new Insumo(1,"BABD",UnidadDeMedida.KILO,2.0,2.0,true));
	insumos.add(new Insumo(1,"BBD",UnidadDeMedida.KILO,2.0,2.0,true));
	
	System.out.println(insumos);
	
	ArbolBinarioBusqueda<Insumo> aaa = new ArbolBinarioBusqueda<Insumo>();
	ComparadorNombreAscendente comp2 = new ComparadorNombreAscendente();
	for(Insumo i : insumos) aaa.agregarPorCriterio(i, comp2);
	System.out.println(aaa.inOrden());
}

}
