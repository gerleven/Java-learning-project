package logica;

import java.util.Comparator;

import isi.died.tp.dominio.Planta;
import isi.died.tp.estructuras.Vertice;

public class ComparadorPageRank implements Comparator<Vertice<Planta>>{
	public int compare(Vertice<Planta> o1, Vertice<Planta>o2) {
			
			return o2.getGradoEntrada()-(o1.getGradoEntrada());
		}
}
