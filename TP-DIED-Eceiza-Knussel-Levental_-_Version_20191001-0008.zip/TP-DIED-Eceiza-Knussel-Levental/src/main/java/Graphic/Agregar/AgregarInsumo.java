package Graphic.Agregar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import App.Bienvenido;
import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.InsumoLiquido;
import isi.died.tp.dominio.UnidadDeMedida;
import logica.Logica;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JSeparator;

public class AgregarInsumo extends JFrame {

	private JPanel contentPane;

	private JTextField costoValor;
	private JTextField nombreValor;
	private JTextField pesoValor;
	private JTextField densidadValor;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AgregarInsumo frame = new AgregarInsumo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AgregarInsumo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		
		JLabel lblAgregarInsumo = new JLabel("Agregar Insumo");
		lblAgregarInsumo.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblAgregarInsumo.setBounds(36, 27, 234, 31);
		contentPane.add(lblAgregarInsumo);
		
		costoValor = new JTextField();
		costoValor.setToolTipText("");
		costoValor.setBounds(373, 194, 153, 22);
		contentPane.add(costoValor);
		costoValor.setColumns(10);
		
		JLabel lblCosto = new JLabel("Costo:");
		lblCosto.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblCosto.setBounds(214, 200, 84, 16);
		contentPane.add(lblCosto);
		
		JLabel lblNewLabel = new JLabel("Nombre:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(214, 88, 90, 16);
		contentPane.add(lblNewLabel);
		
		nombreValor = new JTextField();
		nombreValor.setColumns(10);
		nombreValor.setBounds(373, 82, 153, 22);
		contentPane.add(nombreValor);
		
		JLabel lblPeso = new JLabel("Peso:");
		lblPeso.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPeso.setBounds(214, 144, 70, 16);
		contentPane.add(lblPeso);
		
		pesoValor = new JTextField();
		pesoValor.setColumns(10);
		pesoValor.setBounds(373, 142, 153, 22);
		contentPane.add(pesoValor);
		
		JLabel lblUnidadDeMedida = new JLabel("Unidad de medida:");
		lblUnidadDeMedida.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblUnidadDeMedida.setBounds(214, 269, 130, 16);
		contentPane.add(lblUnidadDeMedida);
		
		JComboBox unidadDeMedidaValor = new JComboBox();
		//unidadDeMedidaValor.setModel(new DefaultComboBoxModel(new String[] {"Seleccione", "KILO", "PIEZA", "GRAMO", "METRO", "LITRO", "M3", "M2"}));
		UnidadDeMedida listaUnidadesDeMedida[] = new UnidadDeMedida[] {UnidadDeMedida.KILO,UnidadDeMedida.PIEZA,UnidadDeMedida.GRAMO,UnidadDeMedida.METRO,UnidadDeMedida.LITRO,UnidadDeMedida.M3,UnidadDeMedida.M2};
		unidadDeMedidaValor.setModel(new DefaultComboBoxModel(listaUnidadesDeMedida));
		unidadDeMedidaValor.setBounds(373, 267, 153, 22);
		contentPane.add(unidadDeMedidaValor);
		unidadDeMedidaValor.setSelectedIndex(-1);
		
		JRadioButton refrigeradoValor = new JRadioButton("Refrigerado");
		refrigeradoValor.setFont(new Font("Tahoma", Font.PLAIN, 15));
		refrigeradoValor.setBounds(393, 340, 140, 25);
		contentPane.add(refrigeradoValor);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final VentanaAgregar a = new VentanaAgregar();
				a.setVisible(true);
				dispose();
				
				
			}
		});
		btnAtras.setBounds(719, 470, 97, 25);
		contentPane.add(btnAtras);
		
		
		JCheckBox chckbxInsumoLiquido = new JCheckBox("Insumo liquido");
		chckbxInsumoLiquido.setFont(new Font("Tahoma", Font.PLAIN, 15));
		chckbxInsumoLiquido.setBounds(214, 340, 137, 25);
		contentPane.add(chckbxInsumoLiquido);
		
		
		JLabel lblDensidad = new JLabel("Densidad:");
		lblDensidad.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDensidad.setBounds(214, 403, 70, 16);
		contentPane.add(lblDensidad);
		lblDensidad.setEnabled(false);
		
		densidadValor = new JTextField();
		densidadValor.setColumns(10);
		densidadValor.setBounds(373, 401, 153, 22);
		contentPane.add(densidadValor);
		densidadValor.setEnabled(false);
		
		chckbxInsumoLiquido.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (chckbxInsumoLiquido.isSelected()) {
					lblPeso.setEnabled(false);
					pesoValor.setEnabled(false);
					lblDensidad.setEnabled(true);
					densidadValor.setEnabled(true);
				} else {
					lblPeso.setEnabled(true);
					pesoValor.setEnabled(true);
					lblDensidad.setEnabled(false);
					densidadValor.setEnabled(false);
				}
			}
		});
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(costoValor.getText().isEmpty() || nombreValor.getText().isEmpty() || ((chckbxInsumoLiquido.isSelected())?false:pesoValor.getText().isEmpty()) || unidadDeMedidaValor.getSelectedIndex()==-1 ) 
					JOptionPane.showMessageDialog(null, "Debe completar todos los campos","¡Error!", JOptionPane.WARNING_MESSAGE);
				else {
					boolean existe = false;
					if(chckbxInsumoLiquido.isSelected()) {
						if (densidadValor.getText().isEmpty())
							JOptionPane.showMessageDialog(null, "Debe especificar la densidad.","¡Error!", JOptionPane.WARNING_MESSAGE);
						else {
							InsumoLiquido nuevoInsumoLiquido = new InsumoLiquido(Logica.getNewId(), nombreValor.getText(), //Logica.getNombreInsumo(),
									(UnidadDeMedida)unidadDeMedidaValor.getSelectedItem(),new Double(costoValor.getText()),
									refrigeradoValor.isSelected(), new Double(densidadValor.getText())
									);
							for (Insumo otroInsumo : Logica.listaInsumosIndustria) {
								if (nuevoInsumoLiquido.equals(otroInsumo)) 
									existe=true;
							}
							if (!existe) {
								Logica.listaInsumosIndustria.add(nuevoInsumoLiquido);
								System.out.println("Insumo liquido agregado: "+nuevoInsumoLiquido.toString());
								JOptionPane.showMessageDialog(null, "Se ha agregado con éxito el insumo líquido: \n"+nuevoInsumoLiquido.toString(),"¡Exito!", JOptionPane.WARNING_MESSAGE);
								 //resetea valores del panel
								
								//if(Bienvenido.cartelito) JOptionPane.showMessageDialog(null, "Se ha agregado con éxito","¡Exito!", JOptionPane.WARNING_MESSAGE);
							} else
								JOptionPane.showMessageDialog(null, "Ya existe un insumo registrado en el sistema.","¡Error!", JOptionPane.WARNING_MESSAGE);
							
						}
					}
					else {
						Insumo nuevoInsumo= new Insumo(Logica.getNewId(), nombreValor.getText(), //Logica.getNombreInsumo(),
								(UnidadDeMedida)unidadDeMedidaValor.getSelectedItem(),new Double(costoValor.getText()),
								new Double(pesoValor.getText()),refrigeradoValor.isSelected());
						for (Insumo otroInsumo : Logica.listaInsumosIndustria) {
							if (nuevoInsumo.getNombre().equals(otroInsumo.getNombre())) 
								existe=true;
						}
						if (!existe) {
							Logica.listaInsumosIndustria.add(nuevoInsumo);
							System.out.println("Insumo solido agregado:"+nuevoInsumo.toString());
							JOptionPane.showMessageDialog(null, "Se ha agregado con éxito el insumo sólido: \n"+nuevoInsumo.toString(),"¡Exito!", JOptionPane.WARNING_MESSAGE);
							
							 
							//if(Bienvenido.cartelito) JOptionPane.showMessageDialog(null, "Se ha agregado con éxito","¡Exito!", JOptionPane.WARNING_MESSAGE);
						} else 
							JOptionPane.showMessageDialog(null, "Ya existe tal insumo registrado en el sistema.","¡Error!", JOptionPane.WARNING_MESSAGE);
					}
				}
				nombreValor.setText(null);
				pesoValor.setText(null);
				costoValor.setText(null);					
				refrigeradoValor.setSelected(false);
				densidadValor.setText(null);
				chckbxInsumoLiquido.setSelected(false);
				pesoValor.setEnabled(true);
				lblPeso.setEnabled(true);
				unidadDeMedidaValor.setSelectedIndex(-1);
			}
		});
		btnAceptar.setBounds(610, 470, 97, 25);
		contentPane.add(btnAceptar);
	}
}
