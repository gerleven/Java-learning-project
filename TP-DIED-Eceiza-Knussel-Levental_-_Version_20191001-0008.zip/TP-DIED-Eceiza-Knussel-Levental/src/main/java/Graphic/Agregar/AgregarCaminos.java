package Graphic.Agregar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import App.Bienvenido;
import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.InsumoLiquido;
import isi.died.tp.dominio.Planta;
import isi.died.tp.dominio.UnidadDeMedida;
import logica.Logica;
import javax.swing.JTextField;

public class AgregarCaminos extends JFrame {

	private JPanel contentPane;
	private JTextField distanciaValor;
	private JTextField duracionValor;
	private JTextField pesoMaxValor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AgregarCaminos frame = new AgregarCaminos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AgregarCaminos() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		

		setLocationRelativeTo(null); //para centrar
		
		
		JLabel lblNewLabel = new JLabel("Agregar Caminos");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel.setBounds(30, 30, 258, 36);
		contentPane.add(lblNewLabel);
		
		JLabel lblPlanta = new JLabel("Planta inicial");
		lblPlanta.setFont(new Font("Dialog", Font.PLAIN, 15));
		lblPlanta.setBounds(111, 128, 87, 16);
		contentPane.add(lblPlanta);
		
		JComboBox plantaInicialValor = new JComboBox();
		List<String> nombrePlantas = new ArrayList<>();
		List<Planta> plantasFiltradas = new ArrayList<>(Logica.listaPlantasIndustria);
		if (!plantasFiltradas.isEmpty()) plantasFiltradas.remove(1);//no te tiene que incluir la del AcopioFinal.
		for(Planta p : plantasFiltradas) nombrePlantas.add(p.get_Nombre_Id());
		plantaInicialValor.setModel(new DefaultComboBoxModel(nombrePlantas.toArray()));
		plantaInicialValor.setBounds(210, 126, 200, 22);
		contentPane.add(plantaInicialValor);
		plantaInicialValor.setSelectedIndex(-1);
		
		JLabel lblPlanta_1 = new JLabel("Planta final");
		lblPlanta_1.setFont(new Font("Dialog", Font.PLAIN, 15));
		lblPlanta_1.setBounds(454, 129, 112, 16);
		contentPane.add(lblPlanta_1);
		
		JComboBox plantaFinalValor = new JComboBox();
		List<String> nombrePlantas2 = new ArrayList<>();
		List<Planta> plantasFiltradas2 = new ArrayList<>(Logica.listaPlantasIndustria);
		if (!plantasFiltradas2.isEmpty()) plantasFiltradas2.remove(0);//no te tiene que incluir la del Puerto.
		for(Planta p : plantasFiltradas2) nombrePlantas2.add(p.get_Nombre_Id());
		plantaFinalValor.setModel(new DefaultComboBoxModel(nombrePlantas2.toArray()));
		plantaFinalValor.setBounds(545, 126, 200, 22);
		contentPane.add(plantaFinalValor);
		plantaFinalValor.setSelectedIndex(-1);
		
		distanciaValor = new JTextField();
		distanciaValor.setColumns(10);
		distanciaValor.setBounds(396, 221, 116, 22);
		contentPane.add(distanciaValor);
		
		duracionValor = new JTextField();
		duracionValor.setColumns(10);
		duracionValor.setBounds(396, 300, 116, 22);
		contentPane.add(duracionValor);
		
		pesoMaxValor = new JTextField();
		pesoMaxValor.setColumns(10);
		pesoMaxValor.setBounds(398, 366, 116, 22);
		contentPane.add(pesoMaxValor);
		
		JLabel duracion = new JLabel("Duración:");
		duracion.setFont(new Font("Dialog", Font.PLAIN, 15));
		duracion.setBounds(278, 295, 106, 16);
		contentPane.add(duracion);
		
		JLabel pesomazimo = new JLabel("Peso Máximo:");
		pesomazimo.setFont(new Font("Dialog", Font.PLAIN, 15));
		pesomazimo.setBounds(278, 366, 106, 16);
		contentPane.add(pesomazimo);
		
		JLabel distancia = new JLabel("Distancia");
		distancia.setFont(new Font("Dialog", Font.PLAIN, 15));
		distancia.setBounds(278, 221, 97, 16);
		contentPane.add(distancia);
		
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.setFont(new Font("Dialog", Font.PLAIN, 15));
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(distanciaValor.getText().isEmpty()||duracionValor.getText().isEmpty()||pesoMaxValor.getText().isEmpty()||plantaInicialValor.getSelectedIndex()==-1||plantaFinalValor.getSelectedIndex()==-1)
						JOptionPane.showMessageDialog(null, "Debe completar todos los campos","¡Error!", JOptionPane.WARNING_MESSAGE);
				else {
					if(plantaInicialValor.getSelectedIndex()!=plantaFinalValor.getSelectedIndex()) {
						Planta plantaInicial = buscarPlanta(plantaInicialValor);
						Planta plantaFinal= buscarPlanta(plantaFinalValor);
						
						
						Number idProximo = (Logica.grafoDePlantas.getAristas().size()+1);
						Logica.grafoDePlantas.conectar(plantaInicial, plantaFinal, idProximo, new Double(distanciaValor.getText()), Integer.valueOf(duracionValor.getText()), new Double(pesoMaxValor.getText()));
						JOptionPane.showMessageDialog(null,"Se conecto la \""+plantaInicial.get_Nombre_Id()+"\" con la \""+plantaFinal.get_Nombre_Id()+"\".", "¡Exito!", JOptionPane.WARNING_MESSAGE);
						Logica.grafoDePlantas.imprimirAristas();
						
						//if(Bienvenido.cartelito) JOptionPane.showMessageDialog(null, "Se ha agregado con éxito","¡Exito!", JOptionPane.WARNING_MESSAGE);
					} else
						JOptionPane.showMessageDialog(null,"No puede crear un camino entre\ndos plantas iguales", "¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				plantaInicialValor.setSelectedIndex(-1);
				plantaFinalValor.setSelectedIndex(-1);
				distanciaValor.setText(null);
				duracionValor.setText(null);
				pesoMaxValor.setText(null);
			}
		});
		btnAceptar.setBounds(593, 467, 97, 25);
		contentPane.add(btnAceptar);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Dialog", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final VentanaAgregar a = new VentanaAgregar();
				a.setVisible(true);
				dispose();		
			}
		});
		btnAtras.setBounds(719, 467, 97, 25);
		contentPane.add(btnAtras);
	
	}

	private Planta buscarPlanta(JComboBox plantaValor){
		Planta plantaEncontrada = null;
		for(Planta p : Logica.listaPlantasIndustria) {
			if(p.get_Nombre_Id().compareTo(plantaValor.getSelectedItem().toString())==0) {
				plantaEncontrada = p;
			}
		}
		return plantaEncontrada;
	}
}
