package Graphic.Agregar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import App.Bienvenido;
import isi.died.tp.dominio.Planta;
import logica.Logica;

public class AgregarPlanta extends JFrame {

	private JPanel contentPane;
	private JTextField nombreValor;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AgregarPlanta frame = new AgregarPlanta();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AgregarPlanta() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 413);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		

		setLocationRelativeTo(null); //para centrar
		
		JLabel lblAgregarPlanta = new JLabel("Agregar Planta");
		lblAgregarPlanta.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblAgregarPlanta.setBounds(38, 32, 300, 29);
		contentPane.add(lblAgregarPlanta);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNombre.setBounds(245, 150, 82, 16);
		contentPane.add(lblNombre);
		
		nombreValor = new JTextField();
		nombreValor.setBounds(334, 147, 180, 22);
		contentPane.add(nombreValor);
		nombreValor.setColumns(10);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final VentanaAgregar a = new VentanaAgregar();
				a.setVisible(true);
				dispose();				
			}
		});
		btnAtras.setBounds(719, 319, 97, 25);
		contentPane.add(btnAtras);
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		//Acciones:
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(nombreValor.getText().isEmpty()) {
						JOptionPane.showMessageDialog(null, "Debe completar todos los campos","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				else {
					boolean existe = false;
					if(Logica.listaPlantasIndustria.isEmpty()) {
						Planta plantaPuerto=new Planta(Logica.getNewId(),"Puerto");
						Logica.listaPlantasIndustria.add(plantaPuerto);
						Logica.grafoDePlantas.addNodo(plantaPuerto);
						Planta plantaAcopioFinal=new Planta(Logica.getNewId(),"AcopioFinal");
						Logica.listaPlantasIndustria.add(plantaAcopioFinal);
						Logica.grafoDePlantas.addNodo(plantaAcopioFinal);
					}
					Planta nuevaPlanta = new Planta(Logica.getNewId(),nombreValor.getText()); 
					for (Planta otraPlanta : Logica.listaPlantasIndustria) {
						if (nuevaPlanta.getNombre().equals(otraPlanta.getNombre()))
							existe=true;
					}
					if(!existe) {
						Logica.listaPlantasIndustria.add(nuevaPlanta);
						Logica.grafoDePlantas.addNodo(nuevaPlanta); 			//verificar esto!
						System.out.println("Se agrego la Planta n° "+Logica.listaPlantasIndustria.size()+" a la Lista de Plantas: "+Logica.listaPlantasIndustria.get(Logica.listaPlantasIndustria.size()-1).getPrint());
						System.out.println("Se agrego la Planta n° "+Logica.listaPlantasIndustria.size()+" al Grafo");
						if (Logica.grafoDePlantas.getNodo(nuevaPlanta)!=null && Logica.listaPlantasIndustria.contains(nuevaPlanta))
							JOptionPane.showMessageDialog(null, "Se ha agregado con éxito.","¡Exito!", JOptionPane.WARNING_MESSAGE);
						else
							JOptionPane.showMessageDialog(null, "No se ha podido agregar, vuelva a intentarlo.","¡Error!", JOptionPane.WARNING_MESSAGE);
						//if(Bienvenido.cartelito) JOptionPane.showMessageDialog(null, "Se ha agregado con éxito","¡Exito!", JOptionPane.WARNING_MESSAGE);
					} else
						JOptionPane.showMessageDialog(null, "Ya existe una planta con ese nombre.","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				nombreValor.setText(null);
			}
		});

		btnAceptar.setBounds(597, 319, 97, 25);
		contentPane.add(btnAceptar);
		
		setLocationRelativeTo(null);
	}
}
