package Graphic.Agregar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import App.Bienvenido;
import isi.died.tp.dominio.Camion;
import logica.Logica;

public class AgregarCamiones extends JFrame {

	private JPanel contentPane;
	private JTextField marca;
	private JTextField modelo;
	private JTextField dominio;
	private JTextField anio;
	private JTextField costoKm;
	private JTextField capacidad;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AgregarCamiones frame = new AgregarCamiones();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AgregarCamiones() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblAgregarCamiones = new JLabel("Agregar Camiones");
		lblAgregarCamiones.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblAgregarCamiones.setBounds(22, 13, 293, 37);
		contentPane.add(lblAgregarCamiones);
		
		JLabel lblMarca = new JLabel("Marca:");
		lblMarca.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblMarca.setBounds(145, 188, 56, 16);
		contentPane.add(lblMarca);
		
		marca = new JTextField();
		marca.setColumns(10);
		marca.setBounds(245, 185, 116, 22);
		contentPane.add(marca);
		
		JLabel lblModelo = new JLabel("Modelo:");
		lblModelo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblModelo.setBounds(145, 291, 56, 16);
		contentPane.add(lblModelo);
		
		modelo = new JTextField();
		modelo.setColumns(10);
		modelo.setBounds(245, 288, 116, 22);
		contentPane.add(modelo);
		
		JLabel lblDominio = new JLabel("Dominio:");
		lblDominio.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblDominio.setBounds(145, 86, 58, 16);
		contentPane.add(lblDominio);
		
		JLabel lblAo = new JLabel("Año:");
		lblAo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblAo.setBounds(440, 291, 56, 16);
		contentPane.add(lblAo);
		
		JLabel lblCostoPorKm = new JLabel("Costo por Km:");
		lblCostoPorKm.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblCostoPorKm.setBounds(440, 81, 99, 16);
		contentPane.add(lblCostoPorKm);
		
		JLabel lblCapacidad = new JLabel("Capacidad:");
		lblCapacidad.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblCapacidad.setBounds(440, 188, 83, 16);
		contentPane.add(lblCapacidad);
		
		JRadioButton rbAptoLiqu = new JRadioButton("Apto para líquidos");
		rbAptoLiqu.setFont(new Font("Tahoma", Font.PLAIN, 15));
		rbAptoLiqu.setBounds(145, 380, 170, 25);
		contentPane.add(rbAptoLiqu);
		
		dominio = new JTextField();
		dominio.setColumns(10);
		dominio.setBounds(245, 83, 116, 22);
		contentPane.add(dominio);
		
		anio = new JTextField();
		anio.setColumns(10);
		anio.setBounds(562, 288, 116, 22);
		contentPane.add(anio);
		
		costoKm = new JTextField();
		costoKm.setColumns(10);
		costoKm.setBounds(562, 78, 116, 22);
		contentPane.add(costoKm);
		
		capacidad = new JTextField();
		capacidad.setColumns(10);
		capacidad.setBounds(562, 185, 116, 22);
		contentPane.add(capacidad);
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//System.out.println("Por razones de tiempo no se implemento la carga de camiones, se debe hacer mediante la carga automatica en la Clase Logica");
				
				
				if(marca.getText().isEmpty()||modelo.getText().isEmpty()||dominio.getText().isEmpty()||anio.getText().isEmpty()||costoKm.getText().isEmpty()||capacidad.getText().isEmpty())
					JOptionPane.showMessageDialog(null, "Debe completar todos los campos","¡Error!", JOptionPane.WARNING_MESSAGE);
				else {
				//Contructor Camion(Integer idCamion, String marca, String modelo, Integer dominio, Integer anio, Float costoPorKm,Boolean aptoLiquidos, Float capacidad)
				Camion camion=new Camion(Logica.getNewId(), marca.getText().toString(), modelo.getText().toString(), Integer.parseInt(dominio.getText()), Integer.parseInt(anio.getText()), Double.parseDouble(costoKm.getText()), rbAptoLiqu.isSelected(), Double.parseDouble(capacidad.getText())); //20190814-2330 se cambio float por Double
				Logica.listaCamiones.add(camion);
				JOptionPane.showMessageDialog(null, "Se ha agregado el camion: "+camion.toString(),"¡Exito!", JOptionPane.WARNING_MESSAGE);
				
				System.out.println("Se agrego el nuevo camion n° "+Logica.listaCamiones.size()+" a la Lista de Camiones: "+Logica.listaCamiones.get(Logica.listaCamiones.size()-1).getIdCamion());
				System.out.println("Se agrego la Planta n° "+Logica.listaPlantasIndustria.size()+" al Grafo");
				//if(Bienvenido.cartelito) JOptionPane.showMessageDialog(null, "Se ha agregado con éxito","¡Exito!", JOptionPane.WARNING_MESSAGE);
				}
				dominio.setText(null);
				costoKm.setText(null);
				marca.setText(null);
				capacidad.setText(null);
				modelo.setText(null);
				anio.setText(null);
				rbAptoLiqu.setSelected(false);
			}
		});
		btnAceptar.setBounds(595, 470, 97, 25);
		contentPane.add(btnAceptar);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final VentanaAgregar a = new VentanaAgregar();
				a.setVisible(true);
				dispose();		
			}
		});
		btnAtras.setBounds(719, 470, 97, 25);
		contentPane.add(btnAtras);
		

		setLocationRelativeTo(null); //para centrar
		
		
	}
}
