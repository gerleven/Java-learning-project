package Graphic.Agregar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import App.Bienvenido;
import isi.died.tp.dominio.Camion;
import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.Planta;
import isi.died.tp.dominio.Stock;
import isi.died.tp.dominio.UnidadDeMedida;
import isi.died.tp.estructuras.Arbol;
import isi.died.tp.estructuras.ArbolBinarioBusqueda;
import isi.died.tp.estructuras.Grafo;
import logica.Logica;

public class VentanaAgregar extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaAgregar frame = new VentanaAgregar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaAgregar() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		

		setLocationRelativeTo(null); 
		
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final Bienvenido a = new Bienvenido();
				a.setVisible(true);
				dispose();
				
			}
		});
		btnAtras.setBounds(719, 470, 97, 25);
		contentPane.add(btnAtras);
		
		JLabel lblAgregar = new JLabel("¿Qué desea agregar?");
		lblAgregar.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblAgregar.setBounds(45, 25, 293, 42);
		contentPane.add(lblAgregar);
		
		
		final AgregarInsumo insumo= new AgregarInsumo();
		
		JButton btnInsumos = new JButton("Insumo");
		btnInsumos.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnInsumos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				insumo.setVisible(true);
				dispose();
				
			}
		});
		btnInsumos.setBounds(312, 93, 176, 25);
		contentPane.add(btnInsumos);
		
		JButton btnPlantas = new JButton("Plantas");
		btnPlantas.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnPlantas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final AgregarPlanta a = new AgregarPlanta();
				a.setVisible(true);
				dispose();
			}
		});
		btnPlantas.setBounds(312, 159, 176, 25);
		contentPane.add(btnPlantas);
		
		JButton btnCaminos = new JButton("Caminos");
		btnCaminos.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnCaminos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final AgregarCaminos a = new AgregarCaminos();
				a.setVisible(true);
				dispose();	
			}
		});
		btnCaminos.setBounds(312, 320, 176, 25);
		contentPane.add(btnCaminos);
		
		JButton btnStock = new JButton("Stock");
		btnStock.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnStock.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				final AgregarStock a = new AgregarStock();
				a.setVisible(true);
				dispose();
			}
		});
		btnStock.setBounds(312, 237, 176, 25);
		contentPane.add(btnStock);
		
		JButton btnCamiones = new JButton("Camiones");
		btnCamiones.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnCamiones.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final AgregarCamiones a = new AgregarCamiones();
				a.setVisible(true);
				dispose();		
				
			}
		});
		btnCamiones.setBounds(312, 394, 176, 25);
		contentPane.add(btnCamiones);
		
	
	}
}

