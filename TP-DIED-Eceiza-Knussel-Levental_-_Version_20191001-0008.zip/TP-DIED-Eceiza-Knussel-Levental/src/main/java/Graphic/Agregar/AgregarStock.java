package Graphic.Agregar;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import App.Bienvenido;
import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.InsumoLiquido;
import isi.died.tp.dominio.Planta;
import isi.died.tp.dominio.Stock;
import isi.died.tp.dominio.UnidadDeMedida;
import isi.died.tp.estructuras.Vertice;
import logica.Logica;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;

public class AgregarStock extends JFrame {

	private JPanel contentPane;
	private JTextField cantidadValor;
	private JTextField puntoPedidoValor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AgregarStock frame = new AgregarStock();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AgregarStock() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		setLocationRelativeTo(null); //para centrar
		
		JLabel lblAgregarStock = new JLabel("Agregar Stock");
		lblAgregarStock.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblAgregarStock.setBounds(40, 13, 248, 34);
		contentPane.add(lblAgregarStock);
		
		JLabel lblCantidad = new JLabel("Cantidad:");
		lblCantidad.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblCantidad.setBounds(219, 96, 69, 16);
		contentPane.add(lblCantidad);
		
		JLabel lblPuntoDePedido = new JLabel("Punto de pedido:");
		lblPuntoDePedido.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPuntoDePedido.setBounds(219, 170, 125, 16);
		contentPane.add(lblPuntoDePedido);
		
		JLabel lblInsumo = new JLabel("Insumo:");
		lblInsumo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblInsumo.setBounds(219, 243, 56, 16);
		contentPane.add(lblInsumo);
		
		cantidadValor = new JTextField();
		cantidadValor.setColumns(10);
		cantidadValor.setBounds(386, 96, 168, 22);
		contentPane.add(cantidadValor);
		
		puntoPedidoValor = new JTextField();
		puntoPedidoValor.setColumns(10);
		puntoPedidoValor.setBounds(386, 167, 168, 22);
		contentPane.add(puntoPedidoValor);
		
		JComboBox insumoValor = new JComboBox();
		insumoValor.setBounds(386, 240, 168, 22);
		List<String> nombreInsumos = new ArrayList<>();
		for(Insumo i : Logica.listaInsumosIndustria) nombreInsumos.add(i.get_Nombre_Id());
		insumoValor.setModel(new DefaultComboBoxModel(nombreInsumos.toArray()));
		contentPane.add(insumoValor);
		insumoValor.setSelectedIndex(-1);
		
		JComboBox plantaValor = new JComboBox();
		plantaValor.setBounds(386, 320, 168, 22);
		List<String> nombrePlantas = new ArrayList<>();
		for(Planta p : Logica.listaPlantasIndustria) nombrePlantas.add(p.get_Nombre_Id());
		plantaValor.setModel(new DefaultComboBoxModel(nombrePlantas.toArray()));
		contentPane.add(plantaValor);
		plantaValor.setSelectedIndex(-1);
		
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(cantidadValor.getText().isEmpty()||puntoPedidoValor.getText().isEmpty()||insumoValor.getSelectedIndex()==-1||plantaValor.getSelectedIndex()==-1)
					JOptionPane.showMessageDialog(null, "Debe completar todos los campos","¡Error!", JOptionPane.WARNING_MESSAGE);
				else {
					boolean existe=false;
					Stock nuevoStock = new Stock(Logica.getNewId(),Logica.listaInsumosIndustria.get(insumoValor.getSelectedIndex()),Integer.valueOf(cantidadValor.getText()),Integer.valueOf(puntoPedidoValor.getText()));
					for (Stock listaStock : Logica.listaPlantasIndustria.get(plantaValor.getSelectedIndex()).getListaStock()) {
						if (listaStock.getInsumo().equals(nuevoStock.getInsumo()))
							existe=true;
					}
					if (!existe) {
						Logica.listaStocksIndustria.add(nuevoStock);
						System.out.println(plantaValor.getSelectedIndex());
						Logica.listaPlantasIndustria.get(plantaValor.getSelectedIndex()).agregarAStock(nuevoStock);
						System.out.println("Se agregó el Stock a la planta: "+(Logica.listaPlantasIndustria.get(plantaValor.getSelectedIndex())).getListaStock());
						JOptionPane.showMessageDialog(null, "Se agrego "+nuevoStock.toString()+" a la planta "+Logica.listaPlantasIndustria.get(plantaValor.getSelectedIndex()),"¡Exito!", JOptionPane.WARNING_MESSAGE);
					} else 
						JOptionPane.showMessageDialog(null,"Ya existe un stock con tal insumo en dicha planta.","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				cantidadValor.setText(null);
				puntoPedidoValor.setText(null);
				insumoValor.setSelectedIndex(-1);
				plantaValor.setSelectedIndex(-1);
					//if(Bienvenido.cartelito) JOptionPane.showMessageDialog(null, "Se ha agregado con éxito","¡Exito!", JOptionPane.WARNING_MESSAGE);
				
				
			}
		});
		btnAceptar.setBounds(604, 470, 97, 25);
		contentPane.add(btnAceptar);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final VentanaAgregar a = new VentanaAgregar();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(719, 470, 97, 25);
		contentPane.add(btnAtras);
		
		JLabel lblPlanta = new JLabel("Planta:");
		lblPlanta.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPlanta.setBounds(219, 322, 56, 16);
		contentPane.add(lblPlanta);
		
		
		
		
	}
	
	private Insumo buscarInsumo(JComboBox insumoValor){
		Insumo insumoEncontrado = null;
		for(Insumo i : Logica.listaInsumosIndustria) {
			if(i.get_Nombre_Id().compareTo(insumoValor.getSelectedItem().toString())==0) {
				insumoEncontrado = i;
			}
		}
		return insumoEncontrado;
	}
	
	private Planta buscarPlanta(JComboBox plantaValor){
		Planta plantaEncontrada = null;
		for(Planta p : Logica.listaPlantasIndustria) {
			if(p.get_Nombre_Id().compareTo(plantaValor.getSelectedItem().toString())==0) {
				plantaEncontrada = p;
			}
		}
		return plantaEncontrada;
	}
}
