package Graphic.Buscar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import logica.Logica;
import logica.Parte03;

public class BuscarInsumoStock extends JFrame {

	private JPanel contentPane;

	private JTextField stockMinValor;
	private JTextField stockMaxValor;

	public static Double stockMinInsumo;
	public static Double stockMaxInsumo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BuscarInsumoStock frame = new BuscarInsumoStock();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BuscarInsumoStock() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 424);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		setLocationRelativeTo(null); //para centrar
		
		JLabel lblBuscarInsumoPor = new JLabel("Buscar insumo por stock");
		lblBuscarInsumoPor.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblBuscarInsumoPor.setBounds(32, 23, 307, 37);
		contentPane.add(lblBuscarInsumoPor);
		
		JLabel lblStockMinimo = new JLabel("Stock minimo");
		lblStockMinimo.setFont(new Font("Dialog", Font.PLAIN, 15));
		lblStockMinimo.setBounds(57, 149, 95, 16);
		contentPane.add(lblStockMinimo);
		
		stockMinValor = new JTextField();
		stockMinValor.setBounds(192, 147, 149, 22);
		contentPane.add(stockMinValor);
		stockMinValor.setColumns(10);
		
		JLabel lblStockMaximo = new JLabel("Stock maximo");
		lblStockMaximo.setFont(new Font("Dialog", Font.PLAIN, 15));
		lblStockMaximo.setBounds(447, 147, 95, 16);
		contentPane.add(lblStockMaximo);
		
		stockMaxValor = new JTextField();
		stockMaxValor.setColumns(10);
		stockMaxValor.setBounds(582, 147, 149, 22);
		contentPane.add(stockMaxValor);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Dialog", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final CriterioBusquedaInsumo a = new CriterioBusquedaInsumo();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(664, 327, 97, 25);
		contentPane.add(btnAtras);
		
		JButton busquedaAsc = new JButton("Busqueda ascendente");
		busquedaAsc.setFont(new Font("Dialog", Font.PLAIN, 15));
		busquedaAsc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(stockMinValor.getText().compareTo("")==0) stockMinInsumo=null;
				else stockMinInsumo = new Double(stockMinValor.getText());
				
				if(stockMaxValor.getText().compareTo("")==0) stockMaxInsumo=null;
				else stockMaxInsumo = new Double(stockMaxValor.getText());
				ResultadosBusquedaInsumo.seleccion=5;
				final ResultadosBusquedaInsumo a= new ResultadosBusquedaInsumo();
				a.setVisible(true);
				dispose();
		}
		});
		busquedaAsc.setBounds(78, 327, 208, 25);
		contentPane.add(busquedaAsc);
		
		JButton busquedaDes = new JButton("Busqueda descendente");
		busquedaDes.setFont(new Font("Dialog", Font.PLAIN, 15));
		busquedaDes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(stockMinValor.getText().compareTo("")==0) stockMinInsumo=null;
				else stockMinInsumo = new Double(stockMinValor.getText());
				
				if(stockMaxValor.getText().compareTo("")==0) stockMaxInsumo=null;
				else stockMaxInsumo = new Double(stockMaxValor.getText());
				ResultadosBusquedaInsumo.seleccion=6;
				final ResultadosBusquedaInsumo a= new ResultadosBusquedaInsumo();
				a.setVisible(true);
				dispose();
		}
		});
		busquedaDes.setBounds(378, 327, 208, 25);
		contentPane.add(busquedaDes);
		
	}

}
