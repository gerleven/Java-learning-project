package Graphic.Buscar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Editar.EditarCamino;
import Editar.EditarPlanta;
import isi.died.tp.dominio.Planta;
import isi.died.tp.estructuras.Arista;
import logica.Logica;
import java.awt.Font;

public class ResultadosBusquedaCamino extends JFrame {

		private JPanel contentPane;

		private JTable tablaResultado;
		public 	List<Arista<Planta>> caminos = new ArrayList<>();//cambie camino por arista
		private JTable table;
		public static Arista caminoGlob;

		/**
		 * Launch the application.
		 */
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						ResultadosBusquedaCamino frame = new ResultadosBusquedaCamino();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}

		/**
		 * Create the frame.
		 */
			public void cargarTabla() {
				DefaultTableModel actualizado = (DefaultTableModel) table.getModel();
				actualizado.setRowCount(0);
				table.setVisible(true);
				

				caminos = (List<Arista<Planta>>) Logica.grafoDePlantas.getAristas();
				
				
					for(int i=0; i< caminos.size(); i++) {
						String[] datos= new String [8];
	
						datos[0] = caminos.get(i).getInicio().getValor().getIdPlanta().toString();
						datos[1] = caminos.get(i).getInicio().getValor().toString();			
						datos[2] = caminos.get(i).getFin().getValor().getIdPlanta().toString();
						datos[3] =caminos.get(i).getFin().getValor().toString();
						datos[4]=caminos.get(i).getDistancia().toString();	
						datos[5]= caminos.get(i).getDuracionDelViaje().toString();
						datos[6]= caminos.get(i).getPesoMaximoCamino().toString();
						
						actualizado.addRow(datos);
						
					}
				}
			
				
			
			
			public ResultadosBusquedaCamino() {
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				setBounds(100, 100, 846, 555);
				getContentPane().setLayout(null);

				setLocationRelativeTo(null);
				
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(12, 13, 804, 431);
				getContentPane().add(scrollPane);
				
				table = new JTable();
				table.setFillsViewportHeight(true);
				table.setSurrendersFocusOnKeystroke(true);
				table.setModel(new DefaultTableModel(
					new Object[][] {}, new String[] {"idPlantaInicial", "Planta inicial", "idPlantaFinal", "Planta final", "Distancia", "Duraci\u00F3n", "Peso m\u00E1ximo"}) {
					Class[] columnTypes = new Class[] {String.class, Object.class,String.class, Object.class, String.class, String.class, String.class};
					public Class getColumnClass(int columnIndex) {
						return columnTypes[columnIndex];
					}
				});
				table.getColumnModel().getColumn(2).setResizable(false);
				table.getColumnModel().getColumn(3).setResizable(false);
				table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				table.setAutoCreateRowSorter(true);
				scrollPane.setViewportView(table);
				
				
				
				JButton button = new JButton("Eliminar");
				button.setFont(new Font("Tahoma", Font.PLAIN, 15));
				button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						int seleccion = table.getSelectedRow(); //me da la fila seleccionada 
						
						if(seleccion==-1) {
							JOptionPane.showMessageDialog(null, "Debe seleccionar una fila","¡Error!", JOptionPane.WARNING_MESSAGE);
						}
						else {
						String idPlantaInicial = table.getModel().getValueAt(seleccion, 0).toString();  //obtengo el id planta inicial
						String idPlantaFinal = table.getModel().getValueAt(seleccion, 2).toString(); //obtengo el id planta final
						Planta inicial = new Planta();
						Planta fin = new Planta();
						
						for (Planta planta : Logica.listaPlantasIndustria) {
							if (planta.getIdPlanta().toString().equals(idPlantaInicial))
								inicial=planta;
							else if (planta.getIdPlanta().toString().equals(idPlantaFinal))
								fin=planta;
						}
						Arista<Planta> aristaEliminar = Logica.grafoDePlantas.buscarArista(inicial, fin);
						Logica.grafoDePlantas.getAristas().remove(aristaEliminar);
						JOptionPane.showMessageDialog(null, "Camino \""+aristaEliminar.toString()+"\" eliminado satisfactoriamente","¡Exito!", JOptionPane.WARNING_MESSAGE);
						cargarTabla();
						
						idPlantaInicial=null;
						idPlantaFinal=null;
						inicial=null;
						fin=null;
						aristaEliminar=null;
						}
					}
				});
				button.setBounds(594, 470, 97, 25);
				getContentPane().add(button);
				
				JButton btnAtras = new JButton("Atras");
				btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
				btnAtras.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						final VentanaBuscar a = new VentanaBuscar();
						a.setVisible(true);
						dispose();
					
					}
				});
				btnAtras.setBounds(719, 470, 97, 25);
				getContentPane().add(btnAtras);
				
				JButton button_2 = new JButton("Editar");
				button_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
				button_2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						int seleccion = table.getSelectedRow(); //me da la fila seleccionada 
						System.out.println(seleccion);
						if(seleccion==-1) {
							JOptionPane.showMessageDialog(null, "Debe elegir una fila","¡Error!", JOptionPane.WARNING_MESSAGE);
						}
						else {
							caminoGlob=caminos.get(seleccion);
							System.out.println(caminoGlob);
							final EditarCamino a = new EditarCamino();
							a.setVisible(true);
							dispose();
						}
						}
					
				});
				button_2.setBounds(467, 470, 97, 25);
				getContentPane().add(button_2);
				
			
				caminos = (List<Arista<Planta>>) Logica.grafoDePlantas.getAristas();
				
				cargarTabla();
				
				
				/*int seleccion = table.getSelectedRow(); //me da la fila seleccionada 
				String idPlanta = table.getModel().getValueAt(seleccion, 0).toString();  //obtengo el id 
				String nombrePlanta = table.getModel().getValueAt(seleccion, 1).toString(); //obtengo el nombre
				System.out.println(idPlanta+ nombrePlanta);*/
			}
	}
