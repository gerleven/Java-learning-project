package Graphic.Buscar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JTextField;

public class BuscarPlantaPor extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BuscarPlantaPor frame = new BuscarPlantaPor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BuscarPlantaPor() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBuscarPlantas = new JLabel("Buscar plantas por:");
		lblBuscarPlantas.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblBuscarPlantas.setBounds(29, 28, 276, 38);
		contentPane.add(lblBuscarPlantas);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final VentanaBuscar a = new VentanaBuscar();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(719, 470, 97, 25);
		contentPane.add(btnAtras);
		
		JButton btnId = new JButton("Id");
		btnId.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnId.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final BuscarPlantaId a = new BuscarPlantaId();
				a.setVisible(true);
				dispose();
				
			}
		});
		btnId.setBounds(300, 163, 175, 25);
		contentPane.add(btnId);
		
		JButton btnNombre = new JButton("Nombre");
		btnNombre.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNombre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final BuscarPlantaNombre a = new BuscarPlantaNombre();
				a.setVisible(true);
				dispose();
			}
		});
		btnNombre.setBounds(300, 301, 175, 25);
		contentPane.add(btnNombre);

		setLocationRelativeTo(null);
		
		
	}
}
