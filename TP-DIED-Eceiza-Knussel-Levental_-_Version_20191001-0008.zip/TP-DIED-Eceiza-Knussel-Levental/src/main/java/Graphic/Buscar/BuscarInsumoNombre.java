package Graphic.Buscar;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import logica.Logica;
import logica.Parte03;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Set;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JList;

public class BuscarInsumoNombre extends JFrame {

	private JPanel contentPane;
	private JTextField nombreValor;
	public static String nombre;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BuscarInsumoNombre frame = new BuscarInsumoNombre();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BuscarInsumoNombre() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 424);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		setLocationRelativeTo(null); //para centrar
		
		JLabel lblBuscarInsumoPor = new JLabel("Buscar insumo por nombre");
		lblBuscarInsumoPor.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblBuscarInsumoPor.setBounds(26, 24, 328, 42);
		contentPane.add(lblBuscarInsumoPor);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setFont(new Font("Dialog", Font.PLAIN, 15));
		lblNombre.setBounds(215, 150, 97, 16);
		contentPane.add(lblNombre);
		
		nombreValor = new JTextField();
		nombreValor.setBounds(365, 148, 195, 22);
		contentPane.add(nombreValor);
		nombreValor.setColumns(10);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Dialog", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				final CriterioBusquedaInsumo a = new CriterioBusquedaInsumo();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(679, 327, 97, 25);
		contentPane.add(btnAtras);
		
		JButton busquedaAsc = new JButton("Busqueda ascendente");
		busquedaAsc.setFont(new Font("Dialog", Font.PLAIN, 15));
		busquedaAsc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				nombre = nombreValor.getText();
				if(nombre.compareTo("")==0) 
					nombre=null;
				ResultadosBusquedaInsumo.seleccion=1;
				final ResultadosBusquedaInsumo a= new ResultadosBusquedaInsumo();
				a.setVisible(true);
				dispose();
				
				
			}
		});
		busquedaAsc.setBounds(36, 327, 205, 25);
		contentPane.add(busquedaAsc);
		
		JButton busquedaDes = new JButton("Busqueda descendente");
		busquedaDes.setFont(new Font("Dialog", Font.PLAIN, 15));
		busquedaDes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nombre = nombreValor.getText();
				if(nombre.compareTo("")==0) 
					nombre=null;
				ResultadosBusquedaInsumo.seleccion=2;
				final ResultadosBusquedaInsumo a= new ResultadosBusquedaInsumo();
				a.setVisible(true);
				dispose();
				
				
				
			}
		});
		busquedaDes.setBounds(355, 327, 205, 25);
		contentPane.add(busquedaDes);
	}
}
