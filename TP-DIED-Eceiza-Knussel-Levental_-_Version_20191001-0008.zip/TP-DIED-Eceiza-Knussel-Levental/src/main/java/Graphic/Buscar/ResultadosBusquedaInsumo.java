package Graphic.Buscar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Editar.EditarInsumo;
import isi.died.tp.dominio.Insumo;
import logica.Logica;
import logica.Parte03;

public class ResultadosBusquedaInsumo extends JFrame {
	
	public static int seleccion;

	private JPanel contentPane;
	private JTable tablaResultado;
	public 	ArrayList<Insumo> insumos = new ArrayList<Insumo>();
	private JTable table;
	public static Insumo insumoGlob;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ResultadosBusquedaInsumo frame = new ResultadosBusquedaInsumo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void cargarTabla() {
		DefaultTableModel actualizado = (DefaultTableModel) table.getModel();
		actualizado.setRowCount(0);
		table.setVisible(true);
		List<Insumo> insumos = new ArrayList<Insumo>();
		
		switch (seleccion){
		case 1:
			insumos=Parte03.busquedaPorNombreAsc(BuscarInsumoNombre.nombre);
			break;
		case 2:
			insumos=Parte03.busquedaPorNombreDes(BuscarInsumoNombre.nombre);
			break;
			
		case 3:
			insumos=Parte03.busquedaPorCostoAsc(BuscarInsumoCosto.costoMinInsumo,BuscarInsumoCosto.costoMaxInsumo);
			break;
			
		case 4:
			insumos=Parte03.busquedaPorCostoDes(BuscarInsumoCosto.costoMinInsumo, BuscarInsumoCosto.costoMaxInsumo);
			break;
			
		case 5:
			insumos=Parte03.busquedaPorStockAsc(BuscarInsumoStock.stockMinInsumo,BuscarInsumoStock.stockMaxInsumo);
			break;
			
		case 6:
			insumos=Parte03.busquedaPorStockDes(BuscarInsumoStock.stockMinInsumo,BuscarInsumoStock.stockMaxInsumo);
			break;
			
			default:
				JOptionPane.showMessageDialog(null, "Error inesperado","¡Error!", JOptionPane.WARNING_MESSAGE);
		}
		
		for(int i=0; i< insumos.size(); i++) {
			String[] datos= new String [8];

			datos[0] = String.valueOf(insumos.get(i).getIdInsumo());
			datos[1] = insumos.get(i).getNombre();
			datos[2]= insumos.get(i).getCosto().toString();
			datos[3]= insumos.get(i).getPeso().toString();
			datos[4]= insumos.get(i).getCantidadEnStockDePlanta().toString();
			datos[5]= insumos.get(i).getEsRefrigerado().toString();
			
			actualizado.addRow(datos);
			
		}
	}

	public ResultadosBusquedaInsumo() {
		setTitle("Resultados de busqueda de insumos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		getContentPane().setLayout(null);

		setLocationRelativeTo(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 13, 804, 444);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Tahoma", Font.PLAIN, 15));
		table.setFillsViewportHeight(true);
		table.setSurrendersFocusOnKeystroke(true);
		table.setModel(new DefaultTableModel(new Object[][] {}, new String[] {"Id Insumo", "Nombre Insumo", "Costo", "Peso", "Stock", "Refrigerado"}) {
			Class[] columnTypes = new Class[] {Object.class, String.class, Object.class, Object.class, Object.class, Object.class};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table.getColumnModel().getColumn(1).setResizable(false);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setAutoCreateRowSorter(true);
		scrollPane.setViewportView(table);
		
		JButton button = new JButton("Eliminar");
		button.setFont(new Font("Tahoma", Font.PLAIN, 15));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int seleccion = table.getSelectedRow(); //me da la fila seleccionada 
				if(seleccion==-1) {
					JOptionPane.showMessageDialog(null, "Debe elegir una fila","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				else {
				String idInsumo = table.getModel().getValueAt(seleccion, 0).toString();  //obtengo el id 
				String nombreInsumo = table.getModel().getValueAt(seleccion, 1).toString(); //obtengo el nombre
				List<Insumo> insumoEliminar = new ArrayList<>();
				
				for (Insumo insumo : Logica.listaInsumosIndustria) {
					if (insumo.getIdInsumo().toString().equals(idInsumo))
						insumoEliminar.add(insumo);
				}
				Logica.listaInsumosIndustria.remove(insumoEliminar.get(0));
				JOptionPane.showMessageDialog(null, nombreInsumo+" eliminado satisfactoriamente.","¡Exito!", JOptionPane.WARNING_MESSAGE);
				idInsumo=null;
				nombreInsumo=null;
				insumoEliminar.clear();
				cargarTabla();

				
			}}
		});
		button.setBounds(588, 470, 97, 25);
		getContentPane().add(button);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final CriterioBusquedaInsumo a = new CriterioBusquedaInsumo();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(719, 470, 97, 25);
		getContentPane().add(btnAtras);
		
		JButton button_2 = new JButton("Editar");
		button_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int seleccion = table.getSelectedRow(); //me da la fila seleccionada 
				if(seleccion==-1) {
					JOptionPane.showMessageDialog(null, "Debe elegir una fila","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				else {
					int i;
					for( i=0; i< insumos.size();i++) {
						if(Integer.parseInt(insumos.get(i).getIdInsumo().toString())==Integer.parseInt( table.getModel().getValueAt(seleccion, 0).toString())) {
							
							 insumoGlob=insumos.get(i);
						}
						/*System.out.println(table.getModel().getValueAt(seleccion, 0));
						System.out.println(insumos.get(i).getIdInsumo());
						System.out.println(insumoGlob);*/
					}
					
				final EditarInsumo a = new EditarInsumo();
				a.setVisible(true);
				dispose();
			}}
		});
		button_2.setBounds(455, 470, 97, 25);
		getContentPane().add(button_2);
		
		insumos = (ArrayList<Insumo>) Logica.listaInsumosIndustria;
		
		cargarTabla();
	}
}
