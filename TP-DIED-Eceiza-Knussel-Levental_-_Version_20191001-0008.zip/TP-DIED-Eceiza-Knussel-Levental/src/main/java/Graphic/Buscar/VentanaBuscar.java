package Graphic.Buscar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import App.Bienvenido;
import logica.Logica;

public class VentanaBuscar extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaBuscar frame = new VentanaBuscar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaBuscar() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDeseaBuscar = new JLabel("¿Qué desea buscar?");
		lblDeseaBuscar.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblDeseaBuscar.setBounds(31, 27, 289, 32);
		contentPane.add(lblDeseaBuscar);
		
		JButton btnInsumo = new JButton("Insumos");
		btnInsumo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnInsumo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Por buscan un insumo...");
				if (!Logica.listaInsumosIndustria.isEmpty()) {
				final CriterioBusquedaInsumo a = new CriterioBusquedaInsumo();
				a.setVisible(true);
				dispose();
				}
				else {
					JOptionPane.showMessageDialog(null, "Aun no hay Insumos cargados","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				
			}
		});
		btnInsumo.setBounds(319, 97, 175, 25);
		contentPane.add(btnInsumo);
		
		JButton btnPlantas = new JButton("Plantas");
		btnPlantas.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnPlantas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final BuscarPlantaPor a = new BuscarPlantaPor();
				a.setVisible(true);
				dispose();
				
			}
		});
		btnPlantas.setBounds(319, 175, 175, 25);
		contentPane.add(btnPlantas);
		
		JButton btnCaminos = new JButton("Caminos");
		btnCaminos.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnCaminos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final ResultadosBusquedaCamino a = new ResultadosBusquedaCamino();
				a.setVisible(true);
				dispose();
				
				
			}
		});
		btnCaminos.setBounds(319, 256, 175, 25);
		contentPane.add(btnCaminos);
		
		JButton btnCamiones = new JButton("Camiones");
		btnCamiones.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnCamiones.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final ResultadosBusquedaCamion a = new ResultadosBusquedaCamion();
				a.setVisible(true);
				dispose();
				
			}
		});
		btnCamiones.setBounds(319, 334, 175, 25);
		contentPane.add(btnCamiones);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				final Bienvenido a = new Bienvenido();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(719, 470, 97, 25);
		contentPane.add(btnAtras);
		
		setLocationRelativeTo(null); 
		
		
	}

}
