package Graphic.Buscar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class BuscarCamiones extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BuscarCamiones frame = new BuscarCamiones();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BuscarCamiones() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBuscarCamiones = new JLabel("Buscar Camiones");
		lblBuscarCamiones.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblBuscarCamiones.setBounds(35, 23, 254, 36);
		contentPane.add(lblBuscarCamiones);
		
		JLabel lblNewLabel = new JLabel("Capacidad:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(253, 108, 89, 16);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(411, 102, 143, 22);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JRadioButton rdbtnLiquido = new JRadioButton("Apto para liquidos");
		rdbtnLiquido.setFont(new Font("Tahoma", Font.PLAIN, 15));
		rdbtnLiquido.setBounds(309, 358, 176, 25);
		contentPane.add(rdbtnLiquido);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnBuscar.setBounds(565, 470, 97, 25);
		contentPane.add(btnBuscar);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final VentanaBuscar a = new VentanaBuscar();
				a.setVisible(true);
				dispose();		
				
			}
		});
		btnAtras.setBounds(719, 470, 97, 25);
		contentPane.add(btnAtras);
		
		JLabel lblPlanta = new JLabel("Planta inicial:");
		lblPlanta.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPlanta.setBounds(253, 195, 89, 16);
		contentPane.add(lblPlanta);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(411, 195, 143, 22);
		contentPane.add(comboBox);
		
		JLabel lblPlanta_1 = new JLabel("Planta final:");
		lblPlanta_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPlanta_1.setBounds(253, 288, 89, 16);
		contentPane.add(lblPlanta_1);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(411, 286, 143, 22);
		contentPane.add(comboBox_1);
		

		setLocationRelativeTo(null);
		
		
	}
}