package Graphic.Buscar;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CriterioBusquedaInsumo extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CriterioBusquedaInsumo frame = new CriterioBusquedaInsumo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CriterioBusquedaInsumo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		setLocationRelativeTo(null); //para centrar
		
		JLabel lblCriterioDeBsqueda = new JLabel("Buscar insumo por:");
		lblCriterioDeBsqueda.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblCriterioDeBsqueda.setBounds(35, 29, 243, 29);
		contentPane.add(lblCriterioDeBsqueda);
		
		JButton btnNewButton = new JButton("Nombre");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				final BuscarInsumoNombre a = new BuscarInsumoNombre();
				a.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(352, 101, 97, 25);
		contentPane.add(btnNewButton);
		
		JButton btnCosto = new JButton("Costo");
		btnCosto.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnCosto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final BuscarInsumoCosto a = new BuscarInsumoCosto();
				a.setVisible(true);
				dispose();
			}
		});
		btnCosto.setBounds(352, 205, 97, 25);
		contentPane.add(btnCosto);
		
		JButton btnStock = new JButton("Stock");
		btnStock.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnStock.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final BuscarInsumoStock a= new BuscarInsumoStock();
				a.setVisible(true);
				dispose();
			}
		});
		btnStock.setBounds(352, 309, 97, 25);
		contentPane.add(btnStock);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				final VentanaBuscar a = new VentanaBuscar();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(719, 470, 97, 25);
		contentPane.add(btnAtras);
	}
}
