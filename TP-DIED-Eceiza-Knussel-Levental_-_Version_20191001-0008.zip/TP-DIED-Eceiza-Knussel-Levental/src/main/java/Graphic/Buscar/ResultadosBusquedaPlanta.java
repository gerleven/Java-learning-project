package Graphic.Buscar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Editar.EditarInsumo;
import Editar.EditarPlanta;
import isi.died.tp.dominio.Planta;
import isi.died.tp.estructuras.Arista;
import isi.died.tp.estructuras.Vertice;
import logica.Logica;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JScrollPane;

public class ResultadosBusquedaPlanta extends JFrame {

	private JPanel contentPane;
	private JTable tablaResultado;
	public 	ArrayList<Planta> plantas = new ArrayList<Planta>();
	private JTable table;
	public static Planta plantaGlob;
	public static int banderaPlanta;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ResultadosBusquedaPlanta frame = new ResultadosBusquedaPlanta();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void cargarTabla() {
		DefaultTableModel actualizado = (DefaultTableModel) table.getModel();
		actualizado.setRowCount(0);
		table.setVisible(true);

		plantas = (ArrayList<Planta>) Logica.listaPlantasIndustria;
		
		switch (banderaPlanta){
		
		case 1:
			for(int i=0; i< plantas.size(); i++) {
				String[] datos= new String [3];
				
				
				datos[0] = plantas.get(i).getIdPlanta().toString();
				datos[1] = plantas.get(i).getNombre();
				
				actualizado.addRow(datos);
				 }
			break;
			
		case 2:
			for(int i=0; i< plantas.size();i++) {
				if(Integer.parseInt(plantas.get(i).getIdPlanta().toString())== BuscarPlantaId.idGlob) {
					
					 plantaGlob=plantas.get(i);
					 String[] datos= new String [3];
					
					datos[0] = String.valueOf(plantas.get(i).getIdPlanta());
					datos[1] = plantas.get(i).getNombre();
					
					actualizado.addRow(datos);
				}}
				break;
		case 3: 
			String[] datos= new String [3];
		
			datos[0] = BuscarPlantaNombre.plantaGlob.getIdPlanta().toString();
			datos[1] = BuscarPlantaNombre.plantaGlob.getNombre();
			
			actualizado.addRow(datos);
			
			break;
		default:
			JOptionPane.showMessageDialog(null, "Error inesperado","¡Error!", JOptionPane.WARNING_MESSAGE);
		}}
	
		
	
	
	public ResultadosBusquedaPlanta() {
		setTitle("Plantas");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		getContentPane().setLayout(null);

		setLocationRelativeTo(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 13, 804, 444);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Tahoma", Font.PLAIN, 15));
		table.setVisible(false);
		table.setFillsViewportHeight(true);
		table.setSurrendersFocusOnKeystroke(true);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Id Planta", "Nombre Planta"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table.getColumnModel().getColumn(0).setResizable(false);
		table.getColumnModel().getColumn(1).setResizable(false);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setAutoCreateRowSorter(true);
		scrollPane.setViewportView(table);
		

		
		JButton button = new JButton("Eliminar");
		button.setFont(new Font("Tahoma", Font.PLAIN, 15));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int seleccion = table.getSelectedRow(); //me da la fila seleccionada 
				if(seleccion==-1) {
					JOptionPane.showMessageDialog(null, "Debe elegir una fila","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				else {
				String idPlanta = table.getModel().getValueAt(seleccion, 0).toString();  //obtengo el id 
				String nombrePlanta = table.getModel().getValueAt(seleccion, 1).toString(); //obtengo el nombre
				List<Planta> plantaEliminar = new ArrayList<>();
				List<Arista<Planta>> aristasEliminar = new ArrayList<>();
				List<Vertice<Planta>> verticeEliminar = new ArrayList<>();
				
				//Elimino planta de listaPlantasIndustria
				for (Planta planta : Logica.listaPlantasIndustria) {
					if (planta.getIdPlanta().toString().equals(idPlanta))
						plantaEliminar.add(planta);
				}
				Logica.listaPlantasIndustria.remove(plantaEliminar.get(0));
				//Elimino aristas asociadas a la planta
				for (Arista<Planta> arista : Logica.grafoDePlantas.getAristas()) {
					if (arista.getFin().getValor().getIdPlanta().toString().equals(idPlanta) || arista.getInicio().getValor().getIdPlanta().toString().equals(idPlanta))
						aristasEliminar.add(arista);
				}
				Logica.grafoDePlantas.getAristas().removeAll(aristasEliminar);	
				//Elimino vertice asociado a la planta
				for (Vertice<Planta> vertice : Logica.grafoDePlantas.getVertices()) {
					if (vertice.getValor().getIdPlanta().toString().equals(idPlanta))
						verticeEliminar.add(vertice);
				}
				Logica.grafoDePlantas.getVertices().remove(verticeEliminar.get(0));
				JOptionPane.showMessageDialog(null, nombrePlanta+" eliminada satisfactoriamente.","¡Exito!", JOptionPane.WARNING_MESSAGE);
				//reseteo valores
				idPlanta=null;
				nombrePlanta=null;
				plantaEliminar.clear();
				aristasEliminar.clear();
				verticeEliminar.clear();
				cargarTabla();
				}
			}
		});
		button.setBounds(589, 470, 97, 25);
		getContentPane().add(button);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final BuscarPlantaPor a = new BuscarPlantaPor();
				a.setVisible(true);
				dispose();
				
				
			}
		});
		btnAtras.setBounds(719, 470, 97, 25);
		getContentPane().add(btnAtras);
		
		JButton button_2 = new JButton("Editar");
		button_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				int seleccion = table.getSelectedRow(); //me da la fila seleccionada 
				System.out.println(seleccion);
				if(seleccion==-1) {
					JOptionPane.showMessageDialog(null, "Debe elegir una fila","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				else {
					
					//buscar la planta en la lista de plantas y mandarsela a la ventana de editar
					int i;
					for( i=0; i< plantas.size();i++) {
						if(Integer.parseInt(plantas.get(i).getIdPlanta().toString())==Integer.parseInt( table.getModel().getValueAt(seleccion, 0).toString())) {
							
							 plantaGlob=plantas.get(i);
						}
						System.out.println(table.getModel().getValueAt(seleccion, 0));
						System.out.println(plantas.get(i).getIdPlanta());
						System.out.println(plantaGlob);
					}
					
					final EditarPlanta a = new EditarPlanta();
					a.setVisible(true);
					dispose();
				}
				
			}
		});
		button_2.setBounds(459, 470, 97, 25);
		getContentPane().add(button_2);
		
		plantas = (ArrayList<Planta>) Logica.listaPlantasIndustria;
		
		cargarTabla();
	}
}