package Graphic.Buscar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;


import Editar.EditarCamion;
import Editar.EditarPlanta;
import isi.died.tp.dominio.Camion;
import isi.died.tp.dominio.Insumo;
import logica.Logica;
import java.awt.Font;

public class ResultadosBusquedaCamion extends JFrame {

		private JPanel contentPanel;
		private JTable tablaResultado;
		public 	ArrayList<Camion> camiones = new ArrayList<Camion>();
		private JTable table;
		public static Camion camionGlob;
		/**
		 * Launch the application.
		 */
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						ResultadosBusquedaCamion frame = new ResultadosBusquedaCamion();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}

		/**
		 * Create the frame.
		 */
		public void cargarTabla() {
			DefaultTableModel actualizado = (DefaultTableModel) table.getModel();
			actualizado.setRowCount(0);
			table.setVisible(true);
			
			camiones = (ArrayList<Camion>) Logica.listaCamiones;
			for(int i=0; i< camiones.size(); i++) {
				String[] datos= new String [8];
				datos[0] = camiones.get(i).getIdCamion().toString();
				datos[1] = camiones.get(i).getMarca();
				datos[2] = camiones.get(i).getModelo();
				datos[3] = camiones.get(i).getDominio().toString();
				datos[4] = camiones.get(i).getAnio().toString();
				datos[5] = camiones.get(i).getCostoPorKm().toString();
				datos[6] = camiones.get(i).getAptoLiquidos().toString();
				datos[7] = camiones.get(i).getCapacidad().toString();
				
				actualizado.addRow(datos);
				
			}
		}
			
		
		
		public ResultadosBusquedaCamion() {
			setTitle("Resultados de busqueda de camiones");
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(100, 100, 846, 555);
			getContentPane().setLayout(null);

			setLocationRelativeTo(null);
			
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(12, 13, 804, 431);
			getContentPane().add(scrollPane);
			
			table = new JTable();
			table.setFillsViewportHeight(true);
			table.setSurrendersFocusOnKeystroke(true);
			table.setModel(new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
					"Id Camion", "Marca", "Modelo", "Dominio", "A\u00F1o", "Costo por km", "Apto para l\u00EDquidos", "Capacidad"
				}
			) {
				Class[] columnTypes = new Class[] {
					String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class
				};
				public Class getColumnClass(int columnIndex) {
					return columnTypes[columnIndex];
				}
				boolean[] columnEditables = new boolean[] {
					true, true, true, true, true, true, true, false
				};
				public boolean isCellEditable(int row, int column) {
					return columnEditables[column];
				}
			});
			table.getColumnModel().getColumn(1).setResizable(false);
			table.getColumnModel().getColumn(2).setResizable(false);
			table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			table.setAutoCreateRowSorter(true);
			scrollPane.setViewportView(table);
			
			
			
			JButton button = new JButton("Eliminar");
			button.setFont(new Font("Tahoma", Font.PLAIN, 15));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int seleccion = table.getSelectedRow(); //me da la fila seleccionada 
					if(seleccion==-1) {
						JOptionPane.showMessageDialog(null, "Debe seleccionar una fila","¡Error!", JOptionPane.WARNING_MESSAGE);
					}
					else {
					String idCamion = table.getModel().getValueAt(seleccion, 0).toString();  //obtengo el id 
					String marcaCamion = table.getModel().getValueAt(seleccion, 1).toString();
					String modeloCamion = table.getModel().getValueAt(seleccion, 2).toString();
					List<Camion> camionEliminar = new ArrayList<>();
					
					for (Camion camion : Logica.listaCamiones) {
						if (camion.getIdCamion().toString().equals(idCamion))
							camionEliminar.add(camion);
					}
					Logica.listaCamiones.remove(camionEliminar.get(0));
					JOptionPane.showMessageDialog(null, "Camion \""+marcaCamion+"\" \""+modeloCamion+"\" eliminado satisfactoriamente.","¡Exito!", JOptionPane.WARNING_MESSAGE);
					cargarTabla();
					
					idCamion=null;
					marcaCamion=null;
					modeloCamion=null;
					camionEliminar.clear();
					}
				}
			});
			button.setBounds(600, 470, 97, 25);
			getContentPane().add(button);
			
			JButton button_1 = new JButton("Atras");
			button_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
			button_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					final VentanaBuscar a = new VentanaBuscar();
					a.setVisible(true);
					dispose();
				}
			});
			button_1.setBounds(719, 470, 97, 25);
			getContentPane().add(button_1);
			
			JButton button_2 = new JButton("Editar");
			button_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
			button_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					

					int seleccion = table.getSelectedRow(); //me da la fila seleccionada 
					System.out.println(seleccion);
					if(seleccion==-1) {
						JOptionPane.showMessageDialog(null, "Debe elegir una fila","¡Error!", JOptionPane.WARNING_MESSAGE);
					}
					else {
						
						//buscar la planta en la lista de plantas y mandarsela a la ventana de editar
						
						for(int i=0; i< camiones.size();i++) {
							if(camiones.get(i).getIdCamion()==Integer.parseInt( table.getModel().getValueAt(seleccion, 0).toString())) {
								
								 camionGlob=camiones.get(i);
							
							System.out.println(table.getModel().getValueAt(seleccion, 0));
							System.out.println(camiones.get(i).getIdCamion());
							}
						}
						
					
					final EditarCamion a = new EditarCamion();
					a.setVisible(true);
					dispose();
				}
				}
			});
			button_2.setBounds(478, 470, 97, 25);
			getContentPane().add(button_2);

			cargarTabla();
		}

	}
