package Graphic.Buscar;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import logica.Parte03;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BuscarInsumoCosto extends JFrame {

	private JPanel contentPane;
	private JTextField costoMinValor;
	private JTextField costoMaxValor;

	public static Double costoMinInsumo;
	public static Double costoMaxInsumo;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BuscarInsumoCosto frame = new BuscarInsumoCosto();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BuscarInsumoCosto() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 426);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		setLocationRelativeTo(null); //para centrar
		
		JLabel lblBuscarInsumoPor = new JLabel("Buscar insumo por costo");
		lblBuscarInsumoPor.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblBuscarInsumoPor.setBounds(26, 39, 294, 27);
		contentPane.add(lblBuscarInsumoPor);
		
		JLabel lblCostoMinimo = new JLabel("Costo minimo:");
		lblCostoMinimo.setFont(new Font("Dialog", Font.PLAIN, 15));
		lblCostoMinimo.setBounds(56, 176, 115, 16);
		contentPane.add(lblCostoMinimo);
		
		costoMinValor = new JTextField();
		costoMinValor.setBounds(228, 174, 151, 22);
		contentPane.add(costoMinValor);
		costoMinValor.setColumns(10);
		
		JLabel lblCostoMaximo = new JLabel("Costo maximo:");
		lblCostoMaximo.setFont(new Font("Dialog", Font.PLAIN, 15));
		lblCostoMaximo.setBounds(443, 176, 115, 16);
		contentPane.add(lblCostoMaximo);
		
		costoMaxValor = new JTextField();
		costoMaxValor.setColumns(10);
		costoMaxValor.setBounds(615, 174, 151, 22);
		contentPane.add(costoMaxValor);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Dialog", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final CriterioBusquedaInsumo a = new CriterioBusquedaInsumo();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(705, 333, 97, 25);
		contentPane.add(btnAtras);
		
		JButton busquedaAsc = new JButton("Busqueda ascendente");
		busquedaAsc.setFont(new Font("Dialog", Font.PLAIN, 15));
		busquedaAsc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(costoMinValor.getText().compareTo("")==0) costoMinInsumo=null;
				else costoMinInsumo = new Double(costoMinValor.getText());
				
				
				if(costoMaxValor.getText().compareTo("")==0) costoMaxInsumo=null;
				else costoMaxInsumo = new Double(costoMaxValor.getText());
				ResultadosBusquedaInsumo.seleccion=3;
				final ResultadosBusquedaInsumo a= new ResultadosBusquedaInsumo();
				a.setVisible(true);
				dispose();
				
			}
		});
		busquedaAsc.setBounds(44, 333, 200, 25);
		contentPane.add(busquedaAsc);
		
		JButton busquedaDes = new JButton("Busqueda descendente");
		busquedaDes.setFont(new Font("Dialog", Font.PLAIN, 15));
		busquedaDes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				//Ger20180808-0325_ cambie arg0 por e pero igual sigue sin andar el boton
				
				if(costoMinValor.getText().compareTo("")==0) costoMinInsumo=null;
				else costoMinInsumo = new Double(costoMinValor.getText());
				
				
				if(costoMaxValor.getText().compareTo("")==0) costoMaxInsumo=null;
				else costoMaxInsumo = new Double(costoMaxValor.getText());
				ResultadosBusquedaInsumo.seleccion=4;
				final ResultadosBusquedaInsumo a= new ResultadosBusquedaInsumo();
				a.setVisible(true);
				dispose();
				
				
				
			}
		});
		busquedaDes.setBounds(375, 333, 200, 25);
		contentPane.add(busquedaDes);
		

	}
}
