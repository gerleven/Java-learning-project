package Graphic.Buscar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import isi.died.tp.dominio.Planta;
import logica.Logica;

import javax.swing.JComboBox;

public class BuscarPlantaNombre extends JFrame {

	private JPanel contentPane;
	public static Planta plantaGlob;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BuscarPlantaNombre frame = new BuscarPlantaNombre();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BuscarPlantaNombre() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 355);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		setLocationRelativeTo(null); //para centrar
		
		JLabel lblBuscarInsumoPor = new JLabel("Buscar planta por nombre");
		lblBuscarInsumoPor.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblBuscarInsumoPor.setBounds(25, 23, 304, 26);
		contentPane.add(lblBuscarInsumoPor);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setFont(new Font("Dialog", Font.PLAIN, 15));
		lblNombre.setBounds(253, 133, 100, 16);
		contentPane.add(lblNombre);
		

		JComboBox nombrePlanta = new JComboBox();
		nombrePlanta.setBounds(365, 130, 183, 22);

		List<String> plantas = new ArrayList<>();
		for(Planta i : Logica.listaPlantasIndustria) plantas.add(i.get_Nombre_Id());
		nombrePlanta.setModel(new DefaultComboBoxModel(plantas.toArray()));
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setFont(new Font("Dialog", Font.PLAIN, 15));
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				plantaGlob=Logica.listaPlantasIndustria.get(nombrePlanta.getSelectedIndex());

				ResultadosBusquedaPlanta.banderaPlanta=3;
				final ResultadosBusquedaPlanta a= new ResultadosBusquedaPlanta();
				a.setVisible(true);
				dispose();
			}
		});
		btnBuscar.setBounds(561, 270, 97, 25);
		contentPane.add(btnBuscar);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Dialog", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				final BuscarPlantaPor a = new BuscarPlantaPor();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(700, 270, 97, 25);
		contentPane.add(btnAtras);
		
		
		contentPane.add(nombrePlanta);
	}

}
