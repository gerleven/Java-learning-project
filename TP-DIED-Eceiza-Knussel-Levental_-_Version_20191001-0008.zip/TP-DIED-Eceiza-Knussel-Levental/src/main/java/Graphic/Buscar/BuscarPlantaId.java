package Graphic.Buscar;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class BuscarPlantaId extends JFrame {

	private JPanel contentPane;
	public static int idGlob=0;

	private JTextField id;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BuscarPlantaId frame = new BuscarPlantaId();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BuscarPlantaId() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 424);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		setLocationRelativeTo(null); //para centrar
		
		JLabel lblBuscarInsumoPor = new JLabel("Buscar planta por id");
		lblBuscarInsumoPor.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblBuscarInsumoPor.setBounds(23, 24, 293, 26);
		contentPane.add(lblBuscarInsumoPor);
		
		JLabel lblNombre = new JLabel("Id:");
		lblNombre.setFont(new Font("Dialog", Font.PLAIN, 15));
		lblNombre.setBounds(295, 177, 56, 16);
		contentPane.add(lblNombre);
		
		id = new JTextField();
		id.setBounds(399, 175, 116, 22);
		contentPane.add(id);
		id.setColumns(10);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setFont(new Font("Dialog", Font.PLAIN, 15));
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(id.getText().isEmpty()) {
					ResultadosBusquedaPlanta.banderaPlanta=1;
					idGlob=0;
					final ResultadosBusquedaPlanta a= new ResultadosBusquedaPlanta();
					a.setVisible(true);
					dispose();
					
				}
				else {

					ResultadosBusquedaPlanta.banderaPlanta=2;
					idGlob=  Integer.parseInt(id.getText());
					final ResultadosBusquedaPlanta a= new ResultadosBusquedaPlanta();
					a.setVisible(true);
					dispose();
				}
			}
		});
		btnBuscar.setBounds(575, 339, 97, 25);
		contentPane.add(btnBuscar);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Dialog", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				final BuscarPlantaPor a = new BuscarPlantaPor();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(719, 339, 97, 25);
		contentPane.add(btnAtras);
	}

}
