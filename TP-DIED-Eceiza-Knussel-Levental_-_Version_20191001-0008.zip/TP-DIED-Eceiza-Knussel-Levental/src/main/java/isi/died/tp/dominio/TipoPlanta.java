package isi.died.tp.dominio;

public enum TipoPlanta {
	AcopioPuerto, Intermedio, AcopioFinal 
}
