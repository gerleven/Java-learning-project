package isi.died.tp.dominio;

public class Stock {
	private Integer idStock;
	private Insumo insumo;
	private Integer cantidad;
	private Integer puntoPedido;
	
	
	//Geters and Seters
	public Insumo getInsumo() {
		return insumo;
	}
	public void setInsumo(Insumo insumo) {
		this.insumo = insumo;
	}
	public Integer getIdStock() {
		return idStock;
	}
	public void setIdStock(Integer id) {
		this.idStock = id;
	}
	public Integer getCantidad() {
		return cantidad;
	}
	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}
	public Integer getPuntoPedido() {
		return puntoPedido;
	}
	public void setPuntoPedido(Integer puntoPedido) {
		this.puntoPedido = puntoPedido;
	}

	
	//Constructores:
		public Stock() {
		} //no borrar, se usa en el taller 4 c)
		
		public Stock(Integer idStock, Insumo insumo, Integer cantidad, Integer puntoPedido) {
			setIdStock(idStock);
			setInsumo(insumo);
			setCantidad(cantidad);
			setPuntoPedido(puntoPedido);
			this.insumo.setCantidadEnStockDePlanta(cantidad);
			this.insumo.setStockQueMeContiene(this);
		}
		
		//Insumos liquidos:
		public Stock(Integer idStock, InsumoLiquido insumo, Integer cantidad, Integer puntoPedido) {
			setIdStock(idStock);
			setInsumo(insumo);
			setCantidad(cantidad);
			setPuntoPedido(puntoPedido);
			this.insumo.setCantidadEnStockDePlanta(cantidad); //Litros
			this.insumo.setPeso(insumo.cantidadEnStockDePlanta*0.001* insumo.densidad);
			this.insumo.setStockQueMeContiene(this);
		}
		
	//Metodos:
		
		public void print() {
			System.out.println(this.getPrint());
		}
		
		public String getPrint() {
			//return "listo!";
			String print = "idStock: "+this.getIdStock().toString()+" Insumo: "+this.getInsumo().getNombre().toString()+"("+this.getInsumo().getIdInsumo().toString()+")"
			+" Cantidad: "+this.getCantidad().toString()+" Punto de pedido: "+this.getPuntoPedido()+".";
			return print; 
		}
		
		public String toString() {  //20190820 Ger. agregue este por las duda que le hagamos un toString en alguna parte
			//return "listo!";
			String print = "idStock: "+this.getIdStock().toString()+" Insumo: "+this.getInsumo().getNombre().toString()+"("+this.getInsumo().getIdInsumo().toString()+")"
			+" Cantidad: "+this.getCantidad().toString()+" Punto de pedido: "+this.getPuntoPedido();
			return print; 
		}
		
		public String get_Nombre_Id() {
			return "Stock-"+this.getInsumo().getNombre().toString()+"(id:"+this.getIdStock().toString()+")";
		}
}
