package isi.died.tp.estructuras; 
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.stream.Collectors;
import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.Planta;
import logica.ComparadorPageRank;
 
public class GrafoPlanta extends Grafo<Planta> { 
	

	//Atributos
//	private List<Arista<T>> aristas;
//	private List<Vertice<T>> vertices;
//	private Vertice<Planta> plantaPuerto;
//	private Vertice<Planta> plantaAcopioFinal;
	
	//Constructores
	public GrafoPlanta() {
		super();
		//this.setPlantaPuerto();
		//this.setPlantaAcopioFinal();
	}
	
	//Getters and Setters
	
	public Vertice<Planta> getPlantaPuerto() {  //Ger20190922-0110
		Vertice<Planta> v = new Vertice(new Planta());
		if(this.getVertices().isEmpty()) {
			return v;
		}
		else {
			for(Vertice<Planta> vPlanta : this.getVertices()) {
				if (this.gradoEntrada(vPlanta)==0 && this.gradoSalida(vPlanta)>0) { //Si no un nodo suelto que aun no tenga creada la arista seria un puerto y un copio al mismo tiempo 
					v = vPlanta;
				}
			}
		}
		return v;
	}
	
	public Vertice<Planta> getPlantaAcopioFinal() {
		Vertice<Planta> v = new Vertice(new Planta());
		if(this.getVertices().isEmpty()) {
			return v;
		}
		else {
			for(Vertice<Planta> vPlanta : this.getVertices()) {
				if (this.gradoSalida(vPlanta)==0 && this.gradoEntrada(vPlanta)>0) { //Si no un nodo suelto que aun no tenga creada la arista seria un puerto y un copio al mismo tiempo 
					v = vPlanta;
				}
			}
		}
		return v;
	}
	
	//---------- no sirven mas:
	/*
	public Vertice<Planta> getPlantaPuerto2() { 
		if(this.plantaPuerto==null) { //Ger20190827-0059
			setPlantaPuerto();
		}
		return this.plantaPuerto;
	}
	
	public void setPlantaPuerto() {												//Agu-20190808-1635 corregi el metodo
		//System.out.println("Antes: "+this.plantaPuerto);
		for(Vertice<Planta> vPlanta : this.getVertices()) {
			if (this.gradoEntrada(vPlanta)==0 && this.gradoSalida(vPlanta)>0) {
				//System.out.println("planta encontrada: "+vPlanta);
				this.plantaPuerto=vPlanta;
			}
		}	
	}
	
	
	
	
	public Vertice<Planta> getPlantaAcopioFinal2() {
		if(this.plantaAcopioFinal==null) { //Ger20190827-0101
			this.setPlantaAcopioFinal();
		}
		return this.plantaAcopioFinal;
	}
	
	public void setPlantaAcopioFinal() {							//Agu-20190808-1635 corregi el metodo
		for(Vertice<Planta> vPlanta : this.getVertices()) {
			if (this.gradoSalida(vPlanta)==0 && this.gradoEntrada(vPlanta)>0) { //Si no un nodo suelto que aun no tenga creada la arista seria un puerto y un copio al mismo tiempo 
				this.plantaAcopioFinal=vPlanta;
			}
		}
	}
	*/
	
	//METODOS:
	public void imprimirDistanciaAdyacentes(Planta inicial) {     
		List<Planta> adyacentes = super.getAdyacentes(inicial);    
	  
		for(Planta unAdyacente: adyacentes) {        
		  Arista<Planta> camino = super.buscarArista(inicial, unAdyacente);        
		  System.out.println("camino de "+inicial.getNombre()+" a "+ unAdyacente.getNombre()+ " tiene valor de "+ camino.getValor() );                    
		}
	}  
	
	//Devuelve lista de plantas que necesitan el insumo
	public List<Vertice<Planta>> buscarPlantasFaltaInsumo(Insumo i) {  //4-a Vfinal_ devuelve lista de las plantas que necesitan el insumo
		List<Vertice<Planta>> listaPlantas = new ArrayList<>();
		    
		List<Vertice<Planta>> adyacentes;
		Stack<Vertice<Planta>> visitar = new Stack<Vertice<Planta>>();
		HashSet<Vertice<Planta>> visitados = new HashSet<Vertice<Planta>>();
		Vertice<Planta> inicio =new Vertice<>(this.getPlantaPuerto().getValor());
			
		visitar.push(inicio);
		visitados.add(inicio);	
		while(!visitar.empty()) {
			Vertice<Planta> verticeActual = visitar.pop();	
			adyacentes=this.getAdyacentes(verticeActual);
		
			if(!adyacentes.isEmpty()) {
				for(Vertice<Planta> adya : adyacentes) {
					if(adya.getValor().necesitaInsumo(i)) {
						listaPlantas.add(adya);
						visitar.push(adya);
						visitados.add(adya);
						}
					if(!visitados.contains(adya)) {
						visitar.push(adya);
						visitados.add(adya);
					}
				}
			}
		}
		return listaPlantas;
	}

	
	public List<List<Vertice<Planta>>> mejorCaminoDistancia(Insumo i) { //4-c  
		List<List<Vertice<Planta>>> listaCaminos = new ArrayList<>();
		List<List<Vertice<Planta>>> listaCaminosPosible = new ArrayList<>();//caminos que tiene a la totalidad de plantas que necesitan el insumo
		List<List<Vertice<Planta>>> listaCaminosFinal = new ArrayList<>();
		Map<List<Vertice<Planta>>, Double> caminosYdistancia = new HashMap<>();
		//List<List<Vertice<Planta>>> listaCaminosFinalIncompleto = new ArrayList<>();//caminos que tienen parte de las plantas que necesitan el insumo por lo que se debe ver como armar dos o mas caminos para devolver
		List<Vertice<Planta>> caminoMasCorto = new ArrayList<>();
		List<Vertice<Planta>> listaPlantas = new ArrayList<>();
		List<Vertice<Planta>> aRemover = new ArrayList<>();
		//obtengo caminos desde puerto hasta acopio final
		listaCaminos=this.caminos(this.getPlantaPuerto(),this.getPlantaAcopioFinal());
		
		//obtengo plantas que necesitan insumo y agrego puerto y acopio final para poder comparar luego
		listaPlantas=this.buscarPlantasFaltaInsumo(i);

		//guarda en listaCaminosPosible los caminos que contienen todas las plantas que necesitan insumo
		for(List<Vertice<Planta>> camino : listaCaminos) {
			if (camino.containsAll(listaPlantas))
				listaCaminosPosible.add(camino);
		}
		//si no encuentra un camino que contenga todas las plantas, entonces buscar mas de un camino
		if (listaCaminosPosible.isEmpty()) {
			for(List<Vertice<Planta>> camino : listaCaminos) {
				for (Vertice<Planta> planta : listaPlantas) {
					if (camino.contains(planta)) {
						if (!listaCaminosPosible.contains(camino)) 
								listaCaminosPosible.add(camino);
					}	
				}
			}
		}
		
		//Calcula distancia de cada camino y lo guarda en un map(camino,distancia)
		for (List<Vertice<Planta>> camino : listaCaminosPosible) {
			Double cont=0.0;
			for (int tam=camino.size();tam>=2;tam--) {
				Vertice<Planta> vUltimo=camino.get(tam-1);
				Vertice<Planta> vAnterior=camino.get(tam-2);
				
				Arista<Planta> arista = this.buscarArista(vAnterior, vUltimo);
				
				cont+=arista.getDistancia();
			}
			caminosYdistancia.put(camino, cont);
		}

		while (!listaPlantas.isEmpty()) {
			Double cont2=Double.MAX_VALUE;
		
			for (Map.Entry<List<Vertice<Planta>>, Double> c : caminosYdistancia.entrySet()) {
				for (Vertice<Planta> planta : listaPlantas) {
					if (c.getKey().contains(planta)) {
						if (c.getValue()<cont2) {
							caminoMasCorto=c.getKey();
							cont2=c.getValue();
						}
					}
				}
			}
			listaCaminosFinal.add(caminoMasCorto);
			for (Vertice<Planta> planta : listaPlantas) {
				if (caminoMasCorto.contains(planta))
					aRemover.add(planta);
			}
			listaPlantas.removeAll(aRemover);
		}
		
		return listaCaminosFinal; 
	}
	
	
	public List<List<Vertice<Planta>>> mejorCaminoDuracion(Insumo i) { 
		List<List<Vertice<Planta>>> listaCaminos = new ArrayList<>();
		List<List<Vertice<Planta>>> listaCaminosPosible = new ArrayList<>();//caminos que tiene a la totalidad de plantas que necesitan el insumo
		List<List<Vertice<Planta>>> listaCaminosFinal = new ArrayList<>();
		Map<List<Vertice<Planta>>, Double> caminosYduracion = new HashMap<>();
		//List<List<Vertice<Planta>>> listaCaminosFinalIncompleto = new ArrayList<>();//caminos que tienen parte de las plantas que necesitan el insumo por lo que se debe ver como armar dos o mas caminos para devolver
		List<Vertice<Planta>> caminoMasCorto = new ArrayList<>();
		List<Vertice<Planta>> listaPlantas = new ArrayList<>();
		List<Vertice<Planta>> aRemover = new ArrayList<>();
		//obtengo caminos desde puerto hasta acopio final
		listaCaminos=this.caminos(this.getPlantaPuerto(),this.getPlantaAcopioFinal());
		
		//obtengo plantas que necesitan insumo y agrego puerto y acopio final para poder comparar luego
		listaPlantas=this.buscarPlantasFaltaInsumo(i);

		//guarda en listaCaminosPosible los caminos que contienen todas las plantas que necesitan insumo
		for(List<Vertice<Planta>> camino : listaCaminos) {
			if (camino.containsAll(listaPlantas))
				listaCaminosPosible.add(camino);
		}
		//si no encuentra un camino que contenga todas las plantas, entonces buscar mas de un camino
		if (listaCaminosPosible.isEmpty()) {
			for(List<Vertice<Planta>> camino : listaCaminos) {
				for (Vertice<Planta> planta : listaPlantas) {
					if (camino.contains(planta)) {
						if (!listaCaminosPosible.contains(camino)) 
								listaCaminosPosible.add(camino);
					}	
				}
			}
		}
		
		//Calcula duracion de cada camino y lo guarda en un map(camino,duracion)
		for (List<Vertice<Planta>> camino : listaCaminosPosible) {
			Double cont=0.0;
			for (int tam=camino.size();tam>=2;tam--) {
				Vertice<Planta> vUltimo=camino.get(tam-1);
				Vertice<Planta> vAnterior=camino.get(tam-2);
				
				Arista<Planta> arista = this.buscarArista(vAnterior, vUltimo);
				
				cont+=arista.getDuracionDelViaje();
			}
			caminosYduracion.put(camino, cont);
		}

		while (!listaPlantas.isEmpty()) {
			Double cont2=Double.MAX_VALUE;
		
			for (Map.Entry<List<Vertice<Planta>>, Double> c : caminosYduracion.entrySet()) {
				for (Vertice<Planta> planta : listaPlantas) {
					if (c.getKey().contains(planta)) {
						if (c.getValue()<cont2) {
							caminoMasCorto=c.getKey();
							cont2=c.getValue();
						}
					}
				}
			}
			listaCaminosFinal.add(caminoMasCorto);
			for (Vertice<Planta> planta : listaPlantas) {
				if (caminoMasCorto.contains(planta))
					aRemover.add(planta);
			}
			listaPlantas.removeAll(aRemover);
		}
		
		return listaCaminosFinal; 
	}
	
	
	
	public List<Vertice<Planta>> ordenarPorPageRank(){						//20190808-1857  hicimos un metodo nuevo usando Stream
		List<Vertice<Planta>> resultado = new ArrayList<>();
		List<Vertice<Planta>> plantasAOrdenar = this.getVertices();
		for(Vertice<Planta> p : plantasAOrdenar) p.setGradoEntrada(this.gradoEntrada(p));
		ComparadorPageRank comp = new ComparadorPageRank();
		resultado = plantasAOrdenar.stream().sorted(comp).collect(Collectors.toList());
		//System.out.println("Resultadp PageRank metodo:"+resultado);
		return resultado;
	}


//Parte 5- 1)
	public Double calcularFlujoMaximo () {	//Agu/20190808-1645 arregle el metodo calcularFlujoMax
		Double flujoMaximo=0.0;	
		if (this.getPlantaPuerto()!=null) {
			GrafoPlanta grafoCopia = this.duplicarGrafo();
			boolean posibleRecorrer = true;
			
			Vertice<Planta> vActual = grafoCopia.getPlantaPuerto();
			Vertice<Planta> vSiguiente = new Vertice<Planta>();
			Arista<Planta> aristaCandidata = new Arista<Planta>();
			
			List<Arista<Planta>> aristasModificar = new ArrayList<>();
			List<Double> totalPesos = new ArrayList<>();
			
			Double maxPeso=0.0;
			Double minPeso=Double.MAX_VALUE;
			
			int i=0;
			while(posibleRecorrer) {
				i++;
				System.out.println("iteracion "+i+": "+flujoMaximo);
				System.out.println("valor vertice actual: "+vActual.toString());
				//obtengo el camino con mayor capacidad
				for (Vertice<Planta> adya : grafoCopia.getAdyacentes(vActual)){
					Arista<Planta> arista = grafoCopia.buscarArista(vActual, adya);
					
					if (arista.getPesoMaximoCamino()>0) {
						if (arista.getPesoMaximoCamino()>maxPeso) {
							maxPeso = arista.getPesoMaximoCamino();
							vSiguiente = adya;
							aristaCandidata = arista;
						}
					}
				}
				//si es nulo, quiere decir que no encontro un camino mayor a 0
				if (!(vSiguiente==null)) {
					//agreego arista que se selecciono para luego restarle el peso minimo del camino
					aristasModificar.add(aristaCandidata);
					
					//si el vertice siguiente a evaluar es el acopio final, entonces significa que ya termino el camino y debo restar peso minimo obtenido a las aristas que fui visitando
					if (vSiguiente.equals(grafoCopia.getPlantaAcopioFinal())) {
						totalPesos.add(maxPeso);
						
						//obtengo peso minimo del camino realizado
						for (Double p : totalPesos) {
							if(p<minPeso)
								minPeso=p;
						}
						//recorro primero la lista de aristas que visite, luego recorro las aristas de mi grafo y por ultimo encuentro con cual coincide para restarle peso
						for (Arista<Planta> aristaABorrar : aristasModificar) {
							for(Arista<Planta> aristaOriginal : grafoCopia.getAristas()) {
								if (aristaABorrar.equals(aristaOriginal)) 
									aristaOriginal.setPesoMaximoCamino(aristaOriginal.getPesoMaximoCamino()-minPeso);
							}
						}

						totalPesos.clear();
						aristasModificar.clear();

						vActual=grafoCopia.getPlantaPuerto();
						vSiguiente=null;
						aristaCandidata=null;

						flujoMaximo=flujoMaximo+minPeso;
						
						minPeso=Double.MAX_VALUE;
						maxPeso=0.0;
					} else { //agrego el siguiente vertice a evaluar y agrego el peso
						//System.out.println("valor de max: "+max);
						aristaCandidata=null;
						vActual=vSiguiente;
						vSiguiente=null;
						totalPesos.add(maxPeso);
						maxPeso=0.0;
					}
				} else 
					posibleRecorrer=false;
			}
			grafoCopia.resetGrafo();
		}
		return flujoMaximo;
	}
		
	public GrafoPlanta duplicarGrafo() {
			GrafoPlanta grafoCopia = new GrafoPlanta();
			List<Arista<Planta>> aristasCopia = new ArrayList<>();
			List<Vertice<Planta>> verticesCopia = new ArrayList<>();
			
			//Vertice<T> ini,Vertice<T> fin,Number val,Double dist,Integer durViaje,Double pesoMax
			for (Arista<Planta> arista : this.getAristas()) {
				Arista<Planta> aristaAgregar = new Arista<>(arista.getInicio(),arista.getFin(),arista.getValor(),arista.getDistancia(),arista.getDuracionDelViaje(),arista.getPesoMaximoCamino());
				aristasCopia.add(aristaAgregar);
			}
			//T v
			for (Vertice<Planta> vertice : this.getVertices()) {
				Vertice<Planta> verticeAgregar = new Vertice<>(vertice.getValor());
				verticesCopia.add(verticeAgregar);
			}
			
			grafoCopia.setAristas(aristasCopia);
			grafoCopia.setVertices(verticesCopia);
			//grafoCopia.setPlantaPuerto();
			//grafoCopia.setPlantaAcopioFinal();
			
			return grafoCopia;
	}
	
	public void resetGrafo () {
		List<Arista<Planta>> aristasReset = new ArrayList<>();
		List<Vertice<Planta>> verticesReset = new ArrayList<>();
		
		this.setAristas(aristasReset);
		this.setVertices(verticesReset);
	//	this.setPlantaPuerto();
	//	this.setPlantaAcopioFinal();
	}
	public void resetGrafo2() {  //Agu, aca hace lo mismo pero limpiando las listas originales con clear
		
		this.getAristas().clear();
		this.getVertices().clear();
		//this.setPlantaPuerto();
		//this.setPlantaAcopioFinal();
	}
}


		

