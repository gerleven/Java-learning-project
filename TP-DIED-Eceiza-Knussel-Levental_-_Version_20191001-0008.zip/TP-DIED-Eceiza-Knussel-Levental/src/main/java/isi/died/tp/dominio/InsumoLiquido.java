package isi.died.tp.dominio;

public class InsumoLiquido extends Insumo{
	
	//atributos
	public Double densidad;
	
	//constructor
	public InsumoLiquido(Integer id, String nombre, Double costo, Boolean esRefrigerado, Double densidad){
		super(id, nombre, UnidadDeMedida.LITRO, costo, esRefrigerado);
		this.densidad = densidad;
		this.peso = this.calcularPeso();
	}
	
	public InsumoLiquido(Integer id, String nombre, UnidadDeMedida unidad, Double costo, Boolean esRefrigerado, Double densidad){
		super(id, nombre, UnidadDeMedida.LITRO, costo, esRefrigerado);
		this.densidad = densidad;
		this.peso = this.calcularPeso();
	}
	
	public Double calcularPeso() {
		Double peso = ((super.cantidadEnStockDePlanta)*0.001* this.densidad); //En la version final del TP final los insumos empiezan teniendo una "cantidadStock"=0 hasta que un Stock le asigne un valor diferente
		//System.out.println("                                                      Peso de este liquido: "+peso);
		return peso;  
		//gl_31/07-18:58hs -> cambio el Insumo.stock por el "super.cantidadEnStockDePlanta"
	}
	
	//Getters and Setters:
		
	public Double getDensidad() {
		return densidad;
	}

	public void setDensidad(Double densidad) {
		this.densidad = densidad;
	}
	
	//Metodos:
	public void print() {
		System.out.println(this.getPrint());
	}

	public String getPrint() {
		String print =super.getPrint()+" Densidad: "+this.getDensidad().toString()+" (Es Insumo Liquido)."; 
		return print; 
		
	}
	
	public String toString() {  //Ger 2019/08/20. agregue el toString por si se usa en algun sysout
		String print =super.getPrint()+" Densidad: "+this.getDensidad().toString()+" (Es Insumo Liquido).\n"; 
		return print; 
		
	}
}
