package isi.died.tp.dominio;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import isi.died.tp.estructuras.InsumoPesoValor;
import isi.died.tp.estructuras.InsumoPesoValorInteger;

public class Planta {
	
	//ATRIBUTOS
	private String nombre;
	private Integer idPlanta;
	private List<Stock> listaStock; 
	
	//GETTERS AND SETTERS
	public Integer getIdPlanta() {
		return idPlanta;
	}
	public void setIdPlanta(Integer id) {
		this.idPlanta = id;
	}
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre1) {
		nombre = nombre1;
	}
	
	//gl_27/07->
	public List<Stock> getListaStock(){
		return listaStock;
	}
	
	public void setListaStock(List<Stock> listaStock1) {
		listaStock=listaStock1;
	}
	
	//CONSTRUCTORES
		//gl_27/07->
		//sin stock
		public Planta() {
		}
		public Planta(Integer id, String nombre) {
			setIdPlanta(id);
			setNombre(nombre);
			setListaStock(new ArrayList<Stock>()); //Ger:05/08/2019 correccion para AgregarStock

		}
		
		//con la lista de stock
		public Planta(Integer id, String nombre, List<Stock> listaStock) {
			this(id, nombre);
			setListaStock(listaStock);
		}
		//<-gl_27/07
		
	//METODOS	
		
		public void agregarAStock(Stock s) {
			this.listaStock.add(s);
		}
		
		public String toString() {
			return this.get_Nombre_Id();
		}
		
		public void print() {
			System.out.println(this.getPrint());
		}
		
		public String getPrint() {
			String print = this.get_Nombre_Id();
				return print; 
		}
		
		public String get_Nombre_Id() {
			return this.getNombre().toString()+"(id:"+this.getIdPlanta().toString()+")";
		}
		
	//Agu taller 4:
	
	//a)
	//Calcula el costo que resulta de sumar el costo de cada insumo que esa planta tiene en su stock. es decir que usar el Stock.cantidad de ese insumo y no el Inusmo.stock
	public Double costoTotal() {
		return (listaStock.stream().distinct().mapToDouble((s)->s.getInsumo().getCosto()*s.getCantidad()).sum());	
	}
	
	//b)
	//obtiene todos los insumos de esa planta cuyo Stock.cantidad en planta sea entre s1 y s2
	public List<Insumo> stockEntre(Integer s1,Integer s2) {
		return listaStock.stream()
				.filter(s->s.getCantidad()>=s1 && s.getCantidad()<=s2 )
				.map(s-> s.getInsumo())
				.collect(Collectors.toList());
	}
	
	//c)
	//retorna verdadero si el insumo i, en el stock disponible en planta se encuentra debajo del punto de pedido
	/*
	public Boolean necesitaInsumo(Insumo i) {																	//GeryBelu20190816-1557_corregimos el get(0) para que primero se fije si la lista que quedo vacia antes de hace rel get(0) porque si no tira error
		List<Stock> s1=new ArrayList<>();
		
		s1=listaStock.stream().filter(s->s.getInsumo().equals(i)).collect(Collectors.toList());
		if(!s1.isEmpty() && s1.get(0).getCantidad() >= s1.get(0).getPuntoPedido()) 
			return true;
		return false; //Retorna true si no tiene le insumo o si lo tiene pero esta por debajo del punto de pedido
	}
	*/
	
	public Boolean necesitaInsumo(Insumo i) {//intente diferentes formas de obtener plantas que necesitan insumo pero sigue tirando mismo error de ConcurrentModification
		//List<Stock> s1=new ArrayList<>();
		
		for (Stock stock : this.getListaStock()) {
			if (stock.getInsumo().equals(i))
				if (stock.getCantidad() < stock.getPuntoPedido())
					return true;
		}
		return false;
		
		/*s1=listaStock.stream().filter(s->s.getInsumo().equals(i)).collect(Collectors.toList());
		if (!s1.isEmpty()) {
			for (int j=0;j<s1.size()-1;j++) {
				if (s1.get(j).getCantidad() < s1.get(j).getPuntoPedido())
					return true;
			}
		}
		return false;*/
		
		/*if(!s1.isEmpty() && s1.get(0).getCantidad() < s1.get(0).getPuntoPedido()) 
			return true;
		return false;*/
	}
	
	public List<InsumoPesoValor> ipvFaltantesEnPlanta(){ //retorna una lista con informacion de que cantidad en peso de cada insumo esta faltando en esa planta
		List<InsumoPesoValor> listaIPVEnEstaPlanta = new ArrayList<>(); //IPV = InsumoPesoValor
		for(Stock s : this.getListaStock()) {
			if(s.getCantidad()<s.getPuntoPedido()) {
				Insumo insumo = s.getInsumo();
				Double pesoFaltante = (s.getPuntoPedido()-s.getCantidad())*s.getInsumo().getPeso();
				Double valorFaltante = (s.getPuntoPedido()-s.getCantidad())*s.getInsumo().getCosto();
				listaIPVEnEstaPlanta.add(new InsumoPesoValor(insumo,pesoFaltante,valorFaltante));
				System.out.println("Se agrega el ipv "+insumo+" con una cnatidad faltante de "+pesoFaltante+" y un valor faltante de "+valorFaltante+".\n");
			}
			
		}
		//System.out.println("Testing metodo insumosFaltantesEnPlantaYPeso() en la clase Planta:"+listaInsumosPesoFaltantesEnEstaPlanta);
		return listaIPVEnEstaPlanta;
	}
	
	public List<InsumoPesoValorInteger> ipvIntegerFaltantesEnPlanta(){ //retorna una lista con informacion de que cantidad en peso de cada insumo esta faltando en esa planta
		List<InsumoPesoValorInteger> listaIPVEnEstaPlanta = new ArrayList<>(); //IPV = InsumoPesoValor
		for(Stock s : this.getListaStock()) {
			if(s.getCantidad()<s.getPuntoPedido()) {
				Integer cantidadFaltante = s.getPuntoPedido()-s.getCantidad();
				Insumo insumo = s.getInsumo();
				Integer pesoFaltante = (int) Math.round(((cantidadFaltante)*(s.getInsumo().getPeso()))); //Aca deberia haber un IF que si es liquido calcule el peso como cantidadFaltante * s.getInsumo().getDensidad() pero es imposible porque segun el enunciado la densidad solo es un atirbuto de Insumo liquido que setea el peso en funcion de la cantidad, y la cantidad no la sabes hasta no fijar el Stock, es un bucle sin salida, en definitiva el atributo densidad no persiste dentro de la clase Insumo (solo en InusmoLiquido pero muere en el momento)
				Integer valorFaltante = (int) Math.round(((cantidadFaltante)*(s.getInsumo().getCosto())));
				listaIPVEnEstaPlanta.add(new InsumoPesoValorInteger(insumo,pesoFaltante,valorFaltante));
				System.out.println("Se agrega el ipv "+insumo+" con una cnatidad faltante de "+pesoFaltante+" y un valor faltante de "+valorFaltante+".\n");
			}
			
		}
		//System.out.println("Testing metodo insumosFaltantesEnPlantaYPeso() en la clase Planta:"+listaInsumosPesoFaltantesEnEstaPlanta);
		return listaIPVEnEstaPlanta;
	}
	
	public List<Insumo> insumosFaltantesEnPlanta2() {
		List<Insumo> listaInsumosFaltantesEnEstaPlanta = new ArrayList<>();
		for(Stock s : this.getListaStock()) {
			if(s.getCantidad()<s.getPuntoPedido()) {
				listaInsumosFaltantesEnEstaPlanta.add(s.getInsumo());
			}
			
		}
		return listaInsumosFaltantesEnEstaPlanta;
	}
	
	public Boolean equals(Planta otra) {
		return this.getIdPlanta()==otra.getIdPlanta();
	}
	
}
