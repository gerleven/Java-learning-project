package isi.died.tp.estructuras;



public class Arista<T> {
	private Vertice<T> inicio;
	private Vertice<T> fin;
	private Number valor; //lo usamos como id
	private Double distancia; //Km
	private Integer duracionDelViaje; //minutos
	private Double pesoMaximoCamino; //toneladas
	
	
	//Constructores
	public Arista(){
		valor=1.0;
		distancia = 0.0;
		duracionDelViaje = 0;
		pesoMaximoCamino = 0.0; //esto hay que ponerlo para que no de NullPointerException
	} 
	
	public Arista(Vertice<T> ini,Vertice<T> fin){
		this();
		this.inicio = ini;
		this.fin = fin;
	}

	public Arista(Vertice<T> ini,Vertice<T> fin,Number val,Double dist,Integer durViaje,Double pesoMax){
		//this(ini,fin); //lo saque para que no haga doble asignacion de valor distancia durecion y peso
		this.inicio = ini;
		this.fin = fin;
		this.setValor(val);
		this.setDistancia(dist);
		this.setDuracionDelViaje(durViaje);
		this.setPesoMaximoCamino(pesoMax);
	}
	
	
	//Getters and Setters
	public Vertice<T> getInicio() {
		return inicio;
	}
	
	public void setInicio(Vertice<T> inicio) {
		this.inicio = inicio;
	}
	
	public Vertice<T> getFin() {
		return fin;
	}
	
	public void setFin(Vertice<T> fin) {
		this.fin = fin;
	}

	public Number getValor() {
		return valor;
	}

	public void setValor(Number valor) {
		this.valor = valor;
	}
	
	public Double getDistancia() {
		return distancia;
	}

	public void setDistancia(Double distancia) {
		this.distancia = distancia;
	}

	public Integer getDuracionDelViaje() {
		return duracionDelViaje;
	}

	public void setDuracionDelViaje(Integer duracionDelViaje) {
		this.duracionDelViaje = duracionDelViaje;
	}

	public Double getPesoMaximoCamino() {
		return pesoMaximoCamino;
	}

	public void setPesoMaximoCamino(Double pesoMaximoCamino) {
		this.pesoMaximoCamino = pesoMaximoCamino;
	}
	//Metodos
	@Override
	public String toString() {
		return "( "+this.inicio.getValor()+" --> "+this.fin.getValor()+" )";
	}
	
	@Override
	public boolean equals(Object obj) {
		return (obj instanceof Arista<?>) && ((Arista<?>)obj).getValor().equals(this.getValor()); 
	}
}