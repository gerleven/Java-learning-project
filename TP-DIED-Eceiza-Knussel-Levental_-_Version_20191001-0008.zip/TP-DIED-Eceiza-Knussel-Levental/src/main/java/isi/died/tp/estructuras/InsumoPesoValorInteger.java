package isi.died.tp.estructuras;

import isi.died.tp.dominio.Insumo;

public class InsumoPesoValorInteger {

	private Insumo insumo;
	private Integer pesoFaltante; //un estock tiene una cantidad de insumo y una cantidad faltante, pesoFaltante es lo que pesa esa cantidad que falta
	private Integer valorFaltante; //valor de la cantidad que falta

	//Constructor
	public InsumoPesoValorInteger(Insumo insumo, Integer pesoFaltante, Integer valor){
		this.insumo=insumo;
		this.pesoFaltante=pesoFaltante;
		this.valorFaltante=valor;
	}
	
	//Getters and Setters
	public Insumo getInsumo() {
		return insumo;
	}
	public void setInsumo(Insumo insumo) {
		this.insumo = insumo;
	}
	public Integer getPesoFaltante() {
		return pesoFaltante;
	}
	public void setPesoFaltante(Integer cantidad) {
		this.pesoFaltante = cantidad;
	}
	
	public Integer getValorFaltante() {
		return valorFaltante;
	}
	public void setValorFaltante(Integer cantidad) {
		this.valorFaltante= cantidad;
	}
	
	//Metodos
	public void sumarPesoFaltante(Integer peso) {
		this.setPesoFaltante(this.getPesoFaltante()+peso);
	}
	
	public void sumarValorFaltante(Integer valor) {
		this.setValorFaltante(this.getValorFaltante()+valor);
	}
	
	
	public Integer getIdDelInsumo() {
		return this.getInsumo().getIdInsumo();
	}

	public String toString() {
		return "(Insumo: "+this.getInsumo().get_Nombre_Id().toString()+" - Peso faltante: "+this.getPesoFaltante().toString()+" Valor faltante: "+this.getValorFaltante()+")\n";
	}
}
