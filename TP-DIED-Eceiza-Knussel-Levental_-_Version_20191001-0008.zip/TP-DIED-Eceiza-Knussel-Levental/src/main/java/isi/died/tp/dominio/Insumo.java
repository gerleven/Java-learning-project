package isi.died.tp.dominio;

import java.util.List;

import isi.died.tp.estructuras.Grafo;
import logica.Logica;

public class Insumo implements Comparable<Insumo>{ //Creo que ya no deberia ser mas comparable porque le vamos a pasar el compareTo por parametro con una funcion lambda
	
	//INSUMO corregido (Insumo_viejo es la vieja)
	//Atributos
	protected Integer idInsumo;
	protected String nombre; //Descripcion
	protected UnidadDeMedida unidad_de_medida;
	protected Double costo;
	protected Double peso; //Kg
	protected Boolean esRefrigerado;
	protected Integer cantidadEnStockDePlanta; //empieza siendo 0
	protected Stock stockQueMeContiene;
	//elimine el Integer stock; que en este TP ya no se usa mas.
	//Agregar aca un puntero a Stock para poder calcular el stock total de un insumo en todas las plantas, puede ser bidireccional
	//protected List<Stock> listaStock; //Deberia ser una Lista de stocks en los que hay de este insumo, ver como lo implementamos
	//Si no se puede borrar esta lista y recorrer todas las plantas.stock y listo
	
	//Geters and Setters
	public Integer getIdInsumo() {
		return idInsumo;
	}
	public void setIdInsumo(Integer id) {
		this.idInsumo = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public UnidadDeMedida getUnidad_de_medida() {
		return this.unidad_de_medida;
	}
	public void setUnidad_de_medida(UnidadDeMedida unidad_de_medida) {
		this.unidad_de_medida = unidad_de_medida;
	}
	public Double getCosto() {
		return costo;
	}
	public void setCosto(Double costo) {
		this.costo = costo;
	}
	public Double getPeso() {
		return peso;
	}
	public void setPeso(Double peso) {
		this.peso = peso;
	}
	public Boolean getEsRefrigerado() {
		return esRefrigerado;
	}
	public void setEsRefrigerado(Boolean esRefrigerado) {
		this.esRefrigerado = esRefrigerado;
	}
	public Integer getCantidadEnStockDePlanta() {
		return this.cantidadEnStockDePlanta;
	}
	public void setCantidadEnStockDePlanta(Integer cantidadEnStockDePlanta) {
		this.cantidadEnStockDePlanta=cantidadEnStockDePlanta;
	}
	public Stock getStockQueMeContiene() {
		return this.stockQueMeContiene;
	}
	public void setStockQueMeContiene(Stock s) {
		this.stockQueMeContiene=s;
	}
	

	//constructores
	public Insumo() {};
	//Sin peso: usado en Insumo liquido por "super(id, descripcion, unidad, costo, stock, esRefrigerado);"
	public Insumo(Integer id, String nombre, UnidadDeMedida unidadDeMedida, Double costo, Boolean esRefrigerado ) {
		//gl28/07>
		setIdInsumo(id);
		setNombre(nombre);
		setUnidad_de_medida(unidadDeMedida);
		setCosto(costo);
		setEsRefrigerado(esRefrigerado);
		//gl28/07<
		this.cantidadEnStockDePlanta=0;
	}
	//con peso, para insumos no loquidos
	public Insumo(Integer id, String nombre, UnidadDeMedida unidadDeMedida, Double costo, Double peso, Boolean esRefrigerado ) {
		//gl28/07>
		this(id, nombre, unidadDeMedida, costo, esRefrigerado);
		setPeso(peso);
		//gl28/07<		
	}

	
	//METODOS
	public int compareTo(Insumo otroInsumo) {
		return ((int)this.getStockTotalEnPlantas()-(int)otroInsumo.getStockTotalEnPlantas());	//borre el casteo (int) porque stock ya es de tipo int
	}
	
	public Integer getStockTotalEnPlantas() { //Recorrienod el Stock de cad auna de las plantas
		//Completar
		Integer acumulador=0;
		List<Planta> listaDePlanta=Logica.grafoDePlantas.recorridoTopologico();
		for(Planta p: listaDePlanta) { //no se por que no me deja hacer el metodo eso, dice que solo final y no se que...
			for(Stock s : p.getListaStock()) {
				if(s.getInsumo().equals(this)) acumulador+=s.getCantidad();
				//se podria hacer tamabien con un Stream
			}
		}
		return acumulador;
	}
	
	public void print() {
		System.out.println(this.getPrint());
	}
	
	
	public String getPrint() {
		//return "listo!";
		String print = 
				//"idInsumo: "+this.getIdInsumo().toString()+" nombre: "+this.getNombre()
			this.get_Nombre_Id()
		+" UnidadDeMedida: "+this.getUnidad_de_medida().toString()
		+" costo: "+this.getCosto().toString()
		+" peso: "+this.getPeso().toString()+((this.getEsRefrigerado())?" (Es Refrigerado)":" (No es Refrigerado)"); 
		return print; 
	}
	
	public String get_Nombre_Id() {
		return this.getNombre().toString()+"(id:"+this.getIdInsumo().toString()+")";
	}
	
	public String toString() {
		String stock = this.getCantidadEnStockDePlanta().toString();
		return this.getNombre()+"(id: "+this.getIdInsumo().toString()+
				" unidadDeMedida: "+this.getUnidad_de_medida()+
				" costo: "+this.getCosto().toString()+
				" peso: "+this.getPeso().toString()+
				" esRefrigerado: "+this.getEsRefrigerado().toString()+
				" stock: "+stock+
				").\n";
	}
	
}
