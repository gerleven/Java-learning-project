package isi.died.tp.dominio;

public class Camion {
	//gl2807>
	//Atributos
	private Integer idCamion;
	private String marca;
	private String modelo;
	private Integer dominio;  
	private Integer anio;
	private Double costoPorKm;
	private Boolean aptoLiquidos;
	private Double capacidad;
	
	
	//Getters and Setters:
	public Integer getIdCamion() {
		return idCamion;
	}
	public void setIdCamion(Integer idCamion) {
		this.idCamion = idCamion;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public Integer getDominio() {
		return dominio;
	}
	public void setDominio(Integer dominio) {
		this.dominio = dominio;
	}
	public Integer getAnio() {
		return anio;
	}
	public void setAnio(Integer anio) {
		this.anio = anio;
	}
	public Double getCostoPorKm() {
		return costoPorKm;
	}
	public void setCostoPorKm(Double costoPorKm) {
		this.costoPorKm = costoPorKm;
	}
	public Boolean getAptoLiquidos() {
		return aptoLiquidos;
	}
	public void setAptoLiquidos(Boolean aptoLiquidos) {
		this.aptoLiquidos = aptoLiquidos;
	}
	public Double getCapacidad() {
		return capacidad;
	}
	public void setCapacidad(Double capacidad) {
		this.capacidad = capacidad;
	}
	
	
	//Constructores:
	public Camion(Integer idCamion, String marca, String modelo, Integer dominio, Integer anio, Double d,Boolean aptoLiquidos, Double e) {
		setIdCamion(idCamion);
		setMarca(marca);
		setModelo(modelo);
		setDominio(dominio);
		setAnio(anio);
		setCostoPorKm(d);
		setAptoLiquidos(aptoLiquidos);
		setCapacidad(e);
	}
	
	
	//Metodos:
	public String toString() {
		return "\nIdCamion: "+this.getIdCamion()+" - costo por peso: "+this.getCostoPorKm()+" capacidad: "+this.getCapacidad()+(this.getAptoLiquidos()?" Apto para liquidos":" No apto para liquidos");
	}
	
	public void imprimirCamion() {
		System.out.println(this.toString());
	}
	
	public String getDominioId() {
		return "Id-"+this.getIdCamion().toString()+" dominio-"+this.getDominio().toString()+".";
	}
}
