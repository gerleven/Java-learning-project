package isi.died.tp.estructuras;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public abstract class Arbol<E extends Comparable<E>> {


	protected E valor;

	public abstract List<E> preOrden();

	public abstract List<E> inOrden();

	public abstract List<E> posOrden();

	public abstract boolean esVacio();

	public abstract E valor();

	public abstract Arbol<E> izquierdo();

	public abstract Arbol<E> derecho();
	
	public abstract boolean contiene(E unValor);

	public abstract boolean equals(Arbol<E> unArbol);
	
	public abstract void agregar(E a);
	
	public abstract void agregarPorCriterio(E a, Comparator<E> comp); //Ger-20190808-0246

	public abstract int profundidad();

	public abstract int cuentaNodosDeNivel(int nivel);

	public abstract boolean esCompleto();

	public abstract boolean esLleno();
	
	public abstract ArrayList<E> rangoAux(int inicio,int fin,ArrayList<E> lista);

	
	//metodo para poder imprimir el arbol en tareas de testing 
		public String valorString() {
			if(this.valor == null){
				return "-";
			}else {
				return String.valueOf(this.valor);
			}
		}
	
}