package isi.died.tp.estructuras;

import java.util.List;

import isi.died.tp.dominio.Insumo;

public class InsumoPesoValor { //

	private Insumo insumo;
	private Double pesoFaltante; //un estock tiene una cantidad de insumo y una cantidad faltante, pesoFaltante es lo que pesa esa cantidad que falta
	private Double valorFaltante; //valor de la cantidad que falta

	//Constructor
	public InsumoPesoValor(Insumo insumo, Double pesoFaltante, Double valor){
		this.insumo=insumo;
		this.pesoFaltante=pesoFaltante;
		this.valorFaltante=valor;
	}
	
	//Getters and Setters
	public Insumo getInsumo() {
		return insumo;
	}
	public void setInsumo(Insumo insumo) {
		this.insumo = insumo;
	}
	public Double getPesoFaltante() {
		return pesoFaltante;
	}
	public void setPesoFaltante(Double cantidad) {
		this.pesoFaltante = cantidad;
	}
	
	public Double getValorFaltante() {
		return valorFaltante;
	}
	public void setValorFaltante(Double cantidad) {
		this.valorFaltante= cantidad;
	}
	
	//Metodos
	public void sumarPesoFaltante(Double peso) {
		this.setPesoFaltante(this.getPesoFaltante()+peso);
	}
	
	public void sumarValorFaltante(Double valor) {
		this.setValorFaltante(this.getValorFaltante()+valor);
	}
	
	
	public Integer getIdDelInsumo() {
		return this.getInsumo().getIdInsumo();
	}

	public String toString() {
		return "(Insumo: "+this.getInsumo().get_Nombre_Id().toString()+" - Peso faltante: "+this.getPesoFaltante().toString()+" Valor faltante: "+this.getValorFaltante()+")\n";
	}
	
}
