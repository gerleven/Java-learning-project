package isi.died.tp.dominio;

public enum UnidadDeMedida {
	KILO, PIEZA, GRAMO, METRO, LITRO, M3, M2
}

//Day dia1 = Day.LUNES;