package Parte5Ventanas;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
//import java.awt.List
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Editar.EditarInsumo;
import Graphic.Buscar.ResultadosBusquedaInsumo;
import Graphic.Buscar.VentanaBuscar;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import isi.died.tp.dominio.*;
import isi.died.tp.estructuras.InsumoPesoValor;
import isi.died.tp.estructuras.InsumoPesoValorInteger;
import logica.Logica;
import logica.Parte05;

import javax.swing.JTextField;


public class MejorViaje extends JFrame {

	public static Camion camionSelected;

	private JPanel contentPane;
	private JTable tablaResultado;
	public 	ArrayList<Insumo> insumos = new ArrayList<Insumo>();
	private JTable table;
	private JTextField liquidoValor;
	private JTextField costokmValor;
	private JTextField capacidadValor;
	private JTextField anioValor;
	private JTextField dominioValor;
	private JTextField modeloValor;
	private JTextField marcaValor;
	private JTextField idValor;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MejorViaje frame = new MejorViaje();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void cargarTabla() {
		//System.out.println("borrar el Logica.mochilaTest() de la linea 76!!");
		//Logica.mochilaTest();
		DefaultTableModel actualizado = (DefaultTableModel) table.getModel();
		actualizado.setRowCount(0);
		table.setVisible(true);
		
		//insumos = (ArrayList<Insumo>) Logica.listaInsumosIndustria;
		List<InsumoPesoValorInteger> insumosFaltantes = new ArrayList<>();
		//System.out.println("insumos faltantes antes del metodo Parte05.ipvFaltantes:\n"+insumosFaltantes);
		insumosFaltantes= Parte05.ipvFaltantesEnIndustria();
		//System.out.println("insumos DESPUES antes del metodo Parte05.ipvFaltantes:\n"+insumosFaltantes);
		if(insumosFaltantes.isEmpty()) {
			JOptionPane.showMessageDialog(null, "No se pudo obtener la lista de insumoPesoValorEnIndustria, por favor corrija los datos cargados ","¡Exito!", JOptionPane.WARNING_MESSAGE);
		}
		for(int i=0; i< insumosFaltantes.size(); i++) {
			String[] datos= new String [3];

			datos[0] = String.valueOf(insumosFaltantes.get(i).getInsumo().getNombre());
			datos[1] = insumosFaltantes.get(i).getPesoFaltante().toString();
			datos[2]= insumosFaltantes.get(i).getValorFaltante().toString();			
			actualizado.addRow(datos);
			
			
			/*
			 * //insumos = (ArrayList<Insumo>) Logica.listaInsumosIndustria;
		insumos = Parte05.insumosFaltantesCantidad();
		for(int i=0; i< insumos.size(); i++) {
			String[] datos= new String [3];

			datos[0] = String.valueOf(insumos.get(i).getIdInsumo());
			datos[1] = insumos.get(i).getNombre();
			//datos[2]= insumos.get(i).getUnidad_de_medida().toString();			
			actualizado.addRow(datos);
			 */
		}
	}
		
	
	
	public MejorViaje() {
		setTitle("Resultados de busqueda de insumos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 568);
		getContentPane().setLayout(null);

		setLocationRelativeTo(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 13, 424, 442);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Tahoma", Font.PLAIN, 15));
		table.setFillsViewportHeight(true);
		table.setSurrendersFocusOnKeystroke(true);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nombre-Id Insumo", "Peso faltante", "Valor"
			}
		));
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setAutoCreateRowSorter(true);
		scrollPane.setViewportView(table);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final Opciones a = new Opciones();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(719, 483, 97, 25);
		getContentPane().add(btnAtras);
		
		JLabel lblCamion = new JLabel("Seleccione camión:");
		lblCamion.setBounds(513, 14, 156, 16);
		getContentPane().add(lblCamion);
		
		JComboBox comboBox_camiones = new JComboBox();
		List<String> nombresCamiones = new ArrayList<>();
		List<Camion> camionesFiltrados = new ArrayList<>(Logica.listaCamiones);
		for(Camion c : camionesFiltrados) nombresCamiones.add(c.getDominioId());
		comboBox_camiones.setModel(new DefaultComboBoxModel(nombresCamiones.toArray()));
		comboBox_camiones.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//System.out.println("GoodChoice!");
				idValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()).getIdCamion().toString()); //revisar 
				anioValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()).getAnio().toString());
				dominioValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()).getDominio().toString());
				modeloValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()).getModelo().toString());
				marcaValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()).getMarca().toString());
				capacidadValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()).getCapacidad().toString());
				costokmValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()).getCostoPorKm().toString());
				Boolean b = camionesFiltrados.get(comboBox_camiones.getSelectedIndex()).getAptoLiquidos();
				String apto = b?"Si":"No";
				liquidoValor.setText(apto);
			}
		});
		comboBox_camiones.setBounds(513, 43, 171, 22);
		getContentPane().add(comboBox_camiones);
		
		JButton btnGenerarSolucion = new JButton("Generar solución");
		btnGenerarSolucion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Generando solucion:");
				MejorViaje.camionSelected = camionesFiltrados.get(comboBox_camiones.getSelectedIndex());
				System.out.println("Camion: "+camionSelected);
				
				Parte05.ipvFaltantesEnIndustria();
				Parte05.MejorEnvio(camionSelected);
				
				final Solucion a = new Solucion();
				a.setVisible(true);
				dispose();
				
			}
		});
		btnGenerarSolucion.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnGenerarSolucion.setBounds(537, 483, 156, 25);
		getContentPane().add(btnGenerarSolucion);
		
		JLabel lblInformacionDelCamin = new JLabel("Informacion del camión");
		lblInformacionDelCamin.setBounds(513, 116, 156, 16);
		getContentPane().add(lblInformacionDelCamin);
		
		JLabel lblId = new JLabel("Id:");
		lblId.setBounds(513, 160, 56, 16);
		getContentPane().add(lblId);
		
		JLabel lblMarca = new JLabel("Marca:");
		lblMarca.setBounds(513, 198, 56, 16);
		getContentPane().add(lblMarca);
		
		JLabel lblModelo = new JLabel("Modelo:");
		lblModelo.setBounds(513, 237, 56, 16);
		getContentPane().add(lblModelo);
		
		JLabel lblDominio = new JLabel("Dominio:");
		lblDominio.setBounds(513, 278, 56, 16);
		getContentPane().add(lblDominio);
		
		JLabel lblAo = new JLabel("Año:");
		lblAo.setBounds(513, 318, 56, 16);
		getContentPane().add(lblAo);
		
		JLabel lblCostoPorKm = new JLabel("Costo por Km:");
		lblCostoPorKm.setBounds(513, 357, 88, 16);
		getContentPane().add(lblCostoPorKm);
		
		JLabel lblAptoParaLquidos = new JLabel("Apto para líquidos:");
		lblAptoParaLquidos.setBounds(513, 396, 122, 16);
		getContentPane().add(lblAptoParaLquidos);
		
		JLabel lblCapacidad = new JLabel("Capacidad:");
		lblCapacidad.setBounds(513, 439, 106, 16);
		getContentPane().add(lblCapacidad);
		
		liquidoValor = new JTextField();
		liquidoValor.setEditable(false);
//		Boolean b = camionesFiltrados.get(comboBox_camiones.getSelectedIndex()+1).getAptoLiquidos();
//		String apto = b?"Si":"No";
//		liquidoValor.setText(apto);
		liquidoValor.setBounds(647, 393, 116, 22);
		getContentPane().add(liquidoValor);
		liquidoValor.setColumns(10);
		
		costokmValor = new JTextField();
		costokmValor.setEditable(false);
		//costokmValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()+1).getCostoPorKm().toString());
		costokmValor.setBounds(647, 354, 116, 22);
		getContentPane().add(costokmValor);
		costokmValor.setColumns(10);
		
		capacidadValor = new JTextField();
		capacidadValor.setEditable(false);
		//capacidadValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()+1).getCapacidad().toString());
		capacidadValor.setBounds(647, 436, 116, 22);
		getContentPane().add(capacidadValor);
		capacidadValor.setColumns(10);
		
		anioValor = new JTextField();
		anioValor.setEditable(false);
		//anioValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()+1).getAnio().toString());
		anioValor.setBounds(647, 315, 116, 22);
		getContentPane().add(anioValor);
		anioValor.setColumns(10);
		
		dominioValor = new JTextField();
		dominioValor.setEditable(false);
		//dominioValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()+1).getDominio().toString());
		dominioValor.setBounds(647, 275, 116, 22);
		getContentPane().add(dominioValor);
		dominioValor.setColumns(10);
		
		modeloValor = new JTextField();
		modeloValor.setEditable(false);
		//modeloValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()+1).getModelo().toString());
		modeloValor.setBounds(647, 234, 116, 22);
		getContentPane().add(modeloValor);
		modeloValor.setColumns(10);
		
		marcaValor = new JTextField();
		marcaValor.setEditable(false);
		//marcaValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()+1).getMarca().toString());
		marcaValor.setBounds(647, 195, 116, 22);
		getContentPane().add(marcaValor);
		marcaValor.setColumns(10);
		
		idValor = new JTextField();
		idValor.setEditable(false);
		//idValor.setText(camionesFiltrados.get(comboBox_camiones.getSelectedIndex()+1).getIdCamion().toString());
		idValor.setBounds(647, 157, 116, 22);
		getContentPane().add(idValor);
		idValor.setColumns(10);
		
		insumos = (ArrayList<Insumo>) Logica.listaInsumosIndustria;
		
		cargarTabla();
	}
}
