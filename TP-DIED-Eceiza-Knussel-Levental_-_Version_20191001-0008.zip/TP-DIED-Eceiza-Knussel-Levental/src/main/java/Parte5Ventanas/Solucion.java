package Parte5Ventanas;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Editar.EditarInsumo;
import Graphic.Buscar.BuscarInsumoCosto;
import Graphic.Buscar.BuscarInsumoNombre;
import Graphic.Buscar.BuscarInsumoStock;
import Graphic.Buscar.CriterioBusquedaInsumo;
import Graphic.Buscar.ResultadosBusquedaInsumo;
import isi.died.tp.dominio.Camion;
import isi.died.tp.dominio.Insumo;
import isi.died.tp.estructuras.InsumoPesoValor;
import isi.died.tp.estructuras.InsumoPesoValorInteger;
import logica.Logica;
import logica.Parte03;
import logica.Parte05;

public class Solucion extends JFrame {

	private JPanel contentPane;
	private JTable tablaResultado;
	public 	ArrayList<Insumo> insumos = new ArrayList<Insumo>();
	private JTable table;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Solucion frame = new Solucion();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
		
	public void cargarTabla() {
		DefaultTableModel actualizado = (DefaultTableModel) table.getModel();
		actualizado.setRowCount(0);
		table.setVisible(true);
		
		//insumos = (ArrayList<Insumo>) Logica.listaInsumosIndustria;
		List<InsumoPesoValorInteger> insumosFaltantes = new ArrayList<>();

		//Camion camionSeleccionado = Logica.listaCamiones.get(3); //reemplazar por el camion que selecciono el usuario
		
		insumosFaltantes= Parte05.MejorEnvio(MejorViaje.camionSelected);
		
		System.out.println("Insumos ipv faltantes: "+insumosFaltantes);
		
		for(int i=0; i< insumosFaltantes.size(); i++) {
			String[] datos= new String [3];

			datos[0] = String.valueOf(insumosFaltantes.get(i).getInsumo().getNombre());
			datos[1] = insumosFaltantes.get(i).getPesoFaltante().toString();
			datos[2]= insumosFaltantes.get(i).getValorFaltante().toString();			
			actualizado.addRow(datos);
			
			
		
		}
	}
	
	
	public Solucion() {
		setTitle("Resultados de busqueda de insumos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		getContentPane().setLayout(null);

		setLocationRelativeTo(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 13, 804, 444);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Tahoma", Font.PLAIN, 15));
		table.setFillsViewportHeight(true);
		table.setSurrendersFocusOnKeystroke(true);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nombre-Id Insumo", "Peso faltante", "Valor"
			}
		));
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setAutoCreateRowSorter(true);
		scrollPane.setViewportView(table);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final MejorViaje a = new MejorViaje();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setBounds(719, 470, 97, 25);
		getContentPane().add(btnAtras);
		
		
		cargarTabla();
	}
}
