package Parte5Ventanas;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import logica.Logica;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FlujoMaximo extends JFrame {

	private JPanel contentPane;
	private JTextField valor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FlujoMaximo frame = new FlujoMaximo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FlujoMaximo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 346);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null); //para centrar
		
		JLabel lblFlujoMximo = new JLabel("Flujo máximo");
		lblFlujoMximo.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblFlujoMximo.setBounds(31, 26, 227, 41);
		contentPane.add(lblFlujoMximo);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				valor.setText(null);
				final Opciones a = new Opciones();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.setBounds(719, 261, 97, 25);
		contentPane.add(btnAtras);
		
		JLabel lblValor = new JLabel("Valor [T]:");
		lblValor.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblValor.setBounds(265, 131, 79, 20);
		contentPane.add(lblValor);
		
		valor = new JTextField();
		valor.setEditable(false);
		valor.setBounds(398, 129, 116, 22);
		valor.setColumns(10);contentPane.add(valor);
		
		if (valor.getText().isEmpty()) 
			valor.setText(Logica.grafoDePlantas.calcularFlujoMaximo().toString());
		
	}

}
