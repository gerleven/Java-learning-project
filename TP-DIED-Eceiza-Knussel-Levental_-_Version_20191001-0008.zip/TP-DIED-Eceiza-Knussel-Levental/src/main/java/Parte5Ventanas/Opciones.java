package Parte5Ventanas;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import App.Bienvenido;
import Graphic.Agregar.VentanaAgregar;
import logica.Logica;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;

public class Opciones extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Opciones frame = new Opciones();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Opciones() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null); //para centrar
		
		JButton btnFlujoMximo = new JButton("Calcular Flujo Máximo");
		btnFlujoMximo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnFlujoMximo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final FlujoMaximo agregar= new FlujoMaximo();
				agregar.setVisible(true);
				dispose();
			}
		});
		btnFlujoMximo.setBounds(270, 130, 241, 25);
		contentPane.add(btnFlujoMximo);
		
		JButton btnOrdenPorPage = new JButton("Orden por Page Rank");
		btnOrdenPorPage.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnOrdenPorPage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final PageRank agregar= new PageRank();
				agregar.setVisible(true);
				dispose();
			}
		});
		btnOrdenPorPage.setBounds(270, 217, 241, 25);
		contentPane.add(btnOrdenPorPage);
		
		JButton btnMejorViaje = new JButton("Mejor Viaje");
		btnMejorViaje.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnMejorViaje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Logica.listaPlantasIndustria.isEmpty()
						||Logica.grafoDePlantas.getAristas().isEmpty()
						||Logica.grafoDePlantas.getVertices().isEmpty()
						||Logica.listaInsumosIndustria.isEmpty()
						||Logica.listaCamiones.isEmpty()
						||Logica.listaStocksIndustria.isEmpty()
						) {
					System.out.println("No, no se puede");
					JOptionPane.showMessageDialog(null, "Para el mejor envio se requiere previamente hacer una carga de datos automatica","¡Error!", JOptionPane.WARNING_MESSAGE);
				}
				else {
					System.out.println("\n\n\nEntrando a mejor envio\n\n\n");
					final MejorViaje agregar= new MejorViaje();
					agregar.setVisible(true);
					dispose();
				}
			}
		});
		btnMejorViaje.setBounds(270, 312, 241, 25);
		contentPane.add(btnMejorViaje);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				final Bienvenido a = new Bienvenido();
				a.setVisible(true);
				dispose();
			}
		});
		btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAtras.setBounds(688, 470, 114, 25);
		contentPane.add(btnAtras);
		
		JLabel lblEnvios = new JLabel("Envios");
		lblEnvios.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblEnvios.setBounds(32, 29, 182, 40);
		contentPane.add(lblEnvios);
	}

}
