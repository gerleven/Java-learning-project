package Parte5Ventanas;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Editar.EditarPlanta;
import Graphic.Buscar.ResultadosBusquedaPlanta;
import Graphic.Buscar.VentanaBuscar;
import isi.died.tp.dominio.Planta;
import isi.died.tp.estructuras.Grafo;
import isi.died.tp.estructuras.GrafoPlanta;
import isi.died.tp.estructuras.Vertice;
import logica.Logica;

public class PageRank extends JFrame {

		private JPanel contentPane;
		private JTable tablaResultado;
		public 	List<Vertice<Planta>> plantas = new ArrayList<Vertice<Planta>>();
		
		private JTable table;

		/**
		 * Launch the application.
		 */
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						PageRank frame = new PageRank();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}

		/**
		 * Create the frame.
		 */
		public void cargarTabla() {
			DefaultTableModel actualizado = (DefaultTableModel) table.getModel();
			actualizado.setRowCount(0);
			
			table.setVisible(true);
			plantas = Logica.grafoDePlantas.ordenarPorPageRank();
			
			for(int i=0; i< plantas.size(); i++) {
				String[] datos= new String [3];

				datos[0] = String.valueOf(plantas.get(i).getValor().getIdPlanta());
				datos[1] = plantas.get(i).getValor().getNombre();
				Vertice<Planta> v = new Vertice<Planta>();
				v.setValor(plantas.get(i).getValor());
			//	datos[2]= Grafo.gradoEntrada(v).toString(); //no funciona porque gradoEntrada no es static pero no quise mandar mano porque usa this
				System.out.println(plantas.get(i).getValor().getNombre());
				
				actualizado.addRow(datos);
				
			}
		}
			
		
		
		public PageRank() {
			setTitle("Plantas");
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(100, 100, 846, 555);
			getContentPane().setLayout(null);

			setLocationRelativeTo(null);
			
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(12, 13, 804, 444);
			getContentPane().add(scrollPane);
			
			table = new JTable();
			table.setFont(new Font("Tahoma", Font.PLAIN, 15));
			table.setVisible(false);
			table.setFillsViewportHeight(true);
			table.setSurrendersFocusOnKeystroke(true);
			table.setModel(new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
					"Id Planta", "Nombre Planta", "Caminos entrantes"
				}
			) {
				Class[] columnTypes = new Class[] {
					String.class, String.class, Object.class
				};
				public Class getColumnClass(int columnIndex) {
					return columnTypes[columnIndex];
				}
			});
			table.getColumnModel().getColumn(0).setResizable(false);
			table.getColumnModel().getColumn(1).setResizable(false);
			table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			table.setAutoCreateRowSorter(true);
			scrollPane.setViewportView(table);
			
			JButton btnAtras = new JButton("Atras");
			btnAtras.setFont(new Font("Tahoma", Font.PLAIN, 15));
			btnAtras.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					final Opciones a = new Opciones();
					a.setVisible(true);
					dispose();
				}
			});
			btnAtras.setBounds(719, 470, 97, 25);
			getContentPane().add(btnAtras);
			
			plantas = Logica.grafoDePlantas.ordenarPorPageRank();
			
			cargarTabla();
		}
	}