package App;

import java.util.List;

import javax.swing.JOptionPane;

import isi.died.tp.dominio.Insumo;
import isi.died.tp.estructuras.InsumoPesoValor;
import logica.Logica;

public class Bugs_Correcciones {
	

}

/*
ArbolBinarioDeBusqueda linea 104, metodo AgregarPorCriterio: llamaba recursivamente con agregar() en vez de con agregarPorCriterio
agregue ademas el cuerpo de la funcion como abstracto en Arbol y el metodo vacio en arbol vacio

BuscarInsumoCosto: linea 107, cambie busquedaAsc por busquedaDes
BuscarInsumoStock: idem

Parte03
linea 67: //Ger-20190808-0340  cambio la lista provisoria de insumos por la lista del sistema
linea 17: //Ger-20190808-0346 agregue la carga de datos que no estaba
linea 73: //Ger-20190808-0355_ saque el .get(0) porque en vaso de no encontrar el insumo daba puntero a null, ahora primero verifica
linea 21: //Ger-20190808-0358 agregue el Des(null) que no estaba

Logica:
linea 51: //Ger-20190808-0401_ cambie los nombres de los insumos a todo mayuscula

08/08/2019 14hs:
Agregue el paquete pantallaGrafo y el codigo del boton Aceptar de Agregar camion. ademas modifique la pantallita de agregar camion para borrar el campo id y ponerle los nombres de variables a cada cosa

Logica, linea 92 ://Ger_20190808-14545_ cambio id1 por Logica.GetNewId()
 
Grafo Planta:
linea 287: //20190808-1857  hicimos un metodo nuevo usando Stream

ToDo falta ver:
poner el boton de carga automatica primero arriba
retivar metodos agus y belu

################## German
14/08/2019
Clase AgregarCamiones: cambie los float por Doubles
Clace Camiones: floats por doubles en todos lados
Clase Logica: agrege la carga de comiones
Clase BuscarInsumoCosto: linea 11 y 120 cambie el metodo buscarstockAsc por costoAsc() 



TODO 20190814:
Belu:
agregar pantalla Beinvenido y la de gafo de la otra version//	LISTO 15-08-2019 01:42

------> hice andar las aristas del grafo!!



Ger y Belu:
implementar variables globales para la pantalla final de resultado de busqueda
Grafo: mostrar las aristas y solucionar el error que tira

Ger:
llamada con agu para pasar sus metodos nuevos a esta version

Parte05 mochila
*/




//Belen 15/8/2019 8:58
//agregue la arista al camino de esa manera puedo sacar la informacion del camino e imprimirla en el grafo				
//YA MUESTRA LA INFO DE LOS CAMINOS
//arregle la vista del grafo 	19:17
/*
		if(Bienvenido.cartelito) JOptionPane.showMessageDialog(null, "Se ha agregado con éxito","¡Exito!", JOptionPane.WARNING_MESSAGE);
		if(Bienvenido.cartelito) JOptionPane.showMessageDialog(null, "Debe completar todos los campos","¡Error!", JOptionPane.WARNING_MESSAGE);
		


Ger y Belu 16/08/2019
Corregimos el metodo necesitaInsumo de la clase Planta para que el get(0) no de error en caos de ser una lista vacia
agregamos lo de pintar los nodos de las plantas que necesitan un insumo
pintar aristas en los botones distancia y duracion de mejor camino en el grafo


###############################

Agu y Ger:
Arreglamos lo de flujo maximo (y algunas cargas de datos en logica)


Agu 17/08/2019
ver meodo de buscar panta que necesitan insumo porque no pinta las planta que necesitan la gaseosa
y mejor cmaino

##########################
18/08/2019
Ger:
hice el metodo verticesToAristasView(Insumo i){} que dado un insumo i devuelve la lista de AritstasView que se corresponde con el camino devuelto por el metodo mejorCaminoDistancia() y mejorCaminoDuracion() de la clase GrafoPlanta
camie la inicializacion de los vertices en GrafoPanel agregando un Switch para que cada vertice aparezca en la misma posicion que nuestro grafo de ejemplo y no tener que ordenarlo con DragAndDrop

##########################
19/08/2019 - Agu
Arregle metodo buscarPlantasFaltaInsumo, habia un error en metodo necesitaInsumo (estaba mal como se comparaba en el if) 
Borré metodo buscarPlantasFaltaInsumo_Viejo

##########################
20/08/2019 - Agu
Arregle metodos mejorCaminoDistancia y mejorCaminoDuracion
Cambie Logica en consecuencia de lo anterior (la parte de conectar las plantas)
Arregle Parte04

Corregi de EjecutarGrafo el boton "buscar" (que busca plantas que necesitan insumo)
Corregi de GrafoPanel del metodo verticesToAristasViewInsumo



*******************************
*Belen 20/08/2019
en parte03 hice que todos los metodos devuelvan listas
en las ventanas ResultadosBusquedaInsumo hice validaciones y aplique bariables globales de las clases:
	buscarInsumoCosto,buscarInsumoStock, buscarInsumoNombre
	tienen variables globales banderas que indican cuando la busqeuda es asc o des.
Las validaciones de ResultadosBusquedaInsumo no andan



#################################### 20/08/2019 Ger
Comente todos los SystemOytPrintLine de la clase Logica porque me molestaban (menos el ultimo que dice carga exitosa)
agregue los metodos "toString()" en varias clases como ser la de Camion, Planta, stock, InsumoLiquido,etc (ya no me acuerdo donde mas)

Clase planta:
agregue el metodo de equals: 
public Boolean equals(Planta otra) {
		return this.getIdPlanta()==otra.getIdPlanta();
	}
	
	
5-3a) Resumen: Agregue un metood nuevo en Planta, modifique la clase Parte05 y agregue 2 estructuras nuevas en el paquete de estructuras (InsumoCantidad y InsumoFaltantePorPlanta)

Chicos, cuando descarguen esta version usenla solo para sacar las cosas que yo medifique y pegarlas en la ultima version que ustedes tengan como se explica a continuacion:

En la clase Planta agreguen este metodo:
public List<InsumoCantidad> insumosFaltantesEnPlanta(){
		List<InsumoCantidad> listaInsumosFaltantesEnEstaPlanta = new ArrayList<>();
		InsumoCantidad ic = new InsumoCantidad();
		for(Stock s : this.getListaStock()) {
			if(s.getCantidad()<s.getPuntoPedido()) {
				ic.setInsumo(s.getInsumo());
				ic.setCantidad(s.getCantidad());
				listaInsumosFaltantesEnEstaPlanta.add(ic);
			}
			
		}
		return listaInsumosFaltantesEnEstaPlanta;
	}


En la Clase Parte05 borren todo el contenido (incluyendo imports y demas) y pegue el contenido entero de esta version
Agreguen ademas dentro del paquete de estructuras las 2 estructuras nuevas que cree: InsumoCantidad y InsumoFaltantePorPlanta

Nota: me imprime mal la solucion, debe ser un problema boludo pero no quiero perder tiempo ahora en encontrarlo porque mañana viajo y quizas agu lo encuentra facil, prefiero seguir avanzando porque mañana que viajo no se si voy a poder


5-3b)
en la clase Camion agregue el metodo toString() que imprime por consola un camion


##########################    21/08/2019 GER

*Comentes todos los sysoutprintLine de Logica que no servian mas

* Borre todo el contenido de la clase Parte05 y le pegue el de mi version que es la que estuve trabajando

*Agregue la Clase InsumoPesoFaltante al paquete de estructuras

*Clase Stock: agreue el metodo toString:

*Clase Planta: agregue los metodos:
public List<InsumoPesoFaltante> insumosFaltantesEnPlantaYPeso(){ 
public List<Insumo> inusmosFaltantesEnPlanta() {

*Insumo liquido: agreue el metodo toString(){} que no estaba

*Camion: agregue los metodos toString(), imprimirCamion() y getDominioId(). 
*MejorViaje:
complete el comboBox de camiones

################### 22/08/2019 GER
*InsumoLiquido: corregi el constructor, hice que la unidad de medida sea siempre UnidadDeMedida.LITRO
*Insumo:agregue un \n en el toString
*Stock: corregi el constructor para InsumosLiqudis agregando esta linea: this.insumo.setPeso(insumo.cantidadEnStockDePlanta*0.001* insumo.densidad);
termine la pantalla de mejor envio
avance con el meotodo de mejor envio de la parte05


############ Ger 27/08/2019
EjecutarGrafo: agregue esta validacion:
if(Logica.grafoDePlantas.getAristas().isEmpty()) {
						JOptionPane.showMessageDialog(null, "Aun no se cargaron los caminos! Grafo inexistente","¡Error!", JOptionPane.WARNING_MESSAGE);
						}
					else {

############
3/9/19

*Corregi ventanas "agregar":
		+agregue restricciones
		+mensajes de error/exito
		+habilitar/deshabilitar botones si selecciona "x" boton o no
*Corregi en ejecutarGrafo el boton reset y que muestre el peso maximo del camino en vez del peso total

*/