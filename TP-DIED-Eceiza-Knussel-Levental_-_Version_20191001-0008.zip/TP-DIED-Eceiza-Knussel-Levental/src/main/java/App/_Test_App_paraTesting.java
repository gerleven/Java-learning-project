package App;

import java.util.ArrayList;

import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.UnidadDeMedida;
import isi.died.tp.estructuras.Arbol;
import isi.died.tp.estructuras.ArbolBinarioBusqueda;
import isi.died.tp.estructuras.Grafo;
import logica.ComparadorCostoAscendente;
import logica.ComparadorCostoDescendente;
import logica.ComparadorNombreAscendente;
import logica.ComparadorNombreDescendente;
import logica.ComparadorStockAscendente;
import logica.ComparadorStockDescendente;
import logica.Logica;

public class _Test_App_paraTesting {
	
	public static void main(String args[]) {
		
		System.out.println("Main:");
		
		UnidadDeMedida a = UnidadDeMedida.KILO;
		System.out.println(a);
		Insumo i = new Insumo(1,"hola",UnidadDeMedida.PIEZA, 750.5, 3.0,false);
		System.out.println(i.getUnidad_de_medida());
	}
}
