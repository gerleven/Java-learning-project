package App;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Graphic.Agregar.VentanaAgregar;
import Graphic.Buscar.VentanaBuscar;
import PantallaGrafo.EjecutarGrafo;
import Parte5Ventanas.Opciones;
import logica.Logica;

import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;


public class Bienvenido extends JFrame {

	private String version = "Versión: "+
			//"20190920-1636"
			"20190920-1750 (tested 20191001-0008)"
			;
	public static Boolean cartelito = false; 
	private JPanel contentPane;
	
	public static void main(String[] args) {
		//Logica.cargaDeDatos();
		//Logica.cargaDeDatosMochila();
		//Logica.mochilaTest();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Bienvenido frame = new Bienvenido();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} 
		});
	}
 

	public Bienvenido() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 846, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		setLocationRelativeTo(null); //para centrar
		
		JLabel lblBienvenido = new JLabel("Bienvenido al sistema de plantas de acopio.");
		lblBienvenido.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblBienvenido.setBounds(27, 23, 507, 27);
		contentPane.add(lblBienvenido);
		
		
		
		JButton btnAgregar = new JButton("Agregar");
		btnAgregar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				final VentanaAgregar agregar= new VentanaAgregar();
				agregar.setVisible(true);
				dispose();
			}
		});
		btnAgregar.setBounds(331, 121, 175, 25);
		contentPane.add(btnAgregar);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Logica.mostrarListas();
				final VentanaBuscar a = new VentanaBuscar();  //falta metodo de busqueda
				a.setVisible(true);
				dispose();
			}
		});
		btnBuscar.setBounds(331, 178, 175, 25);
		contentPane.add(btnBuscar);
		
		
		JButton btnCerrar = new JButton("Cerrar");
		btnCerrar.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnCerrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnCerrar.setBounds(719, 475, 97, 25);
		//contentPane.add(btnCerrar);  //HO HABILITAR!!
		
		
		JButton btnGafo = new JButton("Grafo");
		btnGafo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnGafo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final EjecutarGrafo a= new EjecutarGrafo();
				a.setVisible(true);
				dispose();
			}
		});
		btnGafo.setBounds(331, 234, 175, 25);
		contentPane.add(btnGafo);
		
			
		JLabel lblPorFavorSeleccione = new JLabel("Por favor seleccione una opción.");
		lblPorFavorSeleccione.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblPorFavorSeleccione.setBounds(305, 83, 229, 16);
		contentPane.add(lblPorFavorSeleccione);
		
		JButton btnEnvios = new JButton("Envios");
		btnEnvios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final Opciones a= new Opciones();
				a.setVisible(true);
				dispose();
			}
		});
		btnEnvios.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnEnvios.setBounds(331, 291, 175, 25);
		contentPane.add(btnEnvios);
		
		JLabel label = new JLabel("Datos de prueba:");
		label.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label.setBounds(359, 345, 133, 16);
		contentPane.add(label);
		
		JButton btnEjGrafo = new JButton("Ejemplo Grafo");
		btnEjGrafo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnEjGrafo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Logica.cargaDeDatos();
			}
		});
		btnEjGrafo.setBounds(331, 375, 171, 25);
		contentPane.add(btnEjGrafo);
		
		JButton btnGrafoMinimo = new JButton("Grafo Minimo");
		btnGrafoMinimo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Logica.cargaDeDatosMinimal();
			}
		});
		btnGrafoMinimo.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnGrafoMinimo.setBounds(331, 425, 171, 25);
		contentPane.add(btnGrafoMinimo);
		
		JButton btnMochila = new JButton("Mochila");
		btnMochila.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Logica.mochilaTest();
			}
		});
		btnMochila.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnMochila.setBounds(331, 475, 171, 25);
		contentPane.add(btnMochila);
		
		JButton btnResetDatos = new JButton("Reset Datos prueba");
		btnResetDatos.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnResetDatos.setBounds(650, 475, 171, 25);
		contentPane.add(btnResetDatos);
		btnResetDatos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Logica.resetValores();
				JOptionPane.showMessageDialog(null, "Datos reseteados satisfactoriamente.","¡Exito!", JOptionPane.WARNING_MESSAGE);
			}
			
		});
		
		JLabel label_1 = new JLabel("Integrantes:");
		label_1.setFont(new Font("Sitka Small", Font.BOLD, 16));
		label_1.setBounds(12, 400, 199, 21);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("Eceiza Belén");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_2.setBounds(12, 430, 199, 21);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("Knussel Agustín");
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_3.setBounds(12, 450, 199, 21);
		contentPane.add(label_3);

		JLabel label_4 = new JLabel("Levental Germán");
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 16));
		label_4.setBounds(12, 470, 199, 21);
		contentPane.add(label_4);
		

		JLabel label_5 = new JLabel(version);
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_5.setBounds(12, 490, 276, 21);
		contentPane.add(label_5);
		
	}
}