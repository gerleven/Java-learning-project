package isi.died.tp.estructuras;

import static org.junit.Assert.*;
import org.junit.Test;

import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.InsumoLiquido;
import isi.died.tp.dominio.UnidadDeMedida;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;

import org.junit.Test;

public class InsumoLiquidoTest {
	Insumo insumoLiquido1,insumoLiquido2,insumoLiquido3;
	
	@Before
	public void setUp() {
		//public InsumoLiquido(Integer id, String nombre, UnidadDeMedida unidad, Double costo, Boolean esRefrigerado, Double densidad){
		insumoLiquido1 = new InsumoLiquido(1, "primer insumo liquido de prueba", UnidadDeMedida.KILO, 15.5, true, 15.50);
		insumoLiquido2 = new InsumoLiquido(2, "segundo insumo liquido de prueba", UnidadDeMedida.KILO, 15.5, true, 52.50);
		insumoLiquido2.setCantidadEnStockDePlanta(3);
		insumoLiquido3 = new InsumoLiquido(3, "tercer insumo liquido de prueba", UnidadDeMedida.KILO, 15.5, true, 75.50);
		insumoLiquido3.setCantidadEnStockDePlanta(17);
	}
		
	@Test
	public void testCalcularPeso() { 
		assertEquals(Double.valueOf(0.0),(((InsumoLiquido) insumoLiquido1).calcularPeso()));
		assertNotEquals(Double.valueOf(0.1574),(((InsumoLiquido) insumoLiquido2).calcularPeso()));
		assertEquals(Double.valueOf(0.1575),(((InsumoLiquido) insumoLiquido2).calcularPeso()));
		assertEquals(Double.valueOf(1.2835),(((InsumoLiquido) insumoLiquido3).calcularPeso()));
		assertNotEquals(Double.valueOf(1.28351),(((InsumoLiquido) insumoLiquido3).calcularPeso()));
																																			//Como hago para que me deje usar assertEquals(double,double); ???
	}

}