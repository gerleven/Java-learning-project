package isi.died.tp.estructuras;

import static org.junit.Assert.*;

import org.junit.Test;

public class MochilaTest {

	@Test
		public void testPD () {
			 Mochila m = new Mochila();
			 int[] pesos = {3,2,1,2};
			 int[] valor= {6,9,5,6};
			 boolean[] resultado = m.mejorEnvio(pesos,valor,4);
			 boolean[] esperado = {false,true,false,true};
			 assertArrayEquals( esperado, resultado );
		}

}
