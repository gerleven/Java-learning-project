package isi.died.tp.estructuras;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.Stock;
import isi.died.tp.dominio.UnidadDeMedida;

public class GrafoPlantaTest {
	public static final ArrayList<Insumo> listaInsumos = new ArrayList<Insumo>();
	
	public static Insumo i0,i1,i2,i3,i4,i5,i6,i7,i8,i9;
	final Stock stock1 = new Stock(1,i6,6,8);
	final Stock stock2 = new Stock(2,i7,15,8);
	final Stock stock3 = new Stock(1,i8,6,8);
	final Stock stock4 = new Stock(2,i9,15,8);
	List<Stock> listaStock = new ArrayList<Stock>();
	List<Stock> listaStock2 = new ArrayList<Stock>();
	
	
	@Before
	public void setUp() {
		listaInsumos.add(i0 = new Insumo(1, "primer insumo", UnidadDeMedida.KILO, 20.5, 30.5, false));
		listaInsumos.add(i1 = new Insumo(2, "seundo insumo", UnidadDeMedida.KILO, 24.5, 30.5, true));
		listaInsumos.add(i2 = new Insumo(3, "tercer insumo", UnidadDeMedida.KILO, 27.5, 30.5, false));
		listaInsumos.add(i3 = new Insumo(4, "cuarto insumo", UnidadDeMedida.KILO, 29.5, 30.5, false));
		listaInsumos.add(i4 = new Insumo(5, "quinta insumo", UnidadDeMedida.KILO, 31.0, 30.5, true));
		listaInsumos.add(i5 = new Insumo(6, "sexto insumo", UnidadDeMedida.KILO, 45.5, 30.5, false));
		listaInsumos.add(i6 = new Insumo(7, "septimo insumo", UnidadDeMedida.KILO, 47.5, 30.5, true));
		listaInsumos.add(i7 = new Insumo(8, "octavo insumo (liquido)", UnidadDeMedida.LITRO, 53.5, false));
		listaInsumos.add(i8 = new Insumo(9, "noveno insumo", UnidadDeMedida.KILO, 61.5, 30.5, true));
		listaInsumos.add(i9 = new Insumo(10, "decimo insumo", UnidadDeMedida.KILO, 78.5, 30.5, false));
		
		listaStock.add(stock1);
		listaStock.add(stock2);
		listaStock2.add(stock3);
		listaStock2.add(stock4);
	}
	
	
	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
