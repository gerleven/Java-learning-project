package isi.died.tp.estructuras;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.Planta;
import isi.died.tp.dominio.Stock;
import isi.died.tp.dominio.TipoPlanta;
import isi.died.tp.dominio.UnidadDeMedida;

public class PlantaTest {
	Insumo i1,i2,i3,i4;
	Stock s1,s2,s3,s4;
	List<Insumo> listaInsumo=new ArrayList<>();
	List<Stock> listaStock1=new ArrayList<>();
	Planta p1;
	
	
	@Before
	public void setUp() {
		//creo insumos
		i1=new Insumo(01,"Yerba",UnidadDeMedida.PIEZA,70.0,1.0,false);
		i2=new Insumo(02,"Termo",UnidadDeMedida.PIEZA,3000.0,1.0,false);
		i3=new Insumo(03,"Bombilla",UnidadDeMedida.PIEZA,100.0,1.0,false);
		i4=new Insumo(04,"Mate",UnidadDeMedida.PIEZA,500.0,1.0,false);
	
		//cargo lista insumo para test stockEntre 300 y 800
		listaInsumo.add(i1);
		listaInsumo.add(i2);
		listaInsumo.add(i4);
		
		//creo stocks
		s1=new Stock(01,i1,500,150);
		s2=new Stock(01,i2,500,150);
		s3=new Stock(01,i3,1000,300);
		s4=new Stock(01,i4,500,150);
		
		//cargo lista stock
		listaStock1.add(s1);
		listaStock1.add(s2);
		listaStock1.add(s3);
		listaStock1.add(s4);
	
		//creo planta
		p1=new Planta(01,"p1"/*,TipoPlanta.AcopioPuerto*/,listaStock1);	
	}
	
	
	@Test
	public void testCostoTotal() {
		assertEquals((Double)1885000.0,p1.costoTotal());
	}
	
	@Test
	public void testStockEntre() {
		//for (List<Insumo> lista : ) {
		//assertsEquals(listaInsumo.get(1).getStockTotalEnPlantas(),p1.stockEntre(300,800).get(1).getStockTotalEnPlantas());
		//assertsEquals(true,listaInsumo==(p1.stockEntre(300,800)));
		//}
	}
	//MIRAR USAR COMPARATOR
	
	@Test
  	public void testNecesitaInsumo() {
		//assertsEquals((Boolean)false,p1.necesitaInsumo(i1));
	}//MIRAR

}
