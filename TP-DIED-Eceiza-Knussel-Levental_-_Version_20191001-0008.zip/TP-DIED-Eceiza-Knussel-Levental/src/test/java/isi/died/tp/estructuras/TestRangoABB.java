package isi.died.tp.estructuras;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import isi.died.tp.dominio.Insumo;
import isi.died.tp.dominio.InsumoLiquido;
import isi.died.tp.dominio.Planta;
import isi.died.tp.dominio.UnidadDeMedida;

public class TestRangoABB {
	Insumo i0,i1,i2,i3,i4,i5,i6,i7,i8,i9;
	Arbol<Insumo> arbol1;
	ArrayList<Insumo> lista;

	@Before
	public void setUp() {
		// 4)
		//	public Insumo(int, String, 		UnidadDeMedida, 	double, int, double , boolean) {
		//	public Insumo(id, descripcion, 		unidad, 		costo, stock, peso, esRefrigerado ) {

		i0 = new Insumo(1, "primer insumo", UnidadDeMedida.KILO, 20.5, 30.5, false);
		i1 = new Insumo(2, "seundo insumo", UnidadDeMedida.KILO, 24.5, 30.5, true);
		i2 = new Insumo(3, "tercer insumo", UnidadDeMedida.KILO, 27.5, 30.5, false);
		i3 = new Insumo(4, "cuarto insumo", UnidadDeMedida.KILO, 29.5, 30.5, false);
		i4 = new Insumo(5, "quinta insumo", UnidadDeMedida.KILO, 31.0, 30.5, true);
		i5 = new Insumo(6, "sexto insumo", UnidadDeMedida.KILO, 45.5, 30.5, false);
		i6 = new Insumo(7, "septimo insumo", UnidadDeMedida.KILO, 47.5, 30.5, true);
		i7 = new Insumo(8, "octavo insumo (liquido)", UnidadDeMedida.LITRO, 53.5, false);
		i8 = new Insumo(9, "noveno insumo", UnidadDeMedida.KILO, 61.5, 30.5, true);
		i9 = new Insumo(10, "decimo insumo", UnidadDeMedida.KILO, 78.5, 30.5, false);
		
		arbol1 = new ArbolBinarioBusqueda<Insumo>(i6);
		arbol1.agregar(i1);
		arbol1.agregar(i8);
		arbol1.agregar(i2);
		arbol1.agregar(i9);
		arbol1.agregar(i0);
		arbol1.agregar(i3);
		arbol1.agregar(i5);
		arbol1.agregar(i4);
		
		lista = new ArrayList<>();
		lista.add(i1); //stock 2
		lista.add(i2);
		lista.add(i3);
		lista.add(i4);
		lista.add(i5);
		lista.add(i6);
		//lista.add(i7); // no fue agregado al arbol
		lista.add(i8); //stock 9
	}
	
	//gl_27/07->
	//Arbol <Planta> arbolPlantas = new ArbolBinarioBusqueda<Planta>(); //????????
	//gl_27/07<-
	
	
	@Test
	public void testRango() {
		assertEquals(lista,((ArbolBinarioBusqueda) arbol1).rango(2,9));
		assertNotEquals(lista,((ArbolBinarioBusqueda) arbol1).rango(1,9));
		assertNotEquals(lista,((ArbolBinarioBusqueda) arbol1).rango(3,9));
		assertNotEquals(lista,((ArbolBinarioBusqueda) arbol1).rango(2,5));
		assertNotEquals(lista,((ArbolBinarioBusqueda) arbol1).rango(2,12));
		lista.add(i7);
		assertNotEquals(lista,((ArbolBinarioBusqueda) arbol1).rango(2,9));
	}

}
